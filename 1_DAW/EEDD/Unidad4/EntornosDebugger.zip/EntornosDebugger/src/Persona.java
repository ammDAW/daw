

// <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
// #[regen=yes,id=DCE.C2E5724E-1483-453A-E999-ABD42AB09C26]
// </editor-fold> 
public class Persona {

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.68E083DD-EADF-4A65-0874-C5FBF8559822]
    // </editor-fold> 
    private String nombre;

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.AC2BCBFD-2E37-67DF-A0D6-DB029FC55694]
    // </editor-fold> 
    private int id_persona;

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.5A4D4576-1B56-6D4E-985E-B242E89939AB]
    // </editor-fold> 
    public Persona () {
    }

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,regenBody=yes,id=DCE.8448DEB0-548B-B467-5A12-D9CE9AC6EE11]
    // </editor-fold> 
    public int getId_persona () {
        return 0;
    }

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,regenBody=yes,id=DCE.A2197207-6DB4-33F5-1F36-AEEEB73F18C9]
    // </editor-fold> 
    public void setId_persona (int val) {
    }

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,regenBody=yes,id=DCE.62C01339-5DE5-5430-AE46-13DFC82B0834]
    // </editor-fold> 
    public String getNombre () {
        return null;
    }

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,regenBody=yes,id=DCE.647732CB-061B-4FBF-B80A-78437387A4CA]
    // </editor-fold> 
    public void setNombre (String val) {
    }

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.6FFE8A7E-A2D9-BA75-8654-AA7A987EF79D]
    // </editor-fold> 
    public class Unnamed {

    }

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.2AC2B243-671B-5E90-D0AB-4C79B5F1F462]
    // </editor-fold> 
    public class Cliente {

        // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
        // #[regen=yes,id=DCE.7EA356AB-43EA-CE0B-2373-F7233820EC1F]
        // </editor-fold> 
        public Cliente () {
        }

    }

}

