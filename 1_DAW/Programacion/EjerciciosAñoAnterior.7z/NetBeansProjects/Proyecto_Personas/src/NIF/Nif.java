/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package NIF;

/**
 *
 * @author Alberto
 */
public class Nif {
    
    private String nif;
    private static String letras[]={"T","R","W","A","G","M","Y","F","P","D","X","B","N","J","Z","S","Q","V","H","L","C","K","E"};
    
    public Nif(String NIF) {
        try {
            this.setNif(NIF);
        }catch (IllegalArgumentException error) {
            System.out.println("Error, NIF incorrecto. Se guardará un NIE por defecto.");
            this.nif=("00000000T");
        }
    }
    
    public Nif(int NIF) {
        this.setNif(NIF);
    }
    
    public Nif() {
        this.nif=("00000000T");
    }
    
    public Nif(Nif DNI) {
        this.setNif(DNI.toString());
    }
    
    @Override
    public String toString() {
        return this.nif;
    }
    
    public void setNif(String NIF) throws IllegalArgumentException {
        this.nif=NIF.toUpperCase().replace(" ", "");
        int num;
        if (this.nif.length()!=9)
            throw new IllegalArgumentException("Longitud del NIF incorrecto. ");
        try{
            num=Integer.parseInt(this.nif.substring(0, 8));
        } catch (NumberFormatException n) {
            System.out.println("Formato de NIF incorrecto. Se guardará un NIE por defecto.");
            this.nif=("00000000T");
            return;
        }
        String letra=this.nif.substring(8);
        int pos=num%23;
        if (!letra.equals(letras[pos]))
            throw new IllegalArgumentException("Letra del NIF incorrecta. ");
    }
    
    public void setNif(int NIF) throws IllegalArgumentException {
        if (NIF<1 || NIF>99999999) {
            throw new IllegalArgumentException ("Error, NIF incorrecto. ");
        }
        String temp=String.valueOf(NIF);
        for (int i = temp.length(); i < 8 ; i++) {
            temp='0'+temp;
        }
        this.nif=(temp+letras[NIF%23]);
        
    }
    
    public void setNif(Nif DNI) {
        this.setNif(DNI.toString());
    }
    
    public void setNif() {
        this.nif=("00000000T");
    }

    public String getNif() {
        return this.nif;
    }
    
    public String getNum() {
        return this.nif.substring(0, 8);
    }

    public String getLetra() {
        return this.nif.substring(8);
    }
    
    public boolean equals(Nif otro) {
        return this.nif.equals(otro.nif);
    }
}
