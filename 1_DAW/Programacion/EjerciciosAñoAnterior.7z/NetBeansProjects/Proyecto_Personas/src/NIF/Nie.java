/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package NIF;

/**
 *
 * @author Alberto
 */
public class Nie {
    
    private String nie;
    private static String letras[]={"T","R","W","A","G","M","Y","F","P","D","X","B","N","J","Z","S","Q","V","H","L","C","K","E"};
    
    public Nie(String NIE) {
        try {
            this.setNie(NIE);
        }catch (IllegalArgumentException error) {
            System.out.println("Error, NIE incorrecto. Se guardará un NIE por defecto. ");
            this.nie=("X0000000T");
        }
    }
    
    public Nie() {
        this.nie=("X0000000T");
    }
    
    public Nie(Nie NIE) {
        this.setNie(NIE.toString());
    }
    
    @Override
    public String toString() {
        return this.nie;
    }
    
    public void setNie(String NIE) throws IllegalArgumentException {
        NIE=NIE.toUpperCase().replace(" ", "");
        int num;
        String temp;
        if (NIE.length()!=9)
            throw new IllegalArgumentException("Longitud del NIE incorrecto. ");
        char let=NIE.charAt(0);
        if (let!='X' && let!='Y' && let!='Z') {
            throw new IllegalArgumentException ("La primera letra no corresponde con la de un NIE. ");
        }
        try{
            num=Integer.parseInt(NIE.substring(1, 8));
        } catch (NumberFormatException n) {
            System.out.println("Formato de NIE incorrecto, no hay 7 dígitos. Se guardará un NIE por defecto.");
            this.nie=("X0000000T");
            return;
        }
        switch(let){
            case 'Y': temp='1'+NIE.substring(1, 8); num=Integer.parseInt(temp); break;
            case 'Z': temp='2'+NIE.substring(1, 8); num=Integer.parseInt(temp);
        }
        String letra=NIE.substring(8);
        if (!letra.equals(letras[num%23])) 
            throw new IllegalArgumentException("Letra del NIE incorrecta. ");
        this.nie=NIE;
    }
    
    public void setNie(Nie NIE) {
        this.setNie(NIE.toString());
    }

    public String getNie() {
        return this.nie;
    }
    
    public String getNum() {
        return this.nie.substring(1, 8);
    }

    public String getLetraInicial() {
        return this.nie.substring(0);
    }
    
    public String getLetraFinal() {
        return this.nie.substring(8);
    }
    
    public boolean equals(Nie otro) {
        return this.nie.equals(otro.nie);
    }
}
