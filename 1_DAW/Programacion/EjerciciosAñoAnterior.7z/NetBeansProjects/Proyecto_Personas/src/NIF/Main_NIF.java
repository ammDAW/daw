/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package NIF;

import Metodos.Pedir;

/**
 *
 * @author Alberto
 */
public class Main_NIF {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Nif primero=new Nif(Pedir.cadena("Introduce tu DNI con su letra correspondiente: "));
        System.out.println("El DNI introducido es "+primero);
        Nif segundo=new Nif(Pedir.entero("Introduce el número de tu DNI sin letra: "));
        System.out.println("El DNI introducido con su letra correspondiente es "+segundo);
        Nif tercero=new Nif("23027712C");
        Nif cuarto=new Nif(23027712);
        if (tercero.equals(cuarto)) {
            System.out.println("Los DNIs tercero ("+tercero+") y cuarto ("+cuarto+") son iguales. ");
        } else System.out.println("Los DNIs tercero ("+tercero+") y cuarto ("+cuarto+") son diferentes. ");
        
    }
    
}
