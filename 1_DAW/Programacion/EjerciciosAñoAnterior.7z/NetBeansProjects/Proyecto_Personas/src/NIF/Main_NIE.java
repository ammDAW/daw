/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package NIF;

import Metodos.Pedir;

/**
 *
 * @author Alberto
 */
public class Main_NIE {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Nie primero=new Nie(Pedir.cadena("Introduce tu NIE con sus letras correspondientes: "));
        System.out.println("El NIE introducido es: "+primero);
        Nie segundo=new Nie("X3027712C");
        System.out.println("El segundo NIE introducido es: "+segundo);
        Nie tercero=new Nie("X3027713F");
        System.out.println("El tercer NIE introducido es: "+tercero);
        
        /*Ninguno de los dos NIEs introducidos va a funcionar, no pasan el filtro del algoritmo.
        El primero, por ejemplo, debería tener una S en lugar de la C, y el tercero debería tener una Q.
        */
    }
    
}
