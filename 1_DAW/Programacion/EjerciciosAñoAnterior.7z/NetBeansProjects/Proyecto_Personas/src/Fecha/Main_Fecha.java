/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Fecha;

import Metodos.Pedir;

/**
 *
 * @author Alberto
 */
public class Main_Fecha {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Fecha f1=new Fecha();
        Fecha f2=new Fecha(20,2,1);
        Fecha f3=new Fecha();
        boolean correcta=false;
        System.out.println(" ");
        System.out.println("Vamos a crear una fecha introducida por teclado. ");
        do {
            f3.setFecha(Pedir.entero("Introduce el día: "), Pedir.entero("Introduce el número del mes: "), Pedir.entero("Introduce el año: "));
            if(!f3.equals(1, 1, 2000))
                correcta=true;
        } while(!correcta);
        Fecha f4=new Fecha(f2);
        System.out.println(" ");
        System.out.println("Vamos a completar otra fecha por teclado. ");
        Fecha f5=new Fecha(Pedir.entero("Introduce el día: "),12,Pedir.entero("Introduce el año: "));
        Fecha f6=new Fecha(f4.getDia(),f5.getMes(),2000);
        System.out.println(f1.toString(2));
        System.out.println(f2.toString(3));
        System.out.println(f3.toString(4));
        System.out.println(f4.toString(6));
        System.out.println(f5.toString(2));
        System.out.println(f6.toString(6));
        f4.setFecha(f5);
        f6.setFecha(f1.getDia(), f1.getMes(), f3.getAnio());
        System.out.println(" ");
        System.out.println("Desde el 1 de Enero de 2000 hasta la fecha f5 han transcurrido "+f5.diasEntreFechas(new Fecha())+" días. ");
        /*
        Comparamos f5 con una fecha por defecto nueva que es 1/1/2000 puesto que toDias cuenta desde el año 1900
        */
        f3.fechaSiguiente();
        System.out.println("La fecha siguiente a la fecha f3 es "+f3.toString(1));
        System.out.println("Entre las fechas f4 y f5 han transcurrido "+f4.diasEntreFechas(f5)+" días. ");
        System.out.println("La fecha menor entre f5 y f2 es "+f5.fechaMenor(f2).toString(2)+". ");
        System.out.println("La fecha mayor entre f1 y f5 es "+f1.fechaMayor(f5).toString(2)+". ");
        f4.fechaAnterior();
        System.out.println("La fecha anterior a la fecha f4 es "+f4.toString(1));
        Fecha f7=new Fecha(f3.fechaMayor(f4));
        System.out.println(f7);
    }
    
}
