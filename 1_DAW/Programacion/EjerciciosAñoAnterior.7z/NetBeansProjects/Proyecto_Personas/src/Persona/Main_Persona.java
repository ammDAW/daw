/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Persona;

import Fecha.Fecha;
import Metodos.Pedir;
import NIF.Nif;

/**
 *
 * @author Alberto
 */
public class Main_Persona {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Persona ag007=new Persona("Bond","James","Bond","soltero",'v',10,2,2001,12345678);
        
        System.out.println("Vamos a crear una persona nueva con los datos introducidos por teclado. ");
        Persona p=new Persona(Pedir.cadena("Introduce tu nombre: "),Pedir.cadena("Introduce tu primer apellido: "),Pedir.cadena("Introduce tu segundo apellido: "),Pedir.cadena("Introduce tu estado civil: "),Pedir.Char("Introduce tu sexo (v para masculino, m para femenino): "),Pedir.entero("Introduce tu día de nacimiento: "),Pedir.entero("Introduce tu mes de nacimiento: "),Pedir.entero("Introduce tu año de naciemiento: "),Pedir.entero("Introduce tu DNI sin letra: "));
        
        System.out.println(" ");
        System.out.println(ag007);
        System.out.println(p);
        
        p.getFechaNac().fechaSiguiente();
        System.out.println(p.getFechaNac());
    }
}
