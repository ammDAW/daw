/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Persona;

import Fecha.Fecha;
import NIF.Nie;
import NIF.Nif;

/**
 *
 * @author Alberto
 */
public class Persona {
    
    private static int numPersonas=0;
    private int id;
    private String nombre, apellido1, apellido2, estado;
    private char sexo;
    private Fecha fechaNac;
    private Nif NIF=null;
    private Nie NIE=null;
    private final static char SEXO[]={'V','M'};
    private final static String ESTADO[]={"SOLTERO","CASADO","VIUDO","DIVORCIADO"};
    
    
    public Persona() {
        this.nombre=(" ");
        this.apellido1=(" ");
        this.apellido2=(" ");
        this.estado=("SOLTERO");
        this.sexo=('V');
        this.setFechaNac();
        this.setNif();
        this.NIE=null;
        numPersonas++;
        this.id=numPersonas;
    }
    
    public Persona(String nombre, String apellido1, String apellido2, String estado, char sexo, Fecha nac, Object obj) {
        this.setPersona(nombre, apellido1, apellido2, estado, sexo, nac, obj);
        numPersonas++;
        this.id=numPersonas;
    }
    
    public Persona(String nombre, String apellido1, String apellido2, String estado, char sexo, Fecha nac, int dni) {
        this.setPersona(nombre, apellido1, apellido2, estado, sexo, nac, dni);
        numPersonas++;
        this.id=numPersonas;
    }
    
    public Persona(String nombre, String apellido1, String apellido2, String estado, char sexo, int dia, int mes, int anio, int dni) {
        this.setPersona(nombre, apellido1, apellido2, estado, sexo, dia, mes, anio, dni);
        numPersonas++;
        this.id=numPersonas;
    }
    
    public Persona(Persona otra) {
        this.setPersona(otra);
        numPersonas++;
        this.id=numPersonas;
    }
    
    public void setPersona(String nombre, String apellido1, String apellido2, String estado, char sexo, Fecha nac, Object obj) {
        try {
            this.setNombre(nombre);
            this.setApellido1(apellido1);
            this.setApellido2(apellido2);
            this.setEstado(estado);
            this.setSexo(sexo);
            this.setFechaNac(nac);
            if (obj instanceof Nif) {
                this.NIF=(Nif)obj;
            }
            if (obj instanceof Nie) {
                this.NIE=(Nie)obj;
            }
            else {
                this.setNif();
                this.NIE=null;
            }
        } catch (IllegalArgumentException nuevo) {
            System.out.println("Los datos introducidos son incorrectos, objeto por defecto. ");
            this.nombre=(" ");
            this.apellido1=(" ");
            this.apellido2=(" ");
            this.estado=("SOLTERO");
            this.sexo=('V');
            this.setFechaNac();
            this.setNif();
            this.NIE=null;
        }
    }
    
    public void setPersona(String nombre, String apellido1, String apellido2, String estado, char sexo, Fecha nac, int dni) {
        try {
            this.setNombre(nombre);
            this.setApellido1(apellido1);
            this.setApellido2(apellido2);
            this.setEstado(estado);
            this.setSexo(sexo);
            this.setFechaNac(nac);
            this.setNif(dni);
        } catch (IllegalArgumentException nuevo) {
            System.out.println("Los datos introducidos son incorrectos, objeto por defecto. ");
            this.nombre=(" ");
            this.apellido1=(" ");
            this.apellido2=(" ");
            this.estado=("SOLTERO");
            this.sexo=('V');
            this.setFechaNac();
            this.setNif();
            this.NIE=null;
        }
    }
    
    public void setPersona(String nombre, String apellido1, String apellido2, String estado, char sexo, int dia, int mes, int anio, int dni) {
        try {
            this.setNombre(nombre);
            this.setApellido1(apellido1);
            this.setApellido2(apellido2);
            this.setEstado(estado);
            this.setSexo(sexo);
            this.setFechaNac(dia, mes, anio);
            this.setNif(dni);
        } catch (IllegalArgumentException nuevo) {
            System.out.println("Los datos introducidos son incorrectos, objeto por defecto. ");
            this.nombre=(" ");
            this.apellido1=(" ");
            this.apellido2=(" ");
            this.estado=("SOLTERO");
            this.sexo=('V');
            this.setFechaNac();
            this.setNif();
            this.NIE=null;
        }
    }
    
    public void setPersona() {
        this.nombre=(" ");
        this.apellido1=(" ");
        this.apellido2=(" ");
        this.estado=("SOLTERO");
        this.sexo=('V');
        this.setFechaNac();
        this.setNif();
        this.NIE=null;
        System.out.println("Hemos modificado el objeto a una Persona por defecto.");
    }
    
    public void setPersona(Persona otra) {
        if(otra.NIF!=null)
            this.setPersona(otra.nombre, otra.apellido1, otra.apellido2, otra.estado, otra.sexo, otra.fechaNac, otra.NIF);
        if(otra.NIE!=null)
            this.setPersona(otra.nombre, otra.apellido1, otra.apellido2, otra.estado, otra.sexo, otra.fechaNac, otra.NIE);
    }
    
    public void setNombre(String nombre) {
        for (int i = 0; i < 9; i++)
                nombre=nombre.replaceAll(Integer.toString(i), "");
        this.nombre=(nombre.substring(0, 1).toUpperCase()+nombre.substring(1, nombre.length()).toLowerCase()).trim();
    }
    
    public void setApellido1(String apellido) {
        for (int i = 0; i < 9; i++)
                apellido=apellido.replaceAll(Integer.toString(i), "");
        this.apellido1=(apellido.substring(0, 1).toUpperCase()+apellido.substring(1, apellido.length()).toLowerCase()).trim();
    }
    
    public void setApellido2(String apellido) {
        for (int i = 0; i < 9; i++)
                apellido=apellido.replaceAll(Integer.toString(i), "");
        this.apellido2=(apellido.substring(0, 1).toUpperCase()+apellido.substring(1, apellido.length()).toLowerCase()).trim();
    }
    
    public void setNombreCompleto(String nombre, String apellido1, String apellido2) {
        this.setNombre(nombre);
        this.setApellido1(apellido1);
        this.setApellido2(apellido2);
    }
    
    public void setEstado(String estado) throws IllegalArgumentException {
        estado=estado.toUpperCase();
        boolean cierto=false;
        for (int i = 0; i < ESTADO.length; i++) {
            if (estado.equals(ESTADO[i])) {
                cierto=true; break;
            }
        } if (!cierto)
            throw new IllegalArgumentException("El estado civil indicado no es correcto. ");
        this.estado=estado;
    }
    
    public void setSexo(char sexo) throws IllegalArgumentException {
        sexo=Character.toUpperCase(sexo);
        boolean cierto=false;
        for (int i = 0; i < SEXO.length; i++) {
            if (sexo==SEXO[i]) {
                cierto=true; break;
            }
        } if (!cierto)
            throw new IllegalArgumentException("El sexo indicado no es correcto. ");
        this.sexo=sexo;
    }
    
    public void setFechaNac(int dia, int mes, int anio) {
        this.fechaNac=new Fecha(dia, mes, anio);
    }
    
    public void setFechaNac(Fecha otra) {
        this.fechaNac=new Fecha(otra);
    }
    
    public void setFechaNac() {
        this.fechaNac=new Fecha();
    }
    
    public void setNif(String NIF) {
        this.NIE=null;
        this.NIF=new Nif(NIF);
    }
    
    public void setNif(int NIF) {
        this.NIE=null;
        this.NIF=new Nif(NIF);
    }
    
    public void setNif(Nif NIF) {
        this.NIE=null;
        this.NIF=new Nif(NIF);
    }
    
    public void setNif() {
        this.NIE=null;
        this.NIF=new Nif();
    }
    
    public void setNie(String NIE) {
        this.NIF=null;
        this.NIE=new Nie(NIE);
    }
    
    public void setNie(Nie NIE) {
        this.NIF=null;
        this.NIE=new Nie(NIE);
    }
    
    public void setNie() {
        this.NIF=null;
        this.NIE=new Nie();
    }
    
    @Override
    public String toString() {
        if (" ".equals(this.nombre) && " ".equals(this.apellido1) && " ".equals(this.apellido2)) {
            return ("La persona a mostrar es la persona por defecto, sin nombre y apellidos, soltero y varón, con fecha de nacimiento 1 de Enero del 2000, DNI 00000000T e ID número "+this.id+".");
        }
        if (this.NIE==null) {
            return (this.nombre+" "+this.apellido1+" "+this.apellido2+" de sexo "+this.sexo+" y estado civil "+this.estado+", cuya fecha de nacimiento es "+this.fechaNac.toString(4)+", con NIF número "+this.NIF+" e ID número "+this.id+".");
        }
        else {
            return (this.nombre+" "+this.apellido1+" "+this.apellido2+" de sexo "+this.sexo+" y estado civil "+this.estado+", cuya fecha de nacimiento es "+this.fechaNac.toString(4)+", con NIE número "+this.NIE+" e ID número "+this.id+".");
        } 
    }

    public static int getNumPersonas() {
        return numPersonas;
    }

    public String getNombre() {
        return this.nombre;
    }

    public String getApellido1() {
        return this.apellido1;
    }

    public String getApellido2() {
        return this.apellido2;
    }

    public String getEstado() {
        return this.estado;
    }

    public String getSexo() {
        return Character.toString(this.sexo);
    }

    public Fecha getFechaNac() {
        return this.fechaNac;
    }

    public Nif getNIF() {
        return this.NIF;
    }

    public Nie getNIE() {
        return this.NIE;
    }
    
    @Override
    public Persona clone() {
        return new Persona(this);
    }
    
    @Override
    public void finalize() {
        System.out.println("Se ha destruido el objeto actual. ");
        numPersonas--;
    }
}
