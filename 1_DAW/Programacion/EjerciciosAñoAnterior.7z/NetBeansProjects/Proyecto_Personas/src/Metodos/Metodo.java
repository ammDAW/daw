package Metodos;

import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author nomat
 */
public class Metodo {

    public static boolean esMayuscula(char letra){
        boolean mayuscula;
        mayuscula=(letra>='A' && letra<='Z');
        return mayuscula;
    }
    
    public static boolean esMinuscula(char letra){
        boolean minuscula;
        minuscula=(letra>='a' && letra<='z');
        return minuscula;
    }
    
    public static boolean esLetra(char letra){
        boolean esletra;
        if (Metodo.esMayuscula(letra) || Metodo.esMinuscula(letra))
        esletra=true;
        else esletra=false;
        return esletra;
    }
    
    public static boolean esBisiesto1(String mensaje)
    {
        Scanner teclado=new Scanner(System.in);
        String cadena;
        System.out.print(mensaje);
        boolean esBisiesto=false; boolean bucle=false; int anio;
        do
        {
        try
        {
        do
        {
        cadena=teclado.nextLine();
        anio=Integer.parseInt(cadena);
        bucle=true;
        if (anio<0) System.out.print("El año introducido no es correcto, vuelve a intentarlo: ");
        }
        while (anio<0);
        if (anio%4==0 && (anio%100!=0 || anio%400==0)) esBisiesto=true;

        }catch(NumberFormatException e)
        {
            System.out.println("Te has equivocado, no has introducido un año válido.");
            System.out.println(" ");
            System.out.print("Vuelve a introducir un número: ");
        }
        }while (!bucle);
        
        String resultado=(esBisiesto==true)?"El año introducido es bisiesto. ":"El año introducido no es bisiesto. ";
        System.out.println(resultado);
                
        return esBisiesto;
    }
    
    public static boolean esBisiesto2(int anio)
    {
        boolean esBisiesto=false;
        
        if (anio%4==0 && (anio%100!=0 || anio%400==0)) esBisiesto=true;

        return esBisiesto;
    }
    
    public static boolean esFechaCorrecta(int dia, int mes, int anio)
    {
        boolean esFecha=false;
        int diasMeses[]={0,31,28,31,30,31,30,31,31,30,31,30,31};
        
        if (anio>2000 && anio<2100)
        {
            if (mes>0 && mes<13)
            {
                if (Metodo.esBisiesto2(anio))
                    diasMeses[2]=29;
                if (dia>0 && dia<=diasMeses[mes])
                    esFecha=true;
            }
        }
        
        return esFecha;
    }
    
    public static void mostrarVector (int v[])
    {
        for (int i=0;i<v.length;i++)
            System.out.print(v[i]+"\t");
            System.out.println(" ");
    }
    
    public static void mostrarMatriz (int v[][])
    {
        for (int i=0;i<v.length;i++)
        {
            for (int j=0;j<v[i].length;j++)
                System.out.print(v[i][j]+"\t");
            System.out.println(" ");
        }
    }
    
    public static int contarVector (int v[])
    {
        int contador=0;
            for (int i=0;i<v.length;i++)
                contador+=v[i];
        return contador;
    }
    
    public static int contarMatriz (int v[][])
    {
        int contador=0;
        for (int i=0;i<v.length;i++)
        {
            for (int j=0;j<v[i].length;j++)
                contador+=v[i][j];
        }
        return contador;
    }
    
    public static int[] pedirVectorInt (int tamanio)
    {
        int v[]=new int[tamanio];
        for (int i=0;i<v.length;i++)
        {
            v[i]=Pedir.entero("Dime el valor de la posición "+(i+1)+" del vector: ");
        }
        return v;
    }
    
    public static int[] pedirVectorTamaño (String mensaje)
    {
        System.out.println(mensaje);
        int tamanio=Pedir.entero("Introduce el tamaño del vector: ");
        int v[]=new int[tamanio];
        System.out.println(" ");
        for (int i=0;i<v.length;i++)
        {
            v[i]=Pedir.entero("Dime el valor de la posición "+(i+1)+" del vector: ");
        }
        return v;
    }
    
    public static double[] pedirVectorReal (int tamanio)
    {
        double v[]=new double[tamanio];
        for (int i=0;i<v.length;i++)
        {
            v[i]=Pedir.entero("Dime el valor de la posición "+(i+1)+" del vector: ");
        }
        return v;
    }
    
    public static int[][] pedirMatrizInt (int m, int n)
    {
        int v[][]=new int[m][n];
        for (int i=0;i<v.length;i++)
        {
            for (int j=0;j<v[i].length;j++)
            {
               v[i][j]=Pedir.entero("Dime el valor de la posición ["+(i+1)+"] ["+(j+1)+"] del vector: "); 
            }
        }
        return v;
    }
    
    public static int mayorVector(int v[])
    {
        int mayor=v[0];
        
        for (int i = 1; i < v.length; i++) 
        {
            if (mayor < v[i])
                mayor = v[i];
        }
        return mayor;
    }
    
    public static int menorVector(int v[])
    {
        int menor=v[0];
        
        for (int i = 1; i < v.length; i++) 
        {
            if (menor > v[i])
                menor = v[i];
        }
        return menor;
    }
    
    public static double mediaVectorInt (int v[])
    {
        int cont0=0, contador=0;
        for (int i=0;i<v.length;i++)
        {
            contador+=v[i];
            if (v[i]==0) cont0++;
        }
        double media=(double)contador/(double)(v.length-cont0);
        return media;
    }
    
    public static int[] decirIndiceInt(int v[])
    {
        int vector[]=new int [v.length];
        for (int i = 0; i < v.length; i++)
        {
            vector[i]=(v[i]+1);
        }
    return vector;
    }
    
    public static int[][] decirIndiceMatriz(int v[][])
    {
        int vector[][]=new int [v.length][v[0].length];
        for (int i = 0; i < v.length; i++)
            for (int j = 0; j < v[i].length; j++)
                vector[i][j]=(v[i][j]+1);                
            /**
             * SOLO FUNCIONA CON MATRICES CUADRADAS O RECTANGULARES
             */
    return vector;
    }
    
    public static int[] ordenarVector(int v[])
    {
        int mayor=v[0]; int posicion=0;
        for (int i = 1; i < v.length; i++)
        {
            for (int j = 1; j <= v.length-i; j++)
            {
                if(mayor<v[j])
                {
                    mayor=v[j];
                    posicion=j;
                }
            }
            v[posicion]=v[v.length-i];
            v[v.length-i]=mayor;
            mayor=v[0];
            posicion=0;
        }
            
    return v;
    }
    
    public static int[] ordenarVectorBurbuja(int v[])
    {
        int mayor;
        for (int i = 1; i < v.length; i++)
        {
            for (int j = 0 ; j < v.length-i; j++)
            {
                if (v[j]>v[j+1])
                {
                    mayor=v[j];
                    v[j]=v[j+1];
                    v[j+1]=mayor;
                }
                
            }
        }
        return v;
    }
    
    public static void busquedaLinealMatriz(int v[][])
    {
        int x=Pedir.entero("Introduce un número para comprobar si se encuentra dentro de una matriz: ");
        int cont=0; boolean esta=false;
        
        for (int i = 0; i < v.length; i++)
        {
            for (int j = 0; j < v[i].length; j++) 
            {
                if (v[i][j]==x)
                {
                    esta=true;
                    cont++;
                }
            }
            
        }
        System.out.println(" ");
        if (esta)
        {
            if (cont==1)
            {
                int p[]=new int[2];
                for (int i = 0; i < v.length; i++)
                    {
                        for (int j = 0; j < v[i].length; j++) 
                        {
                            if (v[i][j]==x)
                            {
                                p[0]=i;
                                p[1]=j;
                            }
                        }
                    }
                p=Metodo.decirIndiceInt(p);
                System.out.println("Se ha encontrado el número "+cont+" veces en el Array, en las posiciones: ");
                Metodo.mostrarVector(p);
            }
            else
            {
                int p[][]=new int[cont][2]; int k=0;
                    for (int i = 0; i < v.length; i++)
                    {
                        for (int j = 0; j < v[i].length; j++) 
                        {
                            if (v[i][j]==x)
                            {
                                p[k][0]=i;
                                p[k][1]=j;
                                k++;
                            }
                        }
                    }
                    p=Metodo.decirIndiceMatriz(p);
                    System.out.println("Se ha encontrado el número "+cont+" veces en el Array, en las posiciones: ");
                    Metodo.mostrarMatriz(p);
            }           
        }
        else System.out.println("No se ha encontrado el número en la matriz. ");
        /**
         * SIN TERMINAR DE IR BIEN 
         *
         */
    }
    
    public static String invertirCadena(String texto)
    {
        String textoInvertido="";
        for (int i = texto.length()-1; i >= 0; i--)
            textoInvertido=textoInvertido + texto.charAt(i);
        return textoInvertido;
    }
    
    public static String quitarEspaciosTexto(String texto)
    {
        texto=texto.trim();
        String palabras[]=texto.split(" ");
        String textoSin="";
        for (int i = 0; i < palabras.length; i++)
            textoSin+=palabras[i];
        return textoSin;
    }
}
