package Metodos;

import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author nomat
 */
public class Pedir {
    
    public static int entero(String mensaje)
    {
        Scanner teclado=new Scanner(System.in);
        String cadena;
        System.out.print(mensaje);
        int n=0;
        boolean entero=false;
        
        do
        {
        try
        {
        cadena=teclado.nextLine();
        n=Integer.parseInt(cadena);
        entero=true;
        }catch(NumberFormatException e)
        {
            System.out.println(" ");
            System.out.println("Te has equivocado, no has introducido un número entero.");
            System.out.println(" ");
            System.out.print("Vuelve a introducir un número: ");
        }
        }while (!entero);
        
        return n;
    }
    
    public static byte Byte(String mensaje)
    {
        Scanner teclado=new Scanner(System.in);
        String cadena;
        System.out.print(mensaje);
        byte n=0;
        boolean cierto=false;
        
        do
        {
        try
        {
        cadena=teclado.nextLine();
        n=Byte.parseByte(cadena);
        cierto=true;
        }catch(NumberFormatException e)
        {
            System.out.println("Te has equivocado, no has introducido un byte.");
            System.out.println(" ");
            System.out.print("Vuelve a introducir un número: ");
        }
        }while (!cierto);
        
        return n;
    }
    
    public static short Short(String mensaje)
    {
        Scanner teclado=new Scanner(System.in);
        String cadena;
        System.out.print(mensaje);
        short n=0;
        boolean shorty=false;
        
        do
        {
        try
        {
        cadena=teclado.nextLine();
        n=Short.parseShort(cadena);
        shorty=true;
        }catch(NumberFormatException e)
        {
            System.out.println("Te has equivocado, no has introducido un número short.");
            System.out.println(" ");
            System.out.print("Vuelve a introducir un número: ");
        }
        }while (!shorty);
        
        return n;
    }
    
    public static long Long(String mensaje)
    {
        Scanner teclado=new Scanner(System.in);
        String cadena;
        System.out.print(mensaje);
        long n=0;
        boolean longo=false;
        
        do
        {
        try
        {
        cadena=teclado.nextLine();
        n=Long.parseLong(cadena);
        longo=true;
        }catch(NumberFormatException e)
        {
            System.out.println("Te has equivocado, no has introducido un número long.");
            System.out.println(" ");
            System.out.print("Vuelve a introducir un número: ");
        }
        }while (!longo);
        
        return n;
    }
    
    public static double Double(String mensaje)
    {
        Scanner teclado=new Scanner(System.in);
        String cadena;
        System.out.print(mensaje);
        double n=0;
        boolean dublo=false;
        
        do
        {
        try
        {
        cadena=teclado.nextLine();
        n=Double.parseDouble(cadena);
        dublo=true;
        }catch(NumberFormatException e)
        {
            System.out.println("Te has equivocado, no has introducido un número entero.");
            System.out.println(" ");
            System.out.print("Vuelve a introducir un número: ");
        }
        }while (!dublo);
        
        return n;
    }
    
    public static char Char(String mensaje)
    {
        Scanner teclado=new Scanner(System.in);
        String cadena;
        System.out.print(mensaje);
        char n=0;
        boolean caracter=false;
        
        do
        {
        try
        {
        cadena=teclado.nextLine();
        n=cadena.charAt(0);
        caracter=true;
        }catch(NumberFormatException e)
        {
            System.out.println("Te has equivocado, no has introducido un carácter.");
            System.out.println(" ");
            System.out.print("Vuelve a introducir un carácter: ");
        }
        }while (!caracter);
        
        return n;
    }
    
    public static String cadena(String mensaje)
    {
        Scanner teclado=new Scanner(System.in);
        String cadena="ERROR";
        System.out.print(mensaje);
        boolean frase=false;
        
        do
        {
        try
        {
        cadena=teclado.nextLine();
        frase=true;
        }catch(NumberFormatException e)
        {
            System.out.println("Te has equivocado, no has introducido una cadena de caracteres válidos.");
            System.out.println(" ");
            System.out.print("Vuelve a introducir una frase: ");
        }
        }while (!frase);
        
        return cadena;
    }
    
    public static int[] pedirFecha (String mensaje)
    {   
        System.out.println(mensaje);
        System.out.println(" ");
        int v[]=new int[3];
        v[0]=Pedir.entero("Dime el día: ");
        v[1]=Pedir.entero("Dime el número del mes: ");
        v[2]=Pedir.entero("Dime el año: ");
        
        return v;
    }
}
