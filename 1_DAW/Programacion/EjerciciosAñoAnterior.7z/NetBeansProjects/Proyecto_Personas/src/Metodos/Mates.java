package Metodos;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author nomat
 * MATES es una librería que contiene métodos o funciones matemáticas propias
 * Podemos llamarlo desde otras clases sin dificultad
 */
public class Mates {
    
    public static void multiplicar(int x){
        System.out.println("Tabla de multiplicar del "+x+": ");
        for (int i=1;i<=10;i++)
            System.out.print(x+" x "+i+" = "+(x*i)+"\n");
    }
    
    public static int mayor(int x,int y){
        int mayor;
        if(x>y) mayor=x;
        else mayor=y;
        return mayor;
    }
    
    public static int menor(int x,int y){
        int menor;
        if(x>y) menor=y;
        else menor=x;
        return menor;
    }
    
    public static double LongitudAreaCirculo(double r, char letra){
        double salida;
        if (letra=='a'||letra=='A')
        {
            salida=Math.PI*Math.pow(r,2);
        }
        else salida=2*Math.PI*r;
        return salida;
    }
    
    public static boolean esPar(int x)
    {
        return x%2==0;
    }
    
    public static double DistanciaEuclidea(int x1,int y1,int x2,int y2)
    {
        double distancia;
        distancia=Math.sqrt(Math.pow(x2-x1,2)+Math.pow(y2-y1,2));
        return distancia;
    }
    
    public static long Factorial(long numero)
    {
        long factorial=1;
        for(int i=1;i<=numero;i++)
            factorial*=i;
        return factorial;
    }
    
    public static int NumDivisores (int n)
    {
        int cont=0;
        for(int i=1;i<=n;i++)
        {
            if (n%i==0)
            {
                cont++;
            }
        }
        return cont;
    }
    
    public static int SumaDivisores (int n)
    {
        int suma=0;
        for(int i=1;i<=n;i++)
        {
            if (n%i==0)
            {
                suma+=i;
            }
        }
        return suma;
    }
    
    public static boolean NumPerfecto (int n)
    {
        int suma;
        suma=Mates.SumaDivisores(n);
        boolean perfecto=false;
        if ((suma-n)==n) perfecto=true;
        return perfecto;
    }
    
    public static boolean NumAmigos (int x, int y)
    {
        int sumax, sumay; boolean amigos;
        sumax=Mates.SumaDivisores(x);
        sumay=Mates.SumaDivisores(y);
        amigos=((sumax-x)==y && (sumay-y)==x);
        return amigos;
    }
    
    public static boolean NumPrimo1 (int n)
    {
        boolean NumPrimo; int cont;
        cont=Mates.NumDivisores(n);
        NumPrimo=(cont<=2);
        return NumPrimo;
    }
    
    public static boolean NumPrimo2 (int n) //Este no funciona bien aun!!!! 25 y 49?
    {
        boolean NumPrimo=true; int cont=0;
        for(int i=1;i<=n;i++)
        {
            if(n%i==0) cont++;
            if (cont>2) 
            {
                NumPrimo=false;
                break;
            }
        } 
        return NumPrimo;
    }
}
