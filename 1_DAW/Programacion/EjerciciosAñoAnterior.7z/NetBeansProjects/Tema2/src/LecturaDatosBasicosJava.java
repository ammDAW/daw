
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Profesor
 */
public class LecturaDatosBasicosJava {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner teclado=new Scanner(System.in);
        
        //Tipos enteros
        byte edad; //entre -128 y 127
        short anio; //entre -32.000 a 32.000
        int velocidadRayo;
        long distanciasPolosEnCms;
        int iMay; //contador del bucle para las letras del abecedario Mayúscula
        int iMn; // contador del bucle para las letras en minúsculas
        
        //Tipos reales (decimales)
        float nota; //Hasta 7 cifras decimales
        double areaCirculo; //Más de 7 cifras decimales o números enteros mayores que Long
        
        //Tipo carácter
        char letra;
        char caracter;
        
        caracter='A';
        
        //Tipo cadena
        String nombre;
        String cadena;
        /*
        //Leer un valor byte
        System.out.println("Dime tu edad: ");
        cadena=teclado.nextLine();
        edad=Byte.parseByte(cadena);
        
        //Leer un valor short
        System.out.println("Dime el año actual: ");
        cadena=teclado.nextLine();
        anio=Short.parseShort(cadena);
        
        //Leer un valor Int
        System.out.println("Dime la velocidad del Rayo de la tormenta de ayer en Canarias:  ");
        cadena=teclado.nextLine();
        velocidadRayo=Integer.parseInt(cadena);
 
        //Leer un valor long
        System.out.println("Dime la distancia en cms entre los 2 polos:  ");
        cadena=teclado.nextLine();
        distanciasPolosEnCms=Long.parseLong(cadena);
        
        //Leer un valor float (con decimales)
        System.out.println("Dime la nota:  ");
        cadena=teclado.nextLine();
        nota=Float.parseFloat(cadena);
        
        //Leer un valor double (el mayor en decimales)
        System.out.println("Dime el área del círculo:  ");
        cadena=teclado.nextLine();
        areaCirculo=Double.parseDouble(cadena);
        
        //Leer un carácter
        System.out.println("Dime una letra:  ");
        cadena=teclado.nextLine();
        letra=cadena.charAt(0);
        
        //Leer una cadena
        System.out.println("Dime tu nombre:  ");
        nombre=teclado.nextLine();
        
        //Mostrad por pantalla los valores introducidos
        System.out.println("La edad (byte) es "+edad);
        System.out.println("El año actual (short) es "+anio);
        System.out.println("Velocidad del rayo (int) es "+velocidadRayo);
        System.out.println("Distancia entre los polos es "+distanciasPolosEnCms);
        System.out.println("La nota (float) es "+nota);
        System.out.println("El área del círculo (double) es "+areaCirculo);
        System.out.println("La letra es (char) "+letra);
        System.out.println("Tu nombre es "+nombre);
     */
        //Secuencias de escape
        System.out.println("Mi nombre es Isabel \nProfe\tProgramación");
        
        System.out.println("   'a'    su valor en binario es "+((int)'a'));
        
        System.out.println("La letra :"+caracter+" se representa en binario: "+((int)caracter));
        
        System.out.println("Dime una letra:  ");
        cadena=teclado.nextLine();
        letra=cadena.charAt(0);
        System.out.println("La letra "+letra+" se almacena en binario "+((int)letra));
        
        System.out.println(((char)65));
        
        iMn=(int)'a'; //i=97;
        while (iMn<= 122) //while (i<= ((int)'z')
        {            
            System.out.print((char)iMn+"\t");
            if ((char)iMn=='n')
            {
                System.out.print("ñ\t");
            }
            iMn=iMn+1;
        }
        
        //Representación del abecedario español
        //Cada línea en una línea distinta
        //La primera letra en mayúsculas, después en minúsculas
        System.out.println("");
        System.out.println("");
        iMay=(int)'A'; //i=65;
        while (iMay<= 90) //while (iMay<= ((int)'Z')
        {            
            iMn=iMay+32;
            System.out.print((char)iMay+"\t"+(char)iMn+"\n");
            if ((char)iMay=='N')
            {
                System.out.print("Ñ\tñ\n");
            }
            
            iMay=iMay+1;
        }

        
        
    }
    
    
}
