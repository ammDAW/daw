
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Profesor
 */
public class Ejercicio4Pseudocodigo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //PROGRAMA: Cálculo del salario semanal de un trabajador
        // Es necesario saber su nombre, horas trabajadas y el precio por hora
        // Las horas extras se pagan a 1.5 el precio de la hora
        
        //ENTORNO
        //Variable: nombre cadena de caracteres
        String nombre;
        //Variable: horasTrabajadas real
        double horasTrabajadas;
        //Variable: precioHora real
        double precioHora;
        //Variable: cadena
        String cadena;
        //Variable: salarioBruto
        double salarioBruto;
        //Variable: salario
        double salario;
        
        //ALGORITMO
        Scanner teclado=new Scanner(System.in);
        
        System.out.println("Dime el nombre del trabajador: ");
        nombre=teclado.nextLine();
        
        System.out.println("Dime las horas trabajadas: ");
        cadena=teclado.nextLine();
        horasTrabajadas=Double.parseDouble(cadena);
        
        System.out.println("Dime el precio por hora: ");
        cadena=teclado.nextLine();
        precioHora=Double.parseDouble(cadena);
        
        if (horasTrabajadas <=40)
        {    
           salarioBruto=horasTrabajadas*precioHora;
           // System.out.println(horasTrabajadas*precioHora);
        }
        else
        {
            salarioBruto=40*precioHora + (horasTrabajadas - 40)*precioHora*1.5; ;
            //System.out.println((40*precioHora + (horasTrabajadas - 40)*precioHora*1.5));
        }
        
        
        //salario=salarioBruto*1 - salarioBruto*0.1;
        //salario=salarioBruto*(1-0.1);
        salario=salarioBruto*0.9;
        
        System.out.println("El salario de "+nombre+" es "+salario+"€");
        
        
        
        
        
    }
    
}
