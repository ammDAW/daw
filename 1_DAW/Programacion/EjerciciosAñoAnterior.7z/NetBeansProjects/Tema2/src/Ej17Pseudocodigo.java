
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Profesor
 */
public class Ej17Pseudocodigo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //Ejercicio 17 de la hoja de pseudocódigo
        
        double nota;
        int i; //variable del bucle, va desde 1 hasta 10 de 1 en 1
        int contAprobados;
        int contSuspensos;
        double porcentajeAprobados;
        String cadena;
        
        Scanner teclado=new Scanner(System.in);
        
        contAprobados=0;
        //contSuspensos=0;
        
        i=1;
        while(i<=10)  
        {
            System.out.print("Dime tu nota (alumno nº "+i+") :");
            cadena=teclado.nextLine();
            nota=Double.parseDouble(cadena);
              //Incluir el bucle para que la nota sea correcta 
            if (nota >=5)
            {
                contAprobados=contAprobados+1;
            }
            
            i=i+1;
        }
        
        System.out.println("Hay "+contAprobados+" alumnos aprobados");
        contSuspensos=10-contAprobados;
        System.out.println("Hay "+contSuspensos+" alumnos suspensos");
        porcentajeAprobados=(contAprobados*100)/10;
        System.out.println("El porcentaje de aprobados es "+porcentajeAprobados+"%");
        System.out.println("El porcentaje de suspensos es "+(100-porcentajeAprobados)+"%");
       // System.out.println("El porcentaje de suspensos es "+((contSuspensos*100)/10)+"%");
        
       
       
       //---------------------CON DO-WHILE----------------------
        i=1;
        do  
        {
            System.out.print("Dime tu nota (alumno nº "+i+") :");
            cadena=teclado.nextLine();
            nota=Double.parseDouble(cadena);
              //Incluir el bucle para que la nota sea correcta 
            if (nota >=5)
            {
                contAprobados=contAprobados+1;
            }
            
            i=i+1;
        }while(i<=10);
        
        //-----------------FOR-----------------------------
       //  i=1;
        for(i=1;i<=10;i=i+1)  
        {
            System.out.print("Dime tu nota (alumno nº "+i+") :");
            cadena=teclado.nextLine();
            nota=Double.parseDouble(cadena);
              //Incluir el bucle para que la nota sea correcta 
            if (nota >=5)
            {
                contAprobados=contAprobados+1;
            }
            
            //i=i+1;
        }
       
        
    }
    
}
