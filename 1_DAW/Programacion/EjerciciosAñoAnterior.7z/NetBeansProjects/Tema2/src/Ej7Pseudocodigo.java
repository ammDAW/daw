
import java.util.Scanner;


public class Ej7Pseudocodigo {

    
    public static void main(String[] args) {
      int hora;
      int min;
      int sg;
      String cadena;
      
      Scanner teclado=new Scanner(System.in);
      
        System.out.print("Dime la hora: ");
        cadena=teclado.nextLine();
        hora=Integer.parseInt(cadena);
        
        while (hora<0 || hora>23)// Correcta: hora>=0 && hora<=23
        {
            System.out.println("Introduce de nuevo la hora porque es incorrecta");
            System.out.print("Dime la hora: ");
            cadena=teclado.nextLine();
            hora=Integer.parseInt(cadena);
        }    
        
        System.out.print("Dime los minutos: ");
        cadena=teclado.nextLine();
        min=Integer.parseInt(cadena);
        
        while (min<0 || min>59)// Correcta: min>=0 && min<=59
        {
            System.out.println("Introduce de nuevo los minutos porque son incorrectos");
            System.out.print("Dime los minutos: ");
            cadena=teclado.nextLine();
            min=Integer.parseInt(cadena);
        }
        
        
        System.out.print("Dime los segundos: ");
        cadena=teclado.nextLine();
        sg=Integer.parseInt(cadena);
        
        while (sg<0 || sg>59)// Correcta: sg>=0 && sg<=59
        {
            System.out.println("Introduce de nuevo los segundos porque son incorrectos");
            System.out.print("Dime los segundos: ");
            cadena=teclado.nextLine();
            sg=Integer.parseInt(cadena);
        }
        
        
       // if ((hora>=0 && hora<=23)  && (min>=0 && min<=59)  && (sg>=0 && sg<=59))
        //{            
         System.out.println("Hora actual -> "+hora+":"+min+":"+sg);
        
         sg=sg+1;
         if (sg==60)
         {
            sg=0;
            min=min+1;
            if (min==60)
            {
               min=0;
               hora=hora+1;
               if (hora==24)
               {
                   hora=0;
               }
            }
         }
               
         System.out.println("Un segundo más: "+hora+":"+min+":"+sg);
       //  }
       // else
       // {
         //   System.out.println("Error, la hora introducida es incorrecta");
        //}
      
    }
    
}
