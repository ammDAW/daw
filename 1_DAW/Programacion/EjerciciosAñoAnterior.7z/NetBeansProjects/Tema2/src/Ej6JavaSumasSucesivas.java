
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Profesor
 */
public class Ej6JavaSumasSucesivas {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //Introducir x e y por teclado
        //Calcula el resultado de x*y 
        //Utiliza el método de las sumas sucesivas
        //Suma el valor de X tantas veces como sea Y
        
        Scanner teclado=new Scanner(System.in);
        int x, y, suma=0;
        String cadena;
        
        System.out.print("Dime el valor de x :");
        cadena=teclado.nextLine();
        x=Integer.parseInt(cadena);
        
        System.out.print("Dime el valor de y :");
        cadena=teclado.nextLine();
        y=Integer.parseInt(cadena);
        
        int i=1;
        while (i<=3)
        {
            suma+=4;
            i++;
        }
        System.out.println("4 x 3 ="+suma);
    }
    
}
