
import java.util.Scanner;


/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Profesor
 */
public class EjMeses {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int mes1; //Primer mes
        int mes2; //Segundo mes
        String cadena;
        int mes; //contador del bucle desde x a y
        int sumaDias;
        String nombreMes1;
        String nombreMes2;
        int anio; 
        
        Scanner teclado=new Scanner(System.in);
      
        nombreMes1="";
        nombreMes2="";

        System.out.print("Dime el valor del año: ");
        cadena=teclado.nextLine();
        anio=Integer.parseInt(cadena);
        
        System.out.print("Dime el valor del primer mes: ");
        cadena=teclado.nextLine();
        mes1=Integer.parseInt(cadena);
        
        while (mes1<1 || mes1>12)
        {
            System.out.println("Error, el mes es incorrecto, vuelve a introducirlo ...");
            System.out.print("Dime el valor del primer mes: ");
            cadena=teclado.nextLine();
            mes1=Integer.parseInt(cadena);
        }
        
        System.out.print("Dime el valor del segundo mes: ");
        cadena=teclado.nextLine();
        mes2=Integer.parseInt(cadena);
        
        while (mes2<1 || mes2>12)
        {
            System.out.println("Error, el mes es incorrecto, vuelve a introducirlo ...");
            System.out.print("Dime el valor del segundo mes: ");
            cadena=teclado.nextLine();
            mes2=Integer.parseInt(cadena);
        }
        
        
        if (mes1 <= mes2)
        {
            sumaDias=0;
            mes=mes1;
            while (mes <= mes2)
            {
                switch(mes)
                {
                    case 1: sumaDias=sumaDias + 31; break;
                    case 2: if ((anio % 4 == 0) && ((anio % 100 != 0) || (anio % 400 == 0)))
                            {
                               sumaDias=sumaDias + 29;
                            }
                            else
                            {
                               sumaDias=sumaDias + 28;
                            }
                            break;
                    case 3: sumaDias=sumaDias + 31; break;
                    case 4: sumaDias=sumaDias + 30; break;  
                    case 5: sumaDias=sumaDias + 31; break;
                    case 6: sumaDias=sumaDias + 30; break;
                    case 7: sumaDias=sumaDias + 31; break;
                    case 8: sumaDias=sumaDias + 31; break;
                    case 9: sumaDias=sumaDias + 30; break;
                    case 10: sumaDias=sumaDias + 31; break;
                    case 11: sumaDias=sumaDias + 30; break;
                    case 12: sumaDias=sumaDias + 31;                            
                }
                mes= mes +1;
            }
            
            switch(mes1)
            {
                case 1: nombreMes1="Enero";break;
                case 2: nombreMes1="Febrero";break;
                case 3: nombreMes1="Marzo";break;
                case 4: nombreMes1="Abril";break;
                case 5: nombreMes1="Mayo";break;
                case 6: nombreMes1="Junio";break;
                case 7: nombreMes1="Julio";break;
                case 8: nombreMes1="Agosto";break;
                case 9: nombreMes1="Septiembre";break;
                case 10: nombreMes1="Octubre";break;
                case 11: nombreMes1="Noviembre";break;
                case 12: nombreMes1="Diciembre";
            }
        
            switch(mes2)
            {
                case 1: nombreMes2="Enero";break;
                case 2: nombreMes2="Febrero";break;
                case 3: nombreMes2="Marzo";break;
                case 4: nombreMes2="Abril";break;
                case 5: nombreMes2="Mayo";break;
                case 6: nombreMes2="Junio";break;
                case 7: nombreMes2="Julio";break;
                case 8: nombreMes2="Agosto";break;
                case 9: nombreMes2="Septiembre";break;
                case 10: nombreMes2="Octubre";break;
                case 11: nombreMes2="Noviembre";break;
                case 12: nombreMes2="Diciembre";
            }

            System.out.println("Hay "+sumaDias+" días entre los meses "+nombreMes1+" y "+nombreMes2);
        }
        else
        {
            System.out.println("Error, el primer mes "+mes1+" es mayor que el segundo "+mes2+" del año "+anio);
        }
        
        //Comprobar si un año es bisiesto, se utiliza la variable anio
        //Este código sobra en el ejercicio
        if ((anio % 4 == 0) && ((anio % 100 != 0) || (anio % 400 == 0)))
        {
            System.out.println(anio+ " es bisiesto");
        }
        else
        {
            System.out.println(anio+ " no es bisiesto");
        }
    }
    
}
 