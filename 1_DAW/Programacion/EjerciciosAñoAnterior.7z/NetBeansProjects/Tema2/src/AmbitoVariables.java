/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Profesor
 */
public class AmbitoVariables {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int x=9;
        if (x==9)
        {
            int y=10;
            System.out.println("El valor de x es "+x+" y el de y "+y);
        }
        
        int z=x+1;
        System.out.println("El valor de z es "+z);
        //System.out.println(y); No conoce y
        
        
        float f=3.0f;
        int p=(int)f;
        System.out.println(p);
        
        double d=98.999999999999999999999;
        float g=(float)d;
        System.out.println(g);
    }
    
}
