
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Profesor
 */
public class Ej19Pseudocodigo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //PROGRAMA: TERRA MÍTICA CON RECAUDACIÓN
        
        int contPersonas;
        int cont4;
        int cont4_12;
        int contAdultos;
        int cashInfantil;
        int cashAdultos;
        int cashTotal;
        int edad;
        String cadena;
        
        //ALGORITMO
        Scanner teclado=new Scanner(System.in);
        
        cont4=0;
        cont4_12=0;
        contAdultos=0;
        contPersonas=0;
        
        cashInfantil=0;
        cashAdultos=0;
        
        
        //DISEÑO CON while(condicion_permanencia)
        System.out.println("Dime tu edad:");
        cadena=teclado.nextLine();
        edad=Integer.parseInt(cadena);
        
        while (edad >=0)
        {
            contPersonas=contPersonas +1;
            
            if (edad<4)
            {
                cont4= cont4 +1;
            }
            else
            {
                if (edad < 12)
                {
                    cont4_12=cont4_12 +1;
                    cashInfantil=cashInfantil + 20;                    
                }
                else
                {
                    contAdultos= contAdultos+1;
                    cashAdultos=cashAdultos + 40;                    
                }
            }           
                       
            
            System.out.println("Dime tu edad:");
            cadena=teclado.nextLine();
            edad=Integer.parseInt(cadena);            
        }
        
        
        //contPersonas=cont4+cont4_12+contAdultos;
        System.out.println("En Terra Mítica han entrado "+contPersonas+" personas");
        System.out.println("De las cuales, hay "+cont4+" bebés");
        System.out.println(cont4_12+" infantiles");
        System.out.println(contAdultos+" adultos");
        
        /*
          Otra forma de hacerlo,
          cashInfantil=cont4_12 *20;
          cashAdultos=contAdultos*40;
          cashTotal=cashInfantil + cashAdultos; 
        */
        cashTotal=cashInfantil + cashAdultos;
        System.out.println("La recaudación total es "+cashTotal+"€");
        System.out.println("La recaudación infantil es: "+cashInfantil+"€");
        System.out.println("La recaudación adultos es: "+cashAdultos+"€");
    }
    
}
