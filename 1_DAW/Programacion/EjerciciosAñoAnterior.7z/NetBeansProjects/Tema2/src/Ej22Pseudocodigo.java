/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Profesor
 */
public class Ej22Pseudocodigo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //Suma de los 10 primeros números enteros
        int i; //contador del bucle, va desde 1 hasta 10 de 1 en 1
        int suma; //variable que acumula el valor de la suma 
        
        
        suma=0;
        i=1;
        while (i<=10)//do
        {
            suma=suma+i;
            i=i+1;
        }//while(i<=10);
        System.out.println("La suma total es "+suma);
        
        
        suma=0;
        for(i=1; i<=10; i=i+1)
        {
            suma=suma+i;
        }
        System.out.println("La suma total es "+suma);
        
    }
    
}
