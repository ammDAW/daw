/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Profesor
 */
public class ContParesSumaImpares {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int i; //contador del bucle, va desde 50 hasta 75, de 1 en 1
        int sumaImpares; //suma de los impares
        int contPares; //contador de los pares
        
        
        sumaImpares=0;
        contPares=0;
        
        i=50;
        while (i<=75)
        {
            if (i%2==0) //significa que i es par
            {
                contPares=contPares+1;
            }
            else
            {
                sumaImpares=sumaImpares+i;
            }
            
            i=i+1;
        }
        
         //if (i%2 != 0)  // if (!(i%2==0)) // if (i%2==1) significa que i es impar  
        System.out.println("La suma de los impares es "+sumaImpares+" y hay "+contPares+" pares desde 50 hasta 75");
         
    }
    
}
