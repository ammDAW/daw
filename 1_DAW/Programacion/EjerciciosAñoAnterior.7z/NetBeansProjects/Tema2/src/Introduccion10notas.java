
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Profesor
 */
public class Introduccion10notas {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //PROGRAMA: Introducir 10 notas por teclado
        
        //ENTORNO:
        //Variable: nota real
        double nota;
        //Variable: i contador del bucle
        int i;
        //Variable: cadena String
        String cadena;
        
        //ALGORITMO
        Scanner teclado=new Scanner(System.in);
        
        for (i=1;i<=10;i=i+1)
        {    
         System.out.print("Dime el valor de la nota: ");
         cadena=teclado.nextLine();
         nota=Double.parseDouble(cadena);
         
         while(nota<0 || nota>10)
         {
             System.out.println("Error, nota introducida de forma incorrecta, vuelve a introducirla ...");    
             System.out.print("Dime el valor de la nota: ");
             cadena=teclado.nextLine();
             nota=Double.parseDouble(cadena);     
         }         
        } 
    }
    
}
