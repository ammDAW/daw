
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Profesor
 */
public class Operadores {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //Operadores aritméticos unarios ++ --
        int x=2;
        x++; 
        System.out.println("x ="+x);//muestra 3
        
        --x;
        System.out.println("x = "+x);//muestra 2
        
        int y=5;
        System.out.println("y = "+ y++);//muestra 5 y=6
        System.out.println("y = "+y); //muestra 6
        
        int z=--y; //--y; //y=5    
                   // z=y;  z=5
        System.out.println("z= "+z+" y= "+y); // z=5 y=5
        
        //Operadores de asignación
        int a=2;
        a+=5;//a=a+5; a=7
        System.out.println("a= "+a); //muestra 7
        
        int b=9;
        b*=1;// b=b*1;
        System.out.println("b= "+b);
        
        
        
        
        //Bloques de código y variables declaradas en bloques de código
        if (a==7){
            int d=9;
            d-=a;//d=d-a; d=9-7=2
            System.out.println("d= "+d);//muestra 2
            y=6;            
        }
        
       // System.out.println("d= "+d); Error d nace y muere dentro del código del if
       
       //Combinación de operadores de asignación con los unarios
       int c=7,d=2;
       c+=5+ d++; //c=c + (5+ d++);
                  // 1. c=c+(5+d);  c=7+(5+2)=14
                  // 2. d++; d=d+1; d=3;
                  
       //Operador ternario
       //c=14, d=3
       //Mostrad por pantalla el menor de c y d
       int menor;
       if (c<d){
           menor=c;
       }
       else
       {
           menor=d;
       }
       System.out.println("El menor es "+menor);
       //Ahora utilizamos el operador ternario
       menor=(c<d)?c:d;
       System.out.println("El menor es "+menor);
       
       
       System.out.println("El menor es "+((c<d)?c:d));
       //Introducir la nota de un alumno, nos dirá si está aprobado o suspenso
       Scanner teclado=new Scanner(System.in);
       String cadena;
       int nota;
       
        System.out.print("Dime tu nota: ");
        cadena=teclado.nextLine();
        nota=Integer.parseInt(cadena);
        
        if (nota>=5){
            System.out.println("Estás aprobado");
        }
        else{
            System.out.println("Estás suspenso");
        }
        
        System.out.println((nota>=5)?"Estás aprobado":"Estás suspenso");
        System.out.println("Estás "+((nota>=5)?"aprobado":"suspenso"));
        
        String varAuxiliar;
        varAuxiliar=(nota>=5)?"aprobado":"suspenso";
        System.out.println("Estás "+varAuxiliar);
        
        //Introduce un número por teclado, indica si es par o impar
        int num;
        System.out.print("Dime un número: ");
        cadena=teclado.nextLine();
        num=Integer.parseInt(cadena);
        
        System.out.println((num%2==0)?"par":"impar");
        System.out.println(num+ " es "+((num%2==0)?"par":"impar"));
        
        varAuxiliar=(num%2==0)?"par":"impar";
        System.out.println(num +" es "+varAuxiliar);
        
       //Asignación múltiple
       int k,i,j;
       k=i=j=20;
       
        System.out.println("k= "+k+" i= "+i+" j= "+j);
        
        //Intercambio del valor de 2 variables
        j=90;
        i=23;
        //Objetivo: j tome el valor 23, i tome el valor 90
        int aux;
            aux=i; //aux=23, i=23
            i=j; //i=90, j=90
            j=aux; //j=23, aux=23
        System.out.println("i ="+i+" j= "+j);    
            
        // Dividir 2 números enteros
        i=8;
        j=3;
        System.out.println(i/j); //2 
        System.out.println((float)(i/j)); //2 
        System.out.println( ((float)i) / ((float)j) ); 
        
        
        float f=(float)i; //f=8.0
        
        
        
       
    }
    
}
