
import java.util.Scanner;


public class DiasSemanaAlternativaMultiple {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       //ENTORNO
       //Variable: n numérico entero
       int n;
       //Variable: cadena String
       String cadena;
       
       //ALGORITMO
       Scanner teclado=new Scanner(System.in);
       
       System.out.println("Dime un número y te diré el nombre del día de la semana: ");
       cadena=teclado.nextLine();
       n=Integer.parseInt(cadena);
       
       if (n>=1 && n<=7) 
       {
           if (n==1)
           {
               System.out.println("Lunes"); 
           }
           else
           {
             if (n==2)
             {
                 System.out.println("Martes");
             }
             else
             {
                 if (n==3)
                 {
                     System.out.println("Miércoles");
                 }
                 else
                 {
                  if (n==4)
                  {
                      System.out.println("Jueves");
                  }
                  else
                  {
                      if (n==5)
                      {
                          System.out.println("Viernes");
                      }
                      else
                      {
                          if (n==6)
                          {
                              System.out.println("Sábado");
                          }
                          else
                          {
                              System.out.println("Domingo");
                          }
                      }
                    }
                 }
             }
           }            
       }
       else
       {
           System.out.println("El número "+n+" no es válido");
       }
    }
    
}
