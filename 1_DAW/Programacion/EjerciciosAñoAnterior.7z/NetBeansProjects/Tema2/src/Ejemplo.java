
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Profesor
 */
public class Ejemplo {

    
    public static void main(String[] args) {
          
        //Ayer estuve enferma
        
        /*
        Esto es un comentario que 
        ocupa varias líneas
        Está delimitado y no se ejecuta
        Tiene carácter informativo
        */
        
        Scanner teclado=new Scanner(System.in);
        // Variable edad numérica entera
        int edad;
        //Variable cadena de tipo String (cadena de caracteres)
        String cadena;
        
        
        System.out.println("Dime la edad de Diana: ");
        //Se guarda en la variable cadena lo que se introduzca por teclado en una línea
        cadena=teclado.nextLine();
        //la cadena se transforma en un número entero y se guarda en edad
        edad=Integer.parseInt(cadena);
        
        
        
        
        /*Asignación
        edad=19;
        */
        
        //Órdenes de Escribir
        System.out.println("Voy a mostrar por pantalla el doble de 200 ");
        System.out.println(2*200);
        System.out.println("Mi nombre es "+"Paco Pepe "+"y tengo "+18+" años");
        
        System.out.println("Diana tiene "+ edad +" años");
       //18 System.out.println("Diana tiene "+"edad"+" años");
        
     
        
        
    }
    
}
