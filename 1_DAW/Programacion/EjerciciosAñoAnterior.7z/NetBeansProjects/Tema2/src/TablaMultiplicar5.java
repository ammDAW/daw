/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Profesor
 */
public class TablaMultiplicar5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //PROGRAMA: Tabla de multiplicar del 5
        //ENTORNO:
        //Variable: i entera del bucle
        int i;
        
        //ALGORITMO
        System.out.println("TABLA DE MULTIPLICAR DEL 5");
        i=1;
        while (i<=10)
        {
            System.out.println("5 x "+i+" = "+(5*i));
            i=i+1;
        }
        
        System.out.println("TABLA DE MULTIPLICAR DEL 5 con do-while");
        i=1;
        do
        {
            System.out.println("5 x "+i+" = "+(5*i));
            i=i+1;
        }while(i<=10);
        
    }
    
}
