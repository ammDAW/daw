/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Profesor
 */
public class Ej12Pseudocodigo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int i;
        
        System.out.println("Los 5 primeros números naturales son: ");
        i=0;
        while(i<=4)
        {
            System.out.println(i);
            i=i+1;
        }
        
        System.out.println("FIN");
        
        System.out.println("Los números enteros entre 10 y 20: ");
        i=10;
        while(i<=20)
        {
            System.out.println(i);
            i=i+1;
        }
        
        System.out.println("FIN");

       System.out.println("Los números pares enteros entre 10 y 20: ");
        i=10;
        while(i<=20)
        {
            System.out.println(i);
            i=i+2;
        }
        
        System.out.println("FIN");
 
        System.out.println("Los números enteros entre 20 y 10: ");
        i=20;
        while(i>=10)
        {
            System.out.println(i);
            i=i-1;
        }
        
        System.out.println("FIN");        
    }
    
}
