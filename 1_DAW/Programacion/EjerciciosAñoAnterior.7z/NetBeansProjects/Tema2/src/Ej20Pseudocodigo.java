
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Profesor
 */
public class Ej20Pseudocodigo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //PROGRAMA: Introducid por teclado la nota de 15 alumnos.
        //          Indicad cúantos aprobados hay, cuántos suspensos y la media de sus notas
        
        //ENTORNO
        double nota;
        int contAprobados;
        int contSuspensos;
        String cadena;
        double suma;
        double media;
        int i; //contador del bucle de introducir notas, va de 1 a 15 de 1 en 1
        
        //ALGORITMO
        Scanner teclado=new Scanner(System.in);
        
        contAprobados=0;
        contSuspensos=0;
        suma=0;
        
        i=1;
        while (i <=15)
        {
            System.out.println("Dime la nota nº "+i);
            cadena=teclado.nextLine();
            nota=Double.parseDouble(cadena);
            
            if (nota <5)
            {
                contSuspensos=contSuspensos+1;
            }
            
            suma=suma+nota; //suma acumula la suma de las notas
            i=i+1;
        }
       
        contAprobados=15 - contSuspensos;
        media=suma/15;
        System.out.println("De 15 alumnos, hay "+contSuspensos+" suspensos y "+contAprobados+" aprobados");
        System.out.println("La media es: "+media);
        
    }
    
}
