
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Profesor
 */
public class IntroducirNotaCorrecta {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       //PROGRAMA: Dime la nota de un alumno
       //Esa nota debe ser correcta: comprendida entre 0 y 10 (incluídos)
       
       //ENTORNO
       //Variable: nota entera
       int nota;
       //Variable: cadena String
       String cadena;
       
       //ALGORITMO
       Scanner teclado=new Scanner(System.in);
       
      /* con while
             
        System.out.print("Dime tu nota: ");
        cadena=teclado.nextLine();
        nota=Integer.parseInt(cadena);
                        
        while (nota <0 || nota>10)  // !(nota>=0 && nota<=10)
        {
            System.out.print("Dime tu nota: ");
            cadena=teclado.nextLine();
            nota=Integer.parseInt(cadena);
        }
        
        
        System.out.println("Tu nota es: "+nota );
       */
      
      //Con do-while
       do{       
            System.out.print("Dime tu nota: ");
            cadena=teclado.nextLine();
            nota=Integer.parseInt(cadena);
        }while ( !(nota>=0 && nota<=10) );
        
        
        System.out.println("Tu nota es: "+nota );
    }
    
}
