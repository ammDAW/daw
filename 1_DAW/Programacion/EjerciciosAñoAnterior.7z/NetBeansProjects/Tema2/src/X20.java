
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Profesor
 */
public class X20 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //PROGRAMA: Dime un número entero x
        //Si ese número es menor que 20
        //   Muestra los valores entre x y 20
        //Si no
        //   Muestra "Error"
       
       //ENTORNO
       //Variable: x entera
       int x;
       //Variable i del bucle
       int i;
       //Variable: cadena String
       String cadena;
       
       //ALGORITMO
       Scanner teclado=new Scanner(System.in);
       
        System.out.print("Dime el valor del primer número: ");
        cadena=teclado.nextLine();
        x=Integer.parseInt(cadena);
        
        if (x <= 50)
        {
            for(i=x;i<=50;i=i+1)
            {
                System.out.println(i);
            }
        }
        else
        {
            System.out.println("Error");
        }
       
    }
    
}
