
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Profesor
 */
public class CalculoIMC4Alternativas {

    
    public static void main(String[] args) {
     //ENTORNO
     //Variable peso numérica real
     double peso;
     //Variable: altura numérica real
     double altura;
     //imc numérico real  --> Dato de salida
     double imc;
     //Variable cadena - me ayuda a introducir los datos por teclado
     String cadena;
     
     //ALGORITMO
     //Es una instrucción para indicar que se van a leer
     // datos por teclado
     Scanner teclado=new Scanner(System.in);
     
     System.out.print("Dime cuánto pesas: ");
     cadena=teclado.nextLine();
     peso=Double.parseDouble(cadena);
     
     System.out.print("Dime cuánto mides: ");
     cadena=teclado.nextLine();
     altura=Double.parseDouble(cadena);
     
     imc=peso/(altura*altura);
     //También imc=peso/Math.pow(altura,2);
     
     System.out.println("Tu índice de masa corporal es "+imc);

     if (imc<18.5)
     {
         System.out.println("Peso inferior al normal");
     }
     else
     {
         if (imc < 25)
         {
             System.out.println("Peso normal");
         }
         else
         { 
             if (imc < 30)
             {
               System.out.println("Peso superior al normal");    
             }    
             else
             {
                 System.out.println("Obesidad");
             }
         }    
     }    
     
     
     
     
    }
}
