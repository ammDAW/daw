/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Profesor
 */
public class Multiplos3DoWhile {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //PROGRAMA: Muestra por pantalla los múltiplos de 3 entre 9 y 18
        
        //ENTORNO
        //Variable: i entera, del bucle
        int i;
        
        //ALGORITMO
        //i=9
        //Mientras i<=18
        //      muestra i
        //      i=i+3
        // FinMientras  
        
        i=9;
        while(i<=18){
            System.out.println(i);
            i=i+3;
        }
        
        System.out.println("Usando do-while");
        i=9;
        do{
            System.out.println(i);
            i=i+3; 
        }while (i<=18);
        
        
        
    }
    
}
