
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Profesor
 */
public class Mult5y7 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int x;
        int y;
        String cadena;
        int i; //contador del bucle desde x a y
        int contMult5;
        
        Scanner teclado=new Scanner(System.in);
      
        System.out.print("Dime el valor de x: ");
        cadena=teclado.nextLine();
        x=Integer.parseInt(cadena);
        
        System.out.print("Dime el valor de y: ");
        cadena=teclado.nextLine();
        y=Integer.parseInt(cadena);
        
        /*
        if (x<=y)
        {
            contMult5=0;
            i=x;
            while(i<=y)// do
            {
                if (i%7==0)
                {
                    System.out.println(i+" es múltiplo de 7");
                }
                if (i%5==0)
                {
                    contMult5=contMult5 +1;
                }
                i=i+1;
            }// while (i<=y);
            System.out.println("Hay "+contMult5+" múltiplos de 5");
        }
        else
        {
            System.out.println("Error, el primer valor es mayor que el segundo");
        }
        */
        
        //Con for
        if (x<=y)
        {
            contMult5=0;
            
            for(i=x;i<=y;i=i+1)
            {
                if (i%7==0)
                {
                    System.out.println(i+" es múltiplo de 7");
                }
                if (i%5==0)
                {
                    contMult5=contMult5 +1;
                }               
            }
            System.out.println("Hay "+contMult5+" múltiplos de 5");
        }
        else
        {
            System.out.println("Error, el primer valor es mayor que el segundo");
        }

    }
    
}
