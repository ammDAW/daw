
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Profesor
 */
public class NotaSwitch {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //PROGRAMA : Introduce un número entero y te diré la nota 
        //ENTORNO
        //Variable: n numérica entera
        int n;
        //Variable: cadena String
        String cadena;
        
        //ALGORITMO
        Scanner teclado=new Scanner(System.in);
        
        System.out.print("Dime un número y te diré la nota: ");
        cadena=teclado.nextLine();
        n=Integer.parseInt(cadena);
        
        //Usando default
        /*
        switch(n)
        {
            case 0: 
            case 1:  
            case 2: System.out.println("MD");break;
            case 3: 
            case 4: System.out.println("INSF"); break;
            case 5: System.out.println("SF"); break;
            case 6: System.out.println("B"); break;
            case 7: 
            case 8: System.out.println("NT");break;
            case 9: 
            case 10: System.out.println("SB"); break;
            default: System.out.println("Error, número incorrecto");
        }
        */
        if (n>=0 && n<=10)
        {    
         switch(n)
         {
            case 0: 
            case 1: 
            case 2: System.out.println("MD"); break;
            case 3: 
            case 4: System.out.println("INSF"); break;
            case 5: System.out.println("SF"); break;
            case 6: System.out.println("B"); break;
            case 7: 
            case 8:System.out.println("NT"); break;
            case 9:
            default:System.out.println("SB"); 
         }
        }
        else
        {
            System.out.println("Error, número incorrecto");
        }

        System.out.println("FIN");
    }
    
}
