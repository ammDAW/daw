
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Profesor
 */
public class XYMostrarDesdeXhastaY {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //PROGRAMA: Introducid 2 números enteros por teclado
        //Si el primer es menor que el segundo
        //    Mostrar los valores comprendidos entre el primer el valor y el segundo, incluídos
        //Si no
        //    Muestra error
        
        //ENTORNO
        //Variable x, y números enteros
        int x;
        int y;
        //Variable: i es la variable que se usa en el bucle
        int i;
        //Variable: cadena String
        String cadena;
        
        
        //ALGORITMO
        Scanner teclado=new Scanner(System.in);
        
        System.out.print("Dime el primer número: ");
        cadena=teclado.nextLine();
        x=Integer.parseInt(cadena);
        
        System.out.print("Dime el segundo número: ");
        cadena=teclado.nextLine();
        y=Integer.parseInt(cadena);
        
        
        if (x < y)
        {
            
            i=x;
            while(i<=y)
            {
                System.out.println(i);
                i=i+1;
            }
            
        }
        else
        {
            System.out.println("Error, el primer número NO es menor del segundo");
        }
    }
    
}
