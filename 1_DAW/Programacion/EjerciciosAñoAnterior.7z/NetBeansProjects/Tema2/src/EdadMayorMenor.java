
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Profesor
 */
public class EdadMayorMenor {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //ENTORNO
        //Variable: edad numérico entero
        int edad;
        //Variable: cadena String
        String cadena;
        
        //ALGORITMO
        Scanner teclado=new Scanner(System.in);
        
        System.out.print("Dime tu edad: ");
        cadena=teclado.nextLine();
        edad=Integer.parseInt(cadena);
        
        if (edad>=18)
        {
            System.out.println("Eres Mayor de Edad");
        }        
        else
        {
            System.out.println("Eres Menor de Edad");
        }    
        
        
    }
    
}
