
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Profesor
 */
public class Ejercicio10Pseudocodigo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //PROGRAMA : Introduce un número entero y te diré el nombre de la semana 
        //ENTORNO
        //Variable: n numérica entera
        int n;
        //Variable: cadena String
        String cadena;
        
        //ALGORITMO
        Scanner teclado=new Scanner(System.in);
        
        System.out.print("Dime un número y te digo el nombre del día de la semana: ");
        cadena=teclado.nextLine();
        n=Integer.parseInt(cadena);
        
        //Usando default
        /*
        switch(n)
        {
            case 1: System.out.println("Lunes"); break;
            case 2: System.out.println("Martes"); break;
            case 3: System.out.println("Miércoles"); break;
            case 4: System.out.println("Jueves"); break;
            case 5: System.out.println("Viernes"); break;
            case 6: System.out.println("Sábado"); break;
            case 7: System.out.println("Domingo"); break;
            default: System.out.println("Error, número incorrecto");
        }
        */
        if (n>=1 && n<=7)
        {    
         switch(n)
         {
            case 1: System.out.println("Lunes"); break;
            case 2: System.out.println("Martes"); break;
            case 3: System.out.println("Miércoles"); break;
            case 4: System.out.println("Jueves"); break;
            case 5: System.out.println("Viernes"); break;
            case 6: System.out.println("Sábado"); break;
            case 7: System.out.println("Domingo");          
         }
        }
        else
        {
            System.out.println("Error, número incorrecto");
        }
        System.out.println("FIN");
    }
    
}
