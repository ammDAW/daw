
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Profesor
 */
public class Ej24Pseudocodigo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //PROGRAMA: Introducid una secuencia de notas por teclado
        //          La secuencia acaba cuando la nota es -1
        //          Se desea saber el número de notas introducidas y si al menos hay un 10
        
        //ENTORNO
        boolean hayDiez;
        int nota;
        int contNotas;
        String cadena;
        
        //ALGORITMO
        Scanner teclado=new Scanner (System.in);
        
        /* Con While
        contNotas=0;
        hayDiez=false;
        
        System.out.println("Dime tu nota: ");
        cadena=teclado.nextLine();
        nota=Integer.parseInt(cadena);
        
        while(nota!=-1){
            contNotas=contNotas +1;
            if (nota==10){
                hayDiez=true;
            }
                        
            System.out.println("Dime tu nota: ");
            cadena=teclado.nextLine();
            nota=Integer.parseInt(cadena);            
        }
        
        System.out.println("Se han introducido las notas de "+contNotas+" alumnos");
        if (hayDiez==true)// if (hayDiez)
        {
            System.out.println("Existe al menos un 10");
        }
        else
        {
            System.out.println("No hay dieces");
        }
            
        /*
          if (hayDiez==false)// otra forma if (!hay2Diez)
          {
             sout("No hay 10");
          }        
        else { sout("Hay al menos un 10");} 
        
        */
                
        //CON DO-WHILE
        /*
        contNotas=0;
        hayDiez=false;
        
        do{            
            System.out.println("Dime tu nota: ");
            cadena=teclado.nextLine();
            nota=Integer.parseInt(cadena);  
            
            if (nota!=-1){
                contNotas=contNotas+1;
                if (nota==10)
                {
                    hayDiez=true;
                }
            }
        }while(nota!=-1);
        
        System.out.println("Se han introducido las notas de "+contNotas+" alumnos");
        if (hayDiez==true)// if (hayDiez)
        {
            System.out.println("Existe al menos un 10");
        }
        else
        {
            System.out.println("No hay dieces");
        }
    */
        
        contNotas=0;
        hayDiez=false;
        
        do{            
            System.out.println("Dime tu nota: ");
            cadena=teclado.nextLine();
            nota=Integer.parseInt(cadena);  
            
            if (nota==-1){ break;}
            
            contNotas=contNotas+1;
            if (nota==10)
            {
                   hayDiez=true;
            }
            
        }while(nota!=-1);
        
        System.out.println("Se han introducido las notas de "+contNotas+" alumnos");
        if (hayDiez==true)// if (hayDiez)
        {
            System.out.println("Existe al menos un 10");
        }
        else
        {
            System.out.println("No hay dieces");
        }
 
        
    }
    
}
