
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Profesor
 */
public class ContadorMultiplos3EntreXY {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int x;
        int y;
        String cadena;
        int i; //contador del bucle desde x a y
        int contMult3;
        
        Scanner teclado=new Scanner(System.in);
      
        System.out.print("Dime el valor de x: ");
        cadena=teclado.nextLine();
        x=Integer.parseInt(cadena);
        
        System.out.print("Dime el valor de y: ");
        cadena=teclado.nextLine();
        y=Integer.parseInt(cadena);
        
        while ( !(x<=y) ) //Correcto: x <= y // Incorrecto: NO (x<=y)// Incorrecto: x > y
        {
            System.out.println("Introduce de nuevo y porque es menor que x");
            System.out.print("Dime el valor de y: ");
            cadena=teclado.nextLine();
            y=Integer.parseInt(cadena);
        }
        /*
        contMult3=0;
        i=x;
        while (i<=y)
        {
            if (i%3==0)
            {
                System.out.println(i +" es múltiplo de 3");
                contMult3=contMult3+1;
            }
            i=i+1;
        }
        
        System.out.println("Entre "+x+" y "+y+" hay "+contMult3+" múltiplos de 3");
       */
        contMult3=0;
        i=x;
        do
        {
            if (i%3==0)
            {
                System.out.println(i +" es múltiplo de 3");
                contMult3=contMult3+1;
            }
            i=i+1;
        } while (i<=y);
        
        System.out.println("Entre "+x+" y "+y+" hay "+contMult3+" múltiplos de 3");
     
        contMult3=0;
        for(i=x;i<=y;i=i+1)
        {
            if (i%3==0)
            {
                System.out.println(i +" es múltiplo de 3");
                contMult3=contMult3+1;
            }

        }
        System.out.println("Entre "+x+" y "+y+" hay "+contMult3+" múltiplos de 3");
        
    }
    
}
