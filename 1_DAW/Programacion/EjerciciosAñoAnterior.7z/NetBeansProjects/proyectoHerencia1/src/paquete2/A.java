/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package paquete2;

/**
 *
 * @author Profesor
 */
public class A {
    protected int x, y;

    public A(int x, int y) //PATRÓN
    {
        this.x = x;
        this.y = y;
    }
    
    public A(){
        //this.x=this.y=1;
       // this(1,1);
       this(1);
    }
    
    public A(int valor)
    {
       this(valor,valor);    
    }
    
    public A(A otroA)
    {
        this(otroA.x, otroA.y);
    } 
    
    public int suma()
    {
        return this.x+this.y;
    }

    @Override
    public String toString() {
        return "{" +  this.x + " " + this.y + "}";
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public void setX(int x) {
        this.x = x;
    }

    public void setY(int y) {
        this.y = y;
    }
    
    
}
