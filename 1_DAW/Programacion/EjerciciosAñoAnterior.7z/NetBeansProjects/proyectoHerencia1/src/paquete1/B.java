/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package paquete1;

import paquete2.A;

/**
 *
 * @author Profesor
 */
public class B extends A{
    protected int z;

    public B(int z, int x, int y)
    {
       super(x,y); 
       // super.x=x;
       // super.y=y;
        this.z = z;        
    }
    
    public B(){
        super();
        this.z=1;
    }
    
    public B(int z, int valor)
    {
        super(valor, valor); //super(valor);
        this.z=z;
    }
    
    public B(int z, A otro)
    {
        super(otro);
        // super(otro.getX(), otro.getY());
        /* super.x=otro.getX();
        super.y=otro.getY();
        */
        this.z=z;
    }
    /*
    public B(B otroB)
    {
       super(otroB); 
       this.z=otroB.z;
    }
    */
    @Override
    public String toString()
    {
       return "{"+super.x+" "+super.y+"}"+ this.z;
      //  return super.toString() + this.z;
    }
   
    
    public void mostrarZ()
    {
        System.out.println(this.z);        
    }

    public int getZ() {
        return z;
    }

    public void setZ(int z) {
        this.z = z;
    }
    
    
}
