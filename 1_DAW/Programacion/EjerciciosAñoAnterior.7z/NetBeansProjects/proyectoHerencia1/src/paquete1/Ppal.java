/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package paquete1;

import paquete2.A;

/**
 *
 * @author Profesor
 */
public class Ppal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       A a=new A(4,10);
       //a.setX(4);
       //a.setY(10);
       System.out.println("a="+a);
       System.out.println("Suma a="+a.suma());
       
       B b=new B(20,4,9);
       //b.setX(4);
       //b.setY(9);
       //b.z=20;
       System.out.println("b="+b);
       System.out.println("Suma b="+b.suma());
       b.mostrarZ();      
    
       
       A objA;
       objA=a;
        System.out.println("x de objA "+objA.getX());
        System.out.println("objA = "+objA);
        System.out.println("Suma en objA = "+objA.suma());
        
        objA=b;
        System.out.println("x de objA "+objA.getX()); //x de b-> 4
        System.out.println("objA ="+objA);
        System.out.println("Suma en objA ="+objA.suma());
        //objA.mostrarZ();
    }
    
}
