/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Punto;

/**
 *
 * @author Profesor
 */
public class Punto {
    private int x,y;

    //Constructor con las 2 coordenadas
    public Punto(int x, int y) {
        this.x = x;
        this.y = y;
    }

    //Constructor por defecto
    public Punto() {
        this.x=this.y=-1;
    }
    
    //Constructor un dato de entrada int, x e y toman el mismo valor
    public Punto(int n) {
        this.x=this.y=n;
    }
    
    //Constructor un dato de entrada otroPunto
    //Las coordenadas del punto a crear coinciden con las de otroPunto
    public Punto(Punto otro) {
        this.x=otro.x;
        this.y=otro.y;
    }
    
    
    public int getX() {
        return this.x;
    }

    public int getY() {
        return this.y;
    }

    public void setX(int x) {
        this.x = x;
    }

    public void setY(int y) {
        this.y = y;
    }

    @Override
    public String toString() {
        return "(" + this.x + ","  + this.y + ")";
    }
    
    public double distancia(Punto otro)
    {       
     return Math.sqrt(Math.pow(this.x-otro.x,2)+Math.pow(this.y-otro.y,2)); 
     //return Math.hypot(this.x-otro.x, this.y-otro.y);     
    }
    
    public double distancia(int a, int b)
    {       
     return Math.sqrt(Math.pow(this.x-a,2)+Math.pow(this.y-b,2)); 
     //return Math.hypot(this.x-otro.x, this.y-otro.y);     
    }
    
    public Punto ptoSuma(Punto otro)
    {
       /* 
        Punto suma=new Punto();
        suma.x=this.x+otro.x;
        suma.y=this.y+otro.y;
        
        //Punto suma=new Punto(this.x+otro.x , this.y+otro.y);
        return suma;
        */        
        return this.ptoSuma(otro.x, otro.y);
    }
    
    //MÉTODO MODELO O PATRÓN
    public Punto ptoSuma(int a, int b)
    {
        
        Punto suma=new Punto();
        suma.x=this.x+a;
        suma.y=this.y+b;
        return suma;
        
        //return new Punto(this.x+a, this.y+b);
    }
    
    public Punto ptoIntermedio(Punto otro)
    {
       return this.ptoIntermedio(otro.x, otro.y);
    }
    
    //Método Patrón
    public Punto ptoIntermedio(int a, int b)
    {        
        Punto suma=new Punto();
        suma.x=(this.x+a)/2;
        suma.y=(this.y+b)/2;
        
        return suma;        
    }
    
    public Punto ptoOpuesto() 
    {
        Punto op=new Punto(-this.x, -this.y);
        return op;
    }
     
    //Método patrón
    public void setPunto(int a, int b)
    {
        this.x=a;
        this.y=b;
    }
    
    public void setPunto(Punto otro)
    {
        /*
        this.x=otro.x;
        this.y=otro.y;
        */
        this.setPunto(otro.x, otro.y);
    }
    
}
