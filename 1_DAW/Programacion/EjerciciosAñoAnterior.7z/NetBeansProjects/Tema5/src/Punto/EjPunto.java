/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Punto;

/**
 *
 * @author Profesor
 */
public class EjPunto {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Punto p=new Punto(3,4);
        System.out.println("Punto p"+p.toString());
        
        //q=(3+la x de p, 5+la y de p)
        Punto q=new Punto(3+p.getX(), 5+p.getY());
        System.out.println("Punto q"+q);
        
        //Del q se quiere cambiar la coordenada y
        // La suma de la coordenada x del punto p con la coordenada x del q
        // +1 
        q.setY(p.getX()+q.getX() +1); 
        System.out.println("Punto q"+q);
        
        
        //Crear el punto r por defecto
        Punto r=new Punto();
        System.out.println("Punto r"+r);
        
        //Crear el punto s cuyas coordenadas sean 7
        //Punto s=new Punto(7,7);
        //Punto s=new Punto();
        //s.setX(7);s.setY(7);
        Punto s=new Punto(7);
        System.out.println("Punto s"+s);
        
        Punto t=new Punto(p);
        System.out.println("Punto p"+p);
        System.out.println("Punto t"+t);
        System.out.println("La distancia entre p y t es "+p.distancia(t));
        System.out.println("La distancia entre p y q es "+p.distancia(q));
        System.out.println("La distancia entre p y el punto(8,4)"+p.distancia(new Punto(8,4)));
        System.out.println("La distancia entre p y el punto(8,4)"+p.distancia(8,4));
        
        
        Punto sumaRP=r.ptoSuma(p); // r(-1,-1)  p(3,4)
        System.out.println("El punto sumaRP"+sumaRP);
        
        Punto intermedioRP=r.ptoIntermedio(p);
        System.out.println("El punto intermedio"+intermedioRP);
        
        //Cread un punto pp que sea el punto opuesto del punto intermedio
        //entre el punto t y las suma de los puntos p y q
        
        Punto pp=t.ptoIntermedio(p.ptoSuma(q)).ptoOpuesto();
        System.out.println("Punto pp "+pp);
        
        
        /*Hace lo mismo
        Punto pq=p.ptoSuma(q);
        System.out.println("suma p y q "+pq);
        Punto tpq=t.ptoIntermedio(pq);
        System.out.println("intermedio de t con pq "+tpq);
        Punto otpq=tpq.ptoOpuesto();
        System.out.println("Opuesto de otpq "+otpq);
        */
        
        
        //Cambia la coordenada y del punto t con el siguiente valor
        //Será la coordenada x del punto suma de p con el opuesto de t
        t.setY(t.ptoOpuesto().ptoSuma(p).getX());
        
        System.out.println("Punto t "+t);
        System.out.println("coordenada Y de t "+p.ptoSuma(t.ptoOpuesto()).getX());
       
        //Creando puntos
        Punto ot=t.ptoOpuesto();
        Punto sot=p.ptoSuma(ot);
        int cx=sot.getX();
        t.setY(cx);
        
        //Cambia la coordenada X del p
        //Será la coordenada Y 
        //del punto intermedio de t con la suma del punto q y opuesto de p 
        
        //p.setX(t.ptoIntermedio(q.ptoSuma(p.ptoOpuesto())).getY());
        //System.out.println("Punto p"+p);
        
        
        Punto aa=p.ptoOpuesto();
        Punto aaa=q.ptoSuma(aa);
        Punto aaaa=t.ptoIntermedio(aaa);
        int y=aaaa.getY();
        p.setX(y);
        System.out.println("Punto p"+p);
        
       // p.setX(p.ptoOpuesto().ptoSuma(q).ptoIntermedio(t).getY());
       // System.out.println("Punto p"+p);
        
       
        Punto alberto=new Punto(3,3);
        Punto sumaAlbertoOrigen=alberto.ptoSuma(0,0);
        
        Punto sumaAlbertoP=alberto.ptoSuma(p);
        
        //Punto sumaTresPuntos=alberto.ptoSuma(p.ptoSuma(0,0));
        //Punto sumaTresPuntos=alberto.ptoSuma(p).ptoSuma(0,0);
        
        
        
        
        
        
        
    }
    
}
