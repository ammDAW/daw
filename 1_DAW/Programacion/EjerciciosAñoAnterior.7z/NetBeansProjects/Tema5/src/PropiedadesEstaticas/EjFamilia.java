/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PropiedadesEstaticas;

/**
 *
 * @author Profesor
 */
public class EjFamilia {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Familia nacho=new Familia("Nacho",22);
        Familia madreNacho=new Familia("Josefa",48);
        Familia padreNacho=new Familia("Juan",52);
        System.out.println("Nacho ="+nacho);
        System.out.println("Madre de Nacho ="+madreNacho);
        System.out.println("Padre de Nacho ="+padreNacho);
        
        Familia.setDireccion("Vizcaya");
        System.out.println("Nacho ="+nacho);
        System.out.println("Madre de Nacho ="+madreNacho);
        System.out.println("Padre de Nacho ="+padreNacho);
        
        System.out.println("Dirección de todos los miembros de la familia "+Familia.getDireccion());
    }
    
}
