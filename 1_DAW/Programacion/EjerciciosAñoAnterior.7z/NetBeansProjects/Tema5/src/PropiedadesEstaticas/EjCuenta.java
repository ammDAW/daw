/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PropiedadesEstaticas;

/**
 *
 * @author Profesor
 */
public class EjCuenta {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Cuenta jesus=new Cuenta("Jesús Moreno",200000);
        Cuenta caparros=new Cuenta("Antonio Caparros",200);
        Cuenta zhi=new Cuenta("Zhi Feng",1000000);
        
        System.out.println("La cuenta de Jesús "+jesus);
        System.out.println("La cuenta de Caparros "+caparros);
        System.out.println("La cuenta de Zhi Feng "+zhi);
        
        Cuenta.setBeneficio(0.15);
        
        System.out.println("La cuenta de Jesús "+jesus);
        System.out.println("La cuenta de Caparros "+caparros);
        System.out.println("La cuenta de Zhi Feng "+zhi);
        
        zhi.reintegro(50000);
        System.out.println("El saldo de Zhi Feng es "+zhi.getSaldo());
        
        jesus.reintegro(1000000);
        System.out.println("El saldo de Jesús es "+jesus.getSaldo());
        
        caparros.reintegro(-12);
        System.out.println("El saldo de Caparrós es "+caparros.getSaldo());
        
    }
    
}
