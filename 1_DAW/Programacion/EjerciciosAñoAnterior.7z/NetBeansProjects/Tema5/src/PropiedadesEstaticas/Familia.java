/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PropiedadesEstaticas;

/**
 *
 * @author Profesor
 */
public class Familia {
    private String nombre;
    private int edad;
    private static String direccion;

    public Familia(String nombre, int edad) {
        this.nombre = nombre;
        this.edad = edad;
        Familia.direccion="Murcia";//Propiedad estática
    }

    public String getNombre() {
        return this.nombre;
    }

    public int getEdad() {
        return this.edad;
    }

    public static String getDireccion() {
        return Familia.direccion;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public static void setDireccion(String direccion) {
        Familia.direccion = direccion;
    }

    
    
    
    @Override
    public String toString() {
        return "{" + "Nombre=" + this.nombre + " Edad=" + this.edad + " Dirección= "+Familia.direccion  +'}';
    }
    
    
    
    
}
