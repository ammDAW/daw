/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PropiedadesEstaticas;

/**
 *
 * @author Profesor
 */
public class Cuenta {
    private String titular;
    private double saldo;
    private static double beneficio=0.12;

    public Cuenta(String titular, double saldo) {
        this.titular = titular;
        this.saldo = saldo;
    }

    public String getTitular() {
        return this.titular;
    }

    public double getSaldo() {
        return this.saldo;
    }

    public static double getBeneficio() {
        return Cuenta.beneficio;
    }

    public void setTitular(String titular) {
        this.titular = titular;
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }

    public static void setBeneficio(double beneficio) {
        Cuenta.beneficio = beneficio;
    }

    @Override
    public String toString() {
        return "{" + "Titular=" + this.titular + " Saldo=" + this.saldo + " Intereses= "+Cuenta.beneficio+ '}';
    }
    
    public void ingresar(double cantidad){
      if (cantidad <0)
          System.out.println("Error, no puedes ingresar dinero en negativo");  
      else
          this.saldo=this.saldo+cantidad;
    }
    
    public void reintegro(double cantidad){
      if (cantidad <=0)
            System.out.println("Error, cantidad de dinero incorrecto...");
      else if (cantidad > this.saldo)
            System.out.println("Error, saldo insuficiente");
      else
          this.saldo-=cantidad;
    }
}
