/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Triangulo;

/**
 *
 * @author Profesor
 */
public class Triangulo {
    // PROPIEDADES
    private int base;
    private int altura;
    
    public Triangulo(int base, int altura)
    {
        this.base=base;
        this.altura=altura;
    }
    
    public Triangulo(int n)
    {
        this.base=this.altura=n;
    }
    
    
    //MÉTODOS
    //1. Método que se utiliza al inicializar un triángulo
    public void inicializaTriangulo(int baseInicial, int alturaInicial)
    {
        base=baseInicial;
        altura=alturaInicial;
    }
    
    
    //2. Métodos getter y setter
    public int getBase()
    {
        return this.base;
    }

    public int getAltura() {
        return this.altura;
    }
    
    public void setAltura(int altura)
    {
        this.altura=altura;
    }

    public void setBase(int base) {
        this.base = base;
    }
    
    //3. Método mostrar datos de un triángulo
    public void mostrarTriangulo()
    {
        System.out.println("Los datos del triángulo son: ");
        System.out.println("Base ="+this.base+" \t Altura ="+this.altura);
    }
    
    @Override
    public String toString()
    {
       return "Base= "+this.base+" \tAltura= "+this.altura+" \tHipotenusa= "+this.hipotenusa();
    }
    
    //Método area: (base*altura)/2
    public double area()
    {        
        return (this.base*this.altura)/2.0;
    }
    
    //Método hipotenusa
    public double hipotenusa()
    {
      return Math.hypot(this.base, this.altura);
    }
    
    //Método perímetro
    public double perimetro()
    {
        return this.base+this.altura+hipotenusa();
    }
    
    //Método equals
    public boolean equals(Triangulo t)
    {
        if (this.base==t.base && this.altura==t.altura)
            return true;
        else 
            return false;
        
        //return (this.base==t.base && this.altura==t.altura);
        /*
        if (this.base==t.base && this.altura==t.altura && this.hipotenusa()==t.hipotenusa())
            return true;
        else 
            return false;
      */  
        
    }
    
    public boolean equals(int base, int altura)
    {
        if (this.base==base && this.altura==altura)
            return true;
        else
            return false;
    }
    
    
}
