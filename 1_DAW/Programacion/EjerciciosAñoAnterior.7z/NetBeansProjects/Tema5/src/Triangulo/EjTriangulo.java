/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Triangulo;

/**
 *
 * @author Profesor
 */
public class EjTriangulo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Triangulo t1=new Triangulo(1,4);
        
        System.out.println("Triángulo t1 ="+t1);
        System.out.println("Triángulo t1 ="+t1.toString());
        
        Triangulo sergio=new Triangulo(8);
        System.out.println("El triángulo sergio = "+sergio);
        
        /*
        
        System.out.println("Triángulo t1:");
        t1.mostrarTriangulo();
        //Inicializamos base=10, altura=20
        t1.inicializaTriangulo(10, 20);
        System.out.println("Triángulo t1:");
        t1.mostrarTriangulo();
        
        Triangulo t2=new Triangulo();
        t2.inicializaTriangulo(t1.getBase(), t1.getAltura()-2);
        t2.mostrarTriangulo();
        
        //Cambio: base de t2 sea igual a altura de t1
        t2.setBase(t1.getAltura());
        t2.mostrarTriangulo();
        
        System.out.println("Datos del Triángulo t2= "+t2.toString());
        //Si pongo t2 en el siguiente sout, se ejecuta de forma impícita el 
        //método toString()
        System.out.println("Datos del Triángulo t2= "+t2);
        
        System.out.println("El área de t1 = "+t1.area());
        
        System.out.println("La hipotenusa de t1 es "+t1.hipotenusa());
        System.out.println("El perímetro de t1 es "+t1.perimetro());
        
        
        if (t1.equals(t2)) //t1 es this, t2 es t en la clase Triangulo
            System.out.println("Los triángulos t1 y t2 son iguales");
        else
            System.out.println("Los triángulos t1 y t2 NO son iguales");
        
        */
        
        
    }
    
}
