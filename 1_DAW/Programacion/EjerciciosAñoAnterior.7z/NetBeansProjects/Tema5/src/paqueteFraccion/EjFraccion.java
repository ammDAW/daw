/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package paqueteFraccion;

/**
 *
 * @author Profesor
 */
public class EjFraccion {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        /*
        Fraccion f=new Fraccion(3,2);
        Fraccion g=new Fraccion();
        Fraccion h=new Fraccion(f);
        
        System.out.println("Fracción f="+f);
        System.out.println("Fracción g="+g);
        System.out.println("Fracción h="+h);
        
        //Se cambia la fracción f de forma completa
        //numerador es el denominador de la fracción g
        //denominador es 1
        f.setFraccion(g.getDen(), 1);
        System.out.println("Fracción f="+f);
        
        if (f.equals(1,1))
            System.out.println("f y el quebrado formado por 1/1 son iguales");
        else
            System.out.println("No son iguales");
        */
        
        //uso de la clase Fracción (hoja de ejercicios)
        Fraccion f=new Fraccion(27,5);
        Fraccion g=new Fraccion();
        Fraccion h=new Fraccion(g);
        
        System.out.println("f="+f);
        System.out.println("g="+g);
        System.out.println("h="+h);
        
        Fraccion j=new Fraccion(11,3); //Se supone introducidos por teclado
        System.out.println("j="+j);
        
        //f)
        //Falta reducir la fracción f
        f.setNum(g.getDen());
        f.setDen(h.getNum());
        System.out.println("f="+f);
        
        g.setFraccion(h);
        System.out.println("g="+g);
        
        //g)
        Fraccion k=g.fraccionResta(f);
        //Fraccion k=new Fraccion(g.fraccionResta(f));
        System.out.println("k="+k);
        
        //h)
        Fraccion l=h.fraccionCociente(18, 5);
        System.out.println("l="+l);
        
        //i)
        System.out.println("h:k="+h.fraccionCociente(k));
        
        //Fraccion t=new Fraccion(h.fraccionCociente(k));
        //System.out.println("t="+t);
        
        //j)
        System.out.println("j="+j+" \tl="+l);
        Fraccion m=j.fraccionResta(l.fraccionSuma(23,8));
        System.out.println("m="+m);
        
        //k) La fracción h se cambia a 9/1
        h.setNum(9);
        Fraccion n=g.fraccionCociente( h.fraccionResta(f));
        System.out.println("n="+n);
        
        
        //mcd
        //int nn=Fraccion.mcd(30, 10);
        //System.out.println("El máximo común divisor (30,10) es "+nn);
        
        
        Fraccion ar=new Fraccion(30,10);
        System.out.println("ar "+ar);
        ar.reducir();
        System.out.println("ar reducida "+ar);
        
        System.out.println("Clonación");
        Fraccion clonada=f.clone();
        System.out.println("f="+f);
        System.out.println("clonada="+clonada);
        //Fraccion clonada=new Fraccion(f); Es lo mismo
        
        //f.finalize(); //Método especial, se ejecuta para liberar memoria 
        
        //l)
        //Fraccion o, numerador= denominador de la fraccion suma f y h
        //            denominador= denominador de la fraccion resta g y m 
        Fraccion o=new Fraccion(f.fraccionSuma(h).getDen(), g.fraccionResta(m).getDen());
        System.out.println("Fracción o="+o);
    }
    
}
