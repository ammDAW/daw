/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package paqueteFraccion;

/**
 *
 * @author Profesor
 */
public class Fraccion {
    private int num,den;

    //CONSTRUCTOR PATRÓN
    public Fraccion(int num, int den) {
        this.num = num;
        this.den = den;
        this.reducir();
    }

    public Fraccion() {
        //this.num=1
        //this.den=1;
        this(1,1);
    }
    
    public Fraccion(Fraccion fr)
    {
        this(fr.num,fr.den);
    }
    
    //MÉTODOS DE ACCESO A LAS PROPIEDADES
    //GETTER
    public int getNum() {
        return this.num;
    }

    public int getDen() {
        return this.den;
    }
    //SETTER

    public void setNum(int num) {
        this.num = num;
        this.reducir();
    }

    public void setDen(int den) {
        this.den = den;
        this.reducir();
    }
    
    //SETFRACCION SOBRECARGADO
    //MÉTODO PATRÓN
    public void setFraccion(int num, int den)
    {
        this.num=num;
        this.den=den;
        this.reducir();
    }
    
    public void setFraccion(Fraccion otra)
    {
       /* 
        this.num=otra.num;
        this.den=otra.den;
       */ 
        this.setFraccion(otra.num, otra.den);
    }

    @Override
    public String toString() {
        return "(" + this.num + "/" + this.den + ')';
    }
    
    public boolean equals(int num, int den)
    {
        if (this.num==num && this.den==den)
            return true;
        else
            return false;
    }

    public boolean equals(Fraccion otra)
    {
        return this.equals(otra.num, otra.den);
    }
    
    
    //Operaciones con fracciones: suma, resta, multiplicación y la división
    //MÉTODO PATRÓN
    public Fraccion fraccionSuma(Fraccion otra)
    {
        Fraccion result=new Fraccion();
        result.num=this.num*otra.den + this.den*otra.num;
        result.den=this.den*otra.den; 
        result.reducir();
        return result;
    }
    
    public Fraccion fraccionSuma(int num, int den)
    {
        return this.fraccionSuma(new Fraccion(num,den));
    }
    
    //Método restaFraccion PATRÓN
    public Fraccion fraccionResta(int num, int den)
    {
        Fraccion result=new Fraccion();
        result.num=this.num* den - this.den* num;
        result.den=this.den* den;  
        result.reducir();
        return result;
    }
    
    public Fraccion fraccionResta(Fraccion otra)
    {
        return this.fraccionResta(otra.num, otra.den);
    }
    
    //Método PATRÓN
    public Fraccion fraccionProducto(int num, int den)
    {
        Fraccion result=new Fraccion();
        result.num=this.num* num;
        result.den=this.den* den; 
        result.reducir();
        return result;
    }
    
    public Fraccion fraccionProducto(Fraccion otra)
    {
        return this.fraccionProducto(otra.num, otra.den);
    }
    
    //Método PATRÓN
    public Fraccion fraccionCociente(int num, int den)
    {
        Fraccion result=new Fraccion();
        result.num=this.num* den;
        result.den=this.den* num; 
        result.reducir();
        return result;
    }
    
    public Fraccion fraccionCociente(Fraccion otra)
    {
        return this.fraccionCociente(otra.num, otra.den);
    }
    
    private static int mcd(int x, int y)
    {
        int menor=Math.min(Math.abs(x),Math.abs(y));
        int mcd=1;
            for(int i=1; i<=menor ; i++)
            {    
              if (i>(menor/2) && i!=menor) continue;  
              
              if (x%i==0 && y%i==0)
                    mcd=i;
            }    
        return mcd;
    }
    
    private static int mcd(Fraccion otra){
        
        return Fraccion.mcd(otra.num, otra.den);
    }
    
    public void reducir()
    {
        int mcd=Fraccion.mcd(this.num, this.den);
        this.num/=mcd;
        this.den/=mcd;
    }
    
    @Override
    public Fraccion clone()
    {
       // Fraccion copia=new Fraccion(this.num, this.den); Llama al constructor Fraccion (int ,int)
        Fraccion copia=new Fraccion(this); //Llama al constructor Fraccion(Fraccion otra)
        /*copia.num=this.num;
        copia.den=this.den;*/
        return copia;
    }
    
    
    public void finalize()
    {
        System.out.println("Se ha destruído el objeto "+this.toString());
    }
    
    
}
