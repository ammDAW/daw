/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Alcance;

import Ejemplos.Taxi;



/**
 *
 * @author Profesor
 */
public class EjAlcance {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       Taxi t1=new Taxi();
       
       t1.darAlta("121-FFF","ZhiFeng", "GASOLINA");
       
       t1.mostrarPantalla();
       
       
               
    }
    
}
