/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ejemplos;

import java.util.Scanner;

/**
 *
 * @author Profesor
 */
public class Pedir {
    public static int entero(String mensaje)
    {
        Scanner teclado=new Scanner(System.in);
        String cadena;
         boolean entero=false;   
         int n=0;
    do{   
       try{ 
          System.out.print(mensaje);
          cadena=teclado.nextLine();
          n=Integer.parseInt(cadena);
          entero=true;          
       }
       catch(NumberFormatException e)
       {
        System.out.println("Te has equivocado, vuelve a introducir ");
       }
    }while(!entero); 
    return n;
    }
    
    public static byte Byte(String mensaje)
    {
        Scanner teclado=new Scanner(System.in);
        String cadena;
        byte n=0;
        
         boolean entero=false;   
    do{   
       try{ 
          System.out.print(mensaje);
          cadena=teclado.nextLine();
          n=Byte.parseByte(cadena);
          entero=true;          
       }
       catch(NumberFormatException e)
       {
        System.out.println("Te has equivocado, vuelve a introducir ");
       }
    }while(!entero);
 
        
        return n;
    } 
    
    public static short Short(String mensaje)
    {
        Scanner teclado=new Scanner(System.in);
        System.out.print(mensaje);
        String cadena=teclado.nextLine();
        short n=Short.parseShort(cadena);
        
        return n;
    }
    
   public static long Long(String mensaje)
    {
        Scanner teclado=new Scanner(System.in);
        System.out.print(mensaje);
        String cadena=teclado.nextLine();
        long n=Long.parseLong(cadena);
        
        return n;
    }
    
    public static float Float(String mensaje)
    {
        Scanner teclado=new Scanner(System.in);
        System.out.print(mensaje);
        String cadena=teclado.nextLine();
        float n=Float.parseFloat(cadena);
        
        return n;
    }
    
    public static double Double(String mensaje)
    {
        Scanner teclado=new Scanner(System.in);
        String cadena;
        double n=0.0;
         boolean entero=false;   
    do{   
       try{ 
          System.out.print(mensaje);
          cadena=teclado.nextLine();
          n=Double.parseDouble(cadena);
          entero=true;          
       }
       catch(NumberFormatException e)
       {
        System.out.println("Te has equivocado, vuelve a introducir ");
       }
    }while(!entero);
        
        return n;
    }
    
    public static char Char(String mensaje)
    {
        Scanner teclado=new Scanner(System.in);
        System.out.print(mensaje);
        String cadena=teclado.nextLine();
        char n=cadena.charAt(0);
        
        return n;
    }
    
     public static String cadena(String mensaje)
    {
        Scanner teclado=new Scanner(System.in);
        System.out.print(mensaje);
        String cadena=teclado.nextLine();
                
        return cadena;
    }
    
}
