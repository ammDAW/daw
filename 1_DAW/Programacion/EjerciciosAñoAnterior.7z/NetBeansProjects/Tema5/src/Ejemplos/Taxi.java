/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ejemplos;

/**
 *
 * @author Profesor
 */
public class Taxi {
    //MIEMBROS
    
    //PROPIEDADES
    private String matricula;
    String taxista;
    public String tipoMotor; //Debe ser: "DIESEL", "GASOLINA", "HÍBRIDO", "ELÉCTRICO"
    
    //MÉTODOS
    String devuelveMatricula()
    {
        return matricula;
    }
    
    String getMatricula()
    {
        return matricula;
    }
        
    void cambioMatricula(String mt)
    {
        matricula=mt;
    }
    
    void setMatricula(String mt)
    {
        matricula=mt;
    }
    
    public void darAlta(String mt, String tx, String tm)
    {
        matricula=mt;
        taxista=tx;
        tipoMotor=tm;
    }
    
    public void mostrarPantalla()
    {
         System.out.println("Taxi: \nMatrícula: "+matricula+"\tTaxista: "+taxista+"\tTipo de Motor: "+tipoMotor);    
    }
    
}
