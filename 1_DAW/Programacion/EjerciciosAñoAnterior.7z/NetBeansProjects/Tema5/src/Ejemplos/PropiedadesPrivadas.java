/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ejemplos;

/**
 *
 * @author Profesor
 */
public class PropiedadesPrivadas {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       Taxi t=new Taxi();
       
       t.darAlta("123-LLL","Jesús","GASOLINA");
       
       System.out.println("El taxista de t es "+t.taxista);
        
       t.mostrarPantalla();
       String mat=t.devuelveMatricula();
        System.out.println("La matrícula es "+mat);
       mat=t.getMatricula();
        System.out.println("La matrícula es "+mat);
       
    }
    
}
