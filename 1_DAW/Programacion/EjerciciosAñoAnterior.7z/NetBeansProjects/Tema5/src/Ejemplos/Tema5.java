/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ejemplos;

/**
 *
 * @author Profesor
 */
public class Tema5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //Declaración de un objeto
        Taxi augusto;
        //Se va a trabajar con un taxi llamado augusto
        
        //Crea un objeto en blanco
        augusto=new Taxi();
        //Se reserva una zona de memoria 
        //Para guardar: matricula, taxista, tipoMotor y los métodos
        
        Taxi molina=new Taxi(); //Declaración y creación de un Taxi
        
        //augusto.matricula="2356-FDS"; //NO permitido ya que matricula es privado
        augusto.cambioMatricula("2345-LLL");
        augusto.taxista="Javier Castaño";
        augusto.tipoMotor="DIESEL";
        
        augusto.mostrarPantalla();
        
        String mat=augusto.devuelveMatricula();
        System.out.println("La matrícula del taxi augusto es :"+mat);
        
        augusto.cambioMatricula("3332-DDD");
        augusto.taxista="Juan Antonio Notario";
        augusto.tipoMotor="GASOLINA";
        
        System.out.println("El taxista de augusto es "+augusto.taxista);
        System.out.println("La matricula del taxi augusto es "+augusto.devuelveMatricula());
        
        
        /*
        System.out.println("El tipo de Motor del taxi augusto es: "+augusto.tipoMotor);
        System.out.println("La matrícula del taxi augusto es: "+augusto.matricula);
        System.out.println("El taxista de augusto es "+augusto.taxista);
        
        
        augusto.taxista="Sergio Ortuño";
        System.out.println("El taxista de augusto es "+augusto.taxista);
        
        augusto.matricula=Pedir.cadena("Dime la nueva matrícula de augusto: ");
        System.out.println("Nueva matrícula de augusto es: "+augusto.matricula);
        
        
        augusto.mostrarPantalla();
       
        System.out.println("Taxi molina");
        molina.darAlta("222-KOP","Pedro Sánchez","GASOLINA");
        
        System.out.println("Datos del taxi Molina");
        molina.mostrarPantalla();
        
        String nombreTaxistaMolina=molina.taxista;
        System.out.println("El nombre del taxista de molina es: "+nombreTaxistaMolina);
        */
    }
    
}
