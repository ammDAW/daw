/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Caja;

/**
 *
 * @author Profesor
 */
public class EjCaja {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Caja cajita=new Caja();
            
        
        // el alto de la Caja cajita es 7, largo es 12 y profundo 5
        cajita.setAlto(7);
        cajita.setLargo(12);
        cajita.setProfundo(5);
        
        //Mostrar los valores de la Caja cajita
        System.out.println("Alto de cajita ="+cajita.getAlto());
        System.out.println("Largo de cajita ="+cajita.getLargo());
        System.out.println("Profundo de cajita ="+cajita.getProfundo());
        
        Caja cajaRosa=new Caja();
        //Para cajaRosa, le voy a dar como alto=9, largo=10 y profundo= 7
        cajaRosa.inicializaCaja(9, 10, 7);
        //Para mostrar el alto, largo y profundo de cajaRosa
        System.out.println("Datos de la cajaRosa");
        cajaRosa.mostrarCaja();
        
        //Crear una nueva caja cajaNueva
        //alto sea la suma del alto de cajita con 7
        //largo sea el largo de cajita - largo de cajaRosa
        //profundo sea el mismo valor que el alto de cajaRosa
        
        Caja cajaNueva=new Caja();
        
        /*
        cajaNueva.setAlto(cajita.getAlto()+7);
        
        int largoCajita=cajita.getLargo();
        int largocajaRosa=cajaRosa.getLargo();
        cajaNueva.setLargo(largoCajita - largocajaRosa);
        
        //De otra forma
        cajaNueva.setLargo(cajita.getLargo()-cajaRosa.getLargo());
               
        cajaNueva.setProfundo(cajaRosa.getAlto());
       */
        
        cajaNueva.inicializaCaja(cajita.getAlto()+7,cajita.getLargo()-cajaRosa.getLargo(), cajaRosa.getAlto());
        System.out.println("Datos de la nueva Caja");
        cajaNueva.mostrarCaja();
        
        System.out.println("El volumen de cajita es "+cajita.volumen());
        System.out.println("El volumen de caja nueva es "+cajaNueva.volumen());
        
        cajaNueva.duplicaTamanio();
        System.out.println("Datos de la caja Nueva");
        cajaNueva.mostrarCaja();
        
        cajaNueva.ampliaTamanio(10);
        System.out.println("Datos de la caja Nueva");
        cajaNueva.mostrarCaja();
        
        cajaNueva.setCaja(10, 10, 10);
        System.out.println("caja Nueva modificada");
        cajaNueva.mostrarCaja();
        String cd=cajaNueva.toString();
        System.out.println("Datos de la caja nueva :\n"+cd);
        System.out.println("Datos de la caja nueva :\n"+cajaNueva.toString());
        
    }
    
}
