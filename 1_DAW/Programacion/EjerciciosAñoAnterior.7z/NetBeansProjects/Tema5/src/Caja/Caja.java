/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Caja;

/**
 *
 * @author Profesor
 */
public class Caja {
    //Propiedades
    private int alto, largo, profundo;
    
    //Métodos
    //1. Getter
    public int getAlto()
    {
        return alto;
    }
    
    public int getLargo()
    {
        return largo;
    }
    
    public int getProfundo()
    {
        return profundo;
    }
    
    //2. Setter
    public void setAlto(int a)
    {
        alto=a;
    }
    public void setLargo(int b)
    {
        largo=b;
    }
    public void setProfundo(int c)
    {
        profundo=c;
    }
    
    //3. Dar de alta a una caja
    public void inicializaCaja(int a, int b, int c)
    {
        alto=a;
        largo=b;
        profundo=c;
    }
    
    //4. Método para mostrar todos los datos de una caja
    public void mostrarCaja()
    {
        System.out.println("Alto= "+alto+" \tLargo= "+largo+" \tProfundo= "+profundo);
    }
    
    //5. Método volumen, calcula el volumen de una caja
    public int volumen()
    {
        return alto*largo*profundo;
    }
    
    //6. Método duplicaTamanio, duplica el alto, largo y profundo
    public void duplicaTamanio()
    {
        alto*=2; largo*=2; profundo*=2;
    }
    
    //7. Método ampliaTamanio(int n), amplia el alto, largo y profundo en n unidades
    public void ampliaTamanio(int n)
    {
        alto+=n; largo+=n;profundo+=n;
    }
    
    //8. Método setCaja, se le dan nuevos valores a todas las dimensiones 
    //de una caja
    public void setCaja(int nuevoAlto, int nuevoLargo, int nuevoProfundo)
    {
        alto=nuevoAlto;
        largo=nuevoLargo;
        profundo=nuevoProfundo;
    }
    
    
    @Override
    public String toString()
    {
        String cadena="Alto= "+alto+" \tLargo= "+largo+" \tProfundo= "+profundo;
        return cadena;
    }
    
    
}
