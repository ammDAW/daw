/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package calculadora;

/**
 *
 * @author usuario
 */
public class Calculando {

    public double add(double number1, double number2){
    return number1 + number2; 
    } 
    
    public double subtract(double number1, double number2){ 
    return number1 - number2; 
    } 
    
    public double multiply(double number1, double number2) { 
    return number1 * number2; 
    } 

    public double divide(double number1, double number2){ 
    return number1 / number2; 
}




}
