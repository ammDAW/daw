/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tema4;

/**
 *
 * @author Profesor
 */
public class Ej5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int dia=Pedir.entero("Dime el valor del día: ");
        int mes=Pedir.entero("Dime el valor del mes: ");
        int anio=Pedir.entero("Dime el valor del año: ");
        
        int diasMeses[]={0,31,28,31,30,31,30,31,31,30,31,30,31};
        
        if (MiArray.esBisiesto(anio)) diasMeses[2]=29;
        
        int sumaDias=0;
        for(int i=1;i<mes;i++)
            sumaDias += diasMeses[i];
        
        sumaDias += dia;
        System.out.println("Desde el 1 de Enero de "+anio);
        System.out.println("Hasta la fecha "+dia+"-"+mes+"-"+anio);
        System.out.println("Han transcurrido "+sumaDias+" días");
    }
    
}
