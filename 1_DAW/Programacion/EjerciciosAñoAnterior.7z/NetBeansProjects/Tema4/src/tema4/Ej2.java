/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tema4;

/**
 *
 * @author Profesor
 */
public class Ej2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int tabla[]=new int[10];
        
        for(int i=0;i<10;i++)
            tabla[i]=5*(i+1);
        
        System.out.println("Vector generado");
        for(int i=0;i<tabla.length;i++)
            System.out.println(tabla[i]);
    }
    
}
