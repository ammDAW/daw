/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tema4;

/**
 *
 * @author Profesor
 */
public class Ej3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int v[]={7,56,10,-23,0,9,-99,23,10,12,56,0,88,90,33,-2,28};
        
        int cont10=0,contNulos=0,contNeg=0,contPosi=0;
        for(int i=0;i<v.length;i++)
        {
           if (v[i]==10) cont10++;
           if (v[i]==0) contNulos++;
           else if (v[i]<0) contNeg++;
                else contPosi++;
        }   
        
        System.out.println("En el vector hay "+cont10+" dieces");
        System.out.println("En el vector hay "+contNulos+" ceros");
        System.out.println("En el vector hay "+contNeg+" valores negativos");
        System.out.println("En el vector hay "+contPosi+" valores positivos");
        
        
    }
    
}
