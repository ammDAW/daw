/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tema4;

/**
 *
 * @author Profesor
 */
public class Ej11 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       int v[]={12,4,5,78,45,67,45,66,77,44};
       
      /* Ejercicio 11 
       //a) Guardar el mayor en una variable y su posición en otra
       int my=v[0], posi=0;
        for (int i = 1; i < v.length; i++) {
            if (my<v[i])
            {
                my=v[i];
                posi=i;
            }
        }
        
       //b) Intercambiar el valor mayor con el valor de la última posición 
        v[posi]=v[v.length-1];
        v[v.length-1]=my;
        
        MiArray.mostrarVector(v);
       */ 
        
        //Ordenar el vector
        for(int pasada=1;pasada<v.length;pasada++)
        {
         int my=v[0], posi=0;
         for (int i = 1; i <= v.length - pasada ; i++) {
            if (my<v[i])
            {
                my=v[i];
                posi=i;
            }
        }   
        
         v[posi]=v[v.length-pasada];
         v[v.length-pasada]=my;
        
         MiArray.mostrarVector(v);
            
       }
        
        
    }
    
}
