/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tema4;

/**
 *
 * @author Profesor
 */
public class EjemploTren {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        /*
        int talgo[]=new int[5];
        
        talgo[0]=10;
        talgo[1]=20;
        talgo[2]=30;
        talgo[3]=40;
        talgo[4]=5;
        
        
        int talgo[]={10,20,30,40,5};
        */
        
        //Introducir por teclado los valores de cada vagón
        int talgo[]=new int[5];
        /*
        for(int i=0;i<5;i++)
        {
 int n=Pedir.entero("Dime las personas que hay en el vagón "+(i+1)+" : ");
          talgo[i]=n;          
        }
        */
         for(int i=0;i<5;i++)        
 talgo[i]=Pedir.entero("Dime las personas que hay en el vagón "+(i+1)+" : ");
               

        for(int i=0;i<5;i++)
            System.out.println(talgo[i]);
        
        int suma=0;
        for(int i=0;i<5;i++)
            suma=suma+talgo[i];
        
        
        System.out.println("Hay "+suma+" personas subidas en el Talgo");
    }
    
}
