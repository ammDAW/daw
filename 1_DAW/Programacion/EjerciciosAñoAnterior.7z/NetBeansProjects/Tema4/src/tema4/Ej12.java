/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tema4;

/**
 *
 * @author Profesor
 */
public class Ej12 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int v[]={12,4,5,78,45,67,45,66,77,44};
        
        //Llevar el mayor valor del array a la última posición a base de intercambios
        for (int i = 0; i < v.length -1; i++) {
            if (v[i]>v[i+1])
            {
                int aux=v[i];
                v[i]=v[i+1];
                v[i+1]=aux;
            }
            
        }
        
        MiArray.mostrarVector(v);
    }
    
}
