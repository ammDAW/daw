/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tema4;

/**
 *
 * @author Profesor
 */
public class Prueba {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int w[]={23,45,67,89,-2,0,56};
        MiArray.mostrarVector(w);
        
        int x[]={2,3,4};
        MiArray.mostrarVector(x);
             
        int y[];
        
        //y va a apuntar a w
        y=w;
        //El array w y el array y apuntan a los mismos valores
        //Es lo mismo que decir que y={23,45,67,89,-2,0,56};
        y[1]=-4;
        // Quiere decir que y={23,-4,67,89,-2,0,56};
        // Y también w={23,-4,67,89,-2,0,56};
        
        System.out.println(y[1]);
        System.out.println(w[1]);
        //Saldrá el mismo valor -> -4
        
        //y va a apuntar a x
        y=x;
        //Ahora el vector y={2,3,4};
        y[1]=-7;
        //Quiere decir que y={2,-7,4}
        // Y además x={2,-7,4}
        
        System.out.println(y[1]);
        System.out.println(x[1]);
        
        int k[];
        k=MiArray.pedirVector(4);
        MiArray.mostrarVector(k);
        
        
        
    }
    
}
