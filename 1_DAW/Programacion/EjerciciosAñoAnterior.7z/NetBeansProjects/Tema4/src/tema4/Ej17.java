/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tema4;

/**
 *
 * @author Profesor
 */
public class Ej17 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int v[]={7,56,89,23,58,9,99,23,44,22};
        
        int aux=v[v.length-1];
        for (int i=v.length-1; i>=1; i--)
            v[i]=v[i-1];
        
        v[0]=aux;
        
        MiArray.mostrarVector(v);
    }
    
}
