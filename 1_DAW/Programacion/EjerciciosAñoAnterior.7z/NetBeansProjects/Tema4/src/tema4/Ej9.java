/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tema4;

/**
 *
 * @author Profesor
 */
public class Ej9 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int v[];
        v=MiArray.pedirVector(10);
        
        int my=MiArray.mayorVector(v);
        int repMy=0;
        for (int i = 0; i < v.length; i++) {
            if (v[i]==my)
              repMy++;
        }
        
        System.out.println(my+" es el valor mayor, y se repite "+repMy+" veces");
        
        int mn=MiArray.menorVector(v);
        
        int posi=0;
        for (int i = 0; i < v.length; i++) {
            if (v[i]==mn)
               posi=i;
        }
        
        posi++;
        
        System.out.println(mn+" es el valor menor y ocupa la "+posi+" posición");
    }
    
}
