/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tema4;

/**
 *
 * @author Profesor
 */
public class Ej16 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //Método de la búsqueda dicotómica o binaria
        int v[]={12,34,56,78,89,90,93,95,101};
        
        int x=Pedir.entero("Dime un valor entero: ");
        /*
        boolean encontrado=false;
        int izqda=0, dcha=v.length-1;
        int centro=(izqda+dcha)/2;
        
        while(izqda <= dcha)
        {
           if (v[centro]==x){encontrado=true; break;}
           else if (v[centro]<x) izqda=centro +1;
           else dcha=centro-1;
           
           centro=(izqda+dcha)/2;
        }
        
        System.out.println(x+((encontrado)?" está ":" no está")+" en el array");
        
        */
        //Sin usar break
         boolean encontrado=false;
        int izqda=0, dcha=v.length-1;
        int centro=(izqda+dcha)/2;
        
        while(izqda <= dcha && !encontrado)
        {
           if (v[centro]==x)encontrado=true;
           else if (v[centro]<x) izqda=centro +1;
           else dcha=centro-1;
           
           centro=(izqda+dcha)/2;
        }
        
        System.out.println(x+((encontrado)?" está ":" no está")+" en el array");
       
    }
    
}
