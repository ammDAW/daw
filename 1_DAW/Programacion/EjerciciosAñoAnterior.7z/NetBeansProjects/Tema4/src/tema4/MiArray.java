/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tema4;

/**
 *
 * @author Profesor
 */
public class MiArray {
    public static void mostrarVector(int v[])
    {
        for(int i=0;i<v.length;i++)  
            System.out.print(v[i]+"\t");
        
       
        System.out.println("");
    }
        
    public static void mostrarMatriz(int m[][])
    {
        for(int fila=0;fila<m.length;fila++)
        {
            System.out.println("Fila nº "+(fila+1));
            for(int col=0;col<m[fila].length;col++)
                System.out.print(m[fila][col]+"\t");
            
            System.out.println("");
        }
    }
    
    public static int[][] pedirMatriz(int filas, int columnas)
    {
        int m[][]=new int[filas][columnas];
          for(int fila=0;fila<m.length;fila++)
          {
              System.out.println("Fila nº :"+(fila+1));
              for(int col=0;col<m[fila].length;col++)
                  m[fila][col]=Pedir.entero("Dime un número: ");
          }    
        return m;        
    }
    
    public static int[] pedirVector(int tamanio)
    {
        int v[]=new int[tamanio];
        
        for(int i=0;i<v.length;i++)
            v[i]=Pedir.entero("Dime el valor "+(i+1)+" :");
        
        return v;
    }
    
    public static boolean esBisiesto(int anio)
    {
        boolean es=false;
           if ((anio % 4 == 0) && ((anio % 100 != 0) || (anio % 400 == 0)))
               es=true;
        return es;
    }
    
    public static boolean esFechaCorrecta(int dia, int mes, int anio){
        
        boolean es=false;
        int diasMeses[]={0,31,28,31,30,31,30,31,31,30,31,30,31};
              
        if (anio>=1900 && anio<=2100)
        {
            if (mes>=1 && mes<=12)
            {
                if (MiArray.esBisiesto(anio)) diasMeses[2]=29;
                if (dia>=1 && dia<=diasMeses[mes])
                    es=true;
            }
        }
       
        return es;
    }
    
    public static int mayorVector(int v[])
    {
        int mayor=v[0];
        
        for (int i = 1; i < v.length; i++) {
            if (mayor < v[i])
                mayor=v[i];
        }
        
        return mayor;        
    }
     public static int menorVector(int v[])
    {
        int menor=v[0];
        
        for (int i = 1; i < v.length; i++) {
            if (menor > v[i])
                menor=v[i];
        }
        
        return menor;        
    }
    
     
     public static void rellenar(int v[], int n)
     {
         for (int i = 0; i < v.length; i++) {
             v[i]=n;
         }
     }
     
     public static void rellenar(int v[], int n, int x)
     {
         if (x<0 || x>=v.length) System.out.println("Índice incorrecto");
         else
           for (int i = x; i < v.length; i++) {
             v[i]=n;
           }
     }
     
}
