/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tema4;

/**
 *
 * @author Profesor
 */
public class Ej18 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int v[]={7,56,89,23,58,9,99,23,44,22};
        
        //a. Sumar el valor 15 a los elementos de las posiciones impares
        // Cuyos índices son pares 0,2,4,6 y 8
        
        int w[]=new int[v.length];
        for (int i = 0; i < v.length; i++) {
            if (i%2==0)
               w[i]=v[i]+15;
            else
               w[i]=v[i];
        }
        
        MiArray.mostrarVector(v);
        MiArray.mostrarVector(w);
        
        //b. A todos los elementos de v se calcula el resto de dividir entre 3
        int t[]=new int[v.length];
        for (int i = 0; i < v.length; i++) {
            t[i]=v[i]%3;            
        }
        
        MiArray.mostrarVector(v);
        MiArray.mostrarVector(t);
        
        
        
        
        
    }
    
}
