/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tema4;

/**
 *
 * @author Profesor
 */
public class Ej4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        double v[]=new double[10];
        System.out.println("Introducción de 10 notas");
        for(int i=0;i<v.length;i++)
            v[i]=Pedir.Double("Dime la nota "+(i+1)+" :");
        
        double suma=0.0;
        for(int i=0;i<v.length;i++)
            suma+=v[i];
        
        double media=suma/10.0;
        int contSup=0,contIgual=0,contInf=0;
        for(int i=0;i<v.length;i++)
            if (v[i]>media) contSup++;
            else if (v[i]==media) contIgual++;
                 else contInf++;
        
        System.out.println("El valor de la media es "+media);
        System.out.println("Hay "+contInf+" notas inferiores a la media");
        System.out.println("Hay "+contIgual+" notas iguales a la media");
        System.out.println("Hay "+contSup+" notas superiores a la media");
    }
    
}
