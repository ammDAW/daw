/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tema4;

/**
 *
 * @author Profesor
 */
public class Ej10 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int v[]={12,4,5,78,45,67,45,66,77,44};
        
        int x=Pedir.entero("Dime un valor: ");
        
        int contSup=0,contIg=0,contInf=0;
        
        for (int i = 0; i < v.length; i++) {
           if (v[i]>x) contSup++;
           else if (v[i]==x) contIg++;
           else contInf++; 
        }
        
        System.out.println("Hay "+contSup+" valores superiores a "+x);
        System.out.println("Hay "+contIg+" valores iguales a "+x);
        System.out.println("Hay "+contInf+" valores inferiores a "+x);
                
    }
    
}
