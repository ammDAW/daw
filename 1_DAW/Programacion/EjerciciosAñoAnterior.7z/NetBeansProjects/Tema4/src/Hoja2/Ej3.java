/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Hoja2;

import tema4.Pedir;

/**
 *
 * @author Profesor
 */
public class Ej3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int v[]=new int[5];
        
        System.out.println("Introducción de un array");
        for(int i=0;i<v.length;i++)
            v[i]=Pedir.entero("Dime el valor "+(i+1)+" : ");
        
        double sumaNeg=0.0f,sumaPos=0.0f;
        int contNeg=0, contPosi=0, contCeros=0;
        
        for(int i=0;i<v.length;i++)
        {    
            if (v[i]>0)
            {
                contPosi++;
                sumaPos+=v[i];
            }
            else if (v[i]<0)
                 {
                   contNeg++;
                   sumaNeg+=v[i];
                 } 
                 else contCeros++;
        }
        
        
        if (contPosi==0)
            System.out.println("No hay valores positivos");
        else
        {            
           double mediaPosi=sumaPos/contPosi;
           System.out.println("La media de los valores positivos es "+ mediaPosi);
        }
        
        if (contNeg==0)
            System.out.println("No hay valores negativos");
        else
        {
           double mediaNeg=sumaNeg/contNeg;        
           System.out.println("La media de los valores negativos es "+ mediaNeg);
        }
        
        
        System.out.println("Hay "+contCeros+" ceros");
        
        
    }
    
}
