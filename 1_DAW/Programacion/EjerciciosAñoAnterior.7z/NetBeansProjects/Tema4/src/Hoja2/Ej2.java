/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Hoja2;

import tema4.Pedir;

/**
 *
 * @author Profesor
 */
public class Ej2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       int v[]=new int[5];
        System.out.println("Introduce por teclado los valores del array");
        for(int i=0;i<v.length;i++)
            v[i]=Pedir.entero("Dime el valor "+(i+1)+" :");
        
        System.out.println("Mostrar por pantalla los valores en Orden Inverso");
        for(int i=v.length-1;i>=0;i--)
            System.out.println(v[i]);
    }
    
}
