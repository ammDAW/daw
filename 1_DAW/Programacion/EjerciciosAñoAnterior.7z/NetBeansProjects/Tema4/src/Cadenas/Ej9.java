/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Cadenas;

import tema4.Pedir;

/**
 *
 * @author Profesor
 */
public class Ej9 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       String s=Pedir.cadena("Dime una cadena y te diré si es una palabra :");
       
       String sMy=s.toUpperCase();
       boolean esPalabra=true;
       for(int i=0; i<s.length();i++)
           if (!(sMy.charAt(i)>='A' && sMy.charAt(i)<='Z'))     // || (s.charAt(i)>='a' && s.charAt(i)<='z')) 
           {
               esPalabra=false;
               break;
           }
       
       System.out.println(s+((esPalabra)?" Es":" No es")+" palabra");
       
       
       //Otra forma
       String abecedario="ABCDEFGHIJKLMNOPQRSTUVWXYZ";
       //El String s ya se ha pedido
       // El String sMy
       
       esPalabra=true;
       for(int i=0; i<sMy.length();i++)
       {
           boolean encontrado=false;             
           for(int j=0; j<abecedario.length(); j++)
               if (sMy.charAt(i)==abecedario.charAt(j))
               {  encontrado=true; break;}
           
           if (!encontrado)
           {esPalabra=false; break;}
       }       
       System.out.println(s+((esPalabra)?" Es":" No es")+" palabra");
       
       //Utilizando el método indexOf
       esPalabra=true;
       for(int i=0; i<sMy.length(); i++)
       {
           if (abecedario.indexOf(sMy.charAt(i)) == -1)
           { 
               esPalabra=false;
               break;
           }
       }
       System.out.println(s+((esPalabra)?" Es":" No es")+" palabra");
       
    }
    
}
