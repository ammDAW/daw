/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Cadenas;

import tema4.Pedir;

/**
 *
 * @author Profesor
 */
public class Ej8 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String texto=Pedir.cadena("Dime un texto y lo invierto: ");
        
        String textoInvertido="";
        for (int i = texto.length()-1; i >=0 ; i--) {
            textoInvertido=textoInvertido + texto.charAt(i);
        }
        
        
        System.out.println("Texto: "+texto+" Invertido: "+textoInvertido);
        System.out.println("Texto: "+texto+" Invertido: "+MiString.invertir(texto));
    }
    
}
