/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Cadenas;

/**
 *
 * @author Profesor
 */
public class Ej13 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String texto="En mi proxima vida, creere en la reencarnacion";
        
        int p=texto.indexOf("creere");
        
        if (p==-1)
            System.out.println("La palabra 'creere' no se encuentra en el texto ");
        else
            System.out.println("La palabra 'creere' SI se encuentra en el texto");
    }
    
}
