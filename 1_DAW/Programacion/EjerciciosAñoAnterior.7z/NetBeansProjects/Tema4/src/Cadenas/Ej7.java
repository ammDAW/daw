/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Cadenas;

import tema4.Pedir;

/**
 *
 * @author Profesor
 */
public class Ej7 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String texto=Pedir.cadena("Dime un texto y te diré dónde se encuentra la última 'p' :");
        
        int p=texto.lastIndexOf('p');
        if (p==-1)
            System.out.println("No hay 'p's en el texto");
        else
            System.out.println("La última 'p' está en la posición : "+(p+1));
    }
    
}
