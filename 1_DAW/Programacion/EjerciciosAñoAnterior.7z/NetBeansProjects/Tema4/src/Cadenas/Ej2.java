/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Cadenas;

import java.util.Scanner;

/**
 *
 * @author Profesor
 */
public class Ej2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner teclado=new Scanner(System.in);
        String cadena;
        
        System.out.println("Dime una cadena y te diré si representa a un número entero");
        cadena=teclado.nextLine();
        
        boolean esNumeroEntero=true;
        for(int i=0; i < cadena.length(); i++)
        {
            if (!(cadena.charAt(i)>='0' && cadena.charAt(i)<='9'))
            {    
                esNumeroEntero=false;
                break;
            }    
        }
        
        if (esNumeroEntero)
            System.out.println(cadena +" representa un número entero");
        else
            System.out.println(cadena+" NO representa un número entero");
        
    }
    
}
