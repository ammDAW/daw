/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Cadenas;

/**
 *
 * @author Profesor
 */
public class Ej4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String texto="Mañana es sabado sabadete y voy a irme a tomar unas copillas por los barrios bajos de Logroño";
        
        texto=texto.toUpperCase();
        
        int contA=0;
        int contVocales=0;
        for (int i = 0; i < texto.length(); i++) {
             if (texto.charAt(i)=='A')
                 contA++;
             if (texto.charAt(i)=='A' || texto.charAt(i)=='E' || texto.charAt(i)=='I' || texto.charAt(i)=='O' || texto.charAt(i)=='U')
                 contVocales++;
        }
        
        System.out.println("En "+texto+" hay "+contA+" aes");
        System.out.println("En "+texto+" hay "+contVocales+" vocales");
                
    }
    
}
