/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Cadenas;

/**
 *
 * @author Profesor
 */
public class Ej6 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String texto="Mañana es sabado sabadete y voy a irme a tomar unas copillas por los barrios bajos de Logroño";
        int contT=0;
        for (int i = 0; i < texto.length(); i++) {
            if (texto.charAt(i)=='t' || texto.charAt(i)=='T')
               contT++;
        }
        
        int arrayT[]=new int[contT];
        
        int j=0;
        String texto1=texto.toUpperCase();
        int p=texto1.indexOf('T');
        while (p!=-1)
        {
            arrayT[j]=p;
            j++;
            p=texto1.indexOf('T',p+1);
        }
        
        System.out.println("Valor del array donde están los índices de las T");
        for (j = 0; j < arrayT.length; j++) {
            System.out.println(arrayT[j]);
        }
        
    }
    
}
