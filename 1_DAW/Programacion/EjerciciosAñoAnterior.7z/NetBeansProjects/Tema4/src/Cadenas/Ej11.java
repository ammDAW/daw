/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Cadenas;

import java.util.Scanner;
import tema4.Pedir;

/**
 *
 * @author Profesor
 */
public class Ej11 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        
       
        String texto=Pedir.cadena("Dime un texto y te diré si es palíndromo: ");
        
        //1. Pasar el texto a minúsculas
        String textoModificado=texto.toLowerCase();
        
        //2. Quitar espacios en blanco
        textoModificado=MiString.quitarEspaciosEnBlanco(textoModificado);
        
        //3. Genero el texto Invertido
        String textoInvertido=MiString.invertir(textoModificado);
        
        //4. Comparo textoInvertido con textoModificado
        if (textoInvertido.equals(textoModificado))
            System.out.println("El texto "+texto+" es palíndromo ");
        else
            System.out.println("El texto "+texto+" No es palíndromo");
          
    }
    
}
