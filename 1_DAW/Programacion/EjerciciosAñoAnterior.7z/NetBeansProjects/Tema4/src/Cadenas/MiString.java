/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Cadenas;

/**
 *
 * @author Profesor
 */
public class MiString {
    public static String invertir(String texto)
    {
        String textoInvertido="";
        for (int i = texto.length()-1; i >=0 ; i--) {
            textoInvertido=textoInvertido + texto.charAt(i);
        }
        
        return textoInvertido;
    }
    
    
    public static String quitarEspaciosEnBlanco(String texto)
    {
        String textoModificado=texto.trim();
                
        String palabras[]=textoModificado.split(" ");
        
        String textoSinEspacios="";
        for (int i = 0; i < palabras.length; i++) {
            textoSinEspacios+=palabras[i];         
        }
 
        return textoSinEspacios;
    }
}
