/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Cadenas;

import tema4.Pedir;

/**
 *
 * @author Profesor
 */
public class Ej10 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //Introducir un texto y volver a mostrarlo sin espacios en blanco
        String texto=Pedir.cadena("Dime un texto: ");
        
        //Eliminar los espacios en la parte de la izqda y de la drcha
        String textoModificado=texto.trim();
        
        //Uso del método split, como dato de entrada se va a utilizar 
        // el espacio en blanco como separador
        //Generará un array de String que no contengan ese separador
        
        String palabras[]=textoModificado.split(" ");
        
        String textoSinEspacios="";
        for (int i = 0; i < palabras.length; i++) {
            textoSinEspacios+=palabras[i]; 
            //textoSinEspacios.concat(palabras[i]);
        }
        
        System.out.println("Texto sin espacios "+textoSinEspacios);
        System.out.print("Texto :'Mi mama me ama' sin espacios es:");
        System.out.println(MiString.quitarEspaciosEnBlanco("Mi mama me ama"));
    }
    
}
