/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Cadenas;

import tema4.Pedir;

/**
 *
 * @author Profesor
 */
public class Ej5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       String t=Pedir.cadena("Dime un texto y te diré si contiene la W: ");
       
              
       int n=t.indexOf('W');
       System.out.println("la 'W' se encuentra en el índice "+n); 
       
       /*
        //System.out.println(t.indexOf('a'));
        int q=t.indexOf('a');
        int p=t.indexOf('a', q+1);
        System.out.println("La primera 'a' está en el índice: " +q);
        System.out.println("La segunda 'a' está en el índice: "+p);
        
        System.out.println("Mostrando los índices de todas las 'a'");
        q=t.indexOf('a');
        while (q!=-1) //Mientras hay aes 'a'
        {
            System.out.println("índice: "+q);
            q=t.indexOf('a', q+1);
        }
        
        String nacho="José Ignacio Valle González";
        System.out.println(nacho);
        int w=nacho.indexOf(' ');
        while(w!=-1)
        {
             nacho=nacho.substring(w+1);
             System.out.println(nacho);
             w=nacho.indexOf(' ');
        }
        
     */   
    }
    
}
