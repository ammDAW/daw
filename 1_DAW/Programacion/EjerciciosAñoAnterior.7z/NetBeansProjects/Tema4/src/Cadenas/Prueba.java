/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Cadenas;

/**
 *
 * @author Profesor
 */
public class Prueba {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String pp="Pepe", qq="Pepe", rr="pepe";
        
        if (pp.equals(qq))
            System.out.println("Iguales");
        else
            System.out.println("Distintos");
        
        if (pp.equals(rr))
            System.out.println("Iguales");
        else
            System.out.println("Distintos");
        
        if (pp.equalsIgnoreCase(rr))
            System.out.println("Iguales");
        else
            System.out.println("Distintos");
        
        
        String g="quiero que lo pases a mayúscula";
        String gG=g.toUpperCase();
        System.out.println(g+" en mayúscula "+gG);
        
        for (int i = 0; i < g.length(); i++) {
            System.out.print(g.charAt(i)+" ");
        }
        
        System.out.println("");
        String h="hola";
        h=h.toUpperCase();
        System.out.println(h);
        
    }
    
}
