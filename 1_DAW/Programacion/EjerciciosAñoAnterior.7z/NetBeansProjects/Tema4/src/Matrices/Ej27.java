/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Matrices;

import tema4.MiArray;

/**
 *
 * @author Profesor
 */
public class Ej27 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //Generosidad de Fátima
        int m[][]={
{1,12,6,5,8,7,9,4,5,3,6,12,5,4,9,10,11,15,2,6,8,12,11,13,14,12,10,11,10,21,10},
{1,12,6,5,8,7,9,4,5,3,4,9,10,11,15,2,6,8,12,11,13,12,14,10,11,10,21,10},
{11,12,6,5,18,17,9,14,5,13,6,12,15,4,9,10,11,15,2,6,8,12,11,13,12,14,10,11,10,21,10},
{11,12,6,5,18,17,14,5,13,6,12,15,4,9,10,11,15,2,6,8,12,11,13,12,14,10,11,10,21,10},
{11,12,6,5,18,17,9,14,5,13,6,12,15,4,9,10,11,15,2,6,8,12,11,13,12,14,10,11,10,21,10},
{21,22,23,24,25,26,27,28,29,30,21,22,23,24,25,26,27,28,29,30,21,22,23,24,25,26,27,28,29,30},
{25,26,26,24,25,26,24,25,27,28,29,30,31,32,30,31,32,31,32,31,32,31,32,32,32,32,32,32,32,32,32},
{25,26,26,24,25,26,24,25,27,28,29,30,31,32,30,31,32,31,32,31,32,31,32,32,32,32,32,32,32,32,32},
{21,22,23,24,25,26,27,28,29,30,21,22,23,24,25,26,27,28,29,30,21,22,23,24,25,26,27,28,29,30},
{11,12,6,5,18,1,9,14,5,13,6,12,15,4,9,10,11,15,2,6,8,12,11,13,12,14,10,11,10,21,10},
{11,12,6,5,18,17,14,5,13,6,12,15,4,9,10,11,15,2,6,8,12,11,13,12,14,10,11,10,21,10},
{1,12,6,5,8,7,9,4,3,5,6,12,5,4,9,1,1,1,2,6,8,1,1,1,2,4,10,1,1,1,1}};
        
        String mes[]={"Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre"};
      
       //a. Cálculo de la temperatura media de todos los meses 
        for(int me=0; me < m.length; me++)
        {
            float sumaTempMes=0;
            for(int dia=0; dia < m[me].length ; dia++)
                sumaTempMes += m[me][dia];
            
            float media=sumaTempMes/m[me].length;
            
            System.out.print("La temperatura media del mes "+mes[me]);
            System.out.println(" es "+media);
        }    
        
        //b. Guardar en 2 arrays
        // El días más frío de cada mes 
        // El día más caluroso de cada mes
        
        int diasCalurosos[]=new int[12];
        int diasFrios[]=new int[12];
        for(int me=0; me < m.length ; me++)
        {
          int calor=Integer.MIN_VALUE;// int calor=m[me][0];
          int pDia=-1;// int pDia=0;
          int frio=m[me][0];
          int fDia=0;
          for(int dia=0; dia < m[me].length; dia++)
          {    
              if (calor < m[me][dia])
              {
                  calor=m[me][dia];
                  pDia=dia;
              }
              if (frio > m[me][dia])
              {
                  frio=m[me][dia];
                  fDia=dia;
              }
          }        
          diasCalurosos[me]=pDia+1;
          diasFrios[me]=fDia+1;
        }
        MiArray.mostrarVector(diasCalurosos);
        MiArray.mostrarVector(diasFrios);
    }
    
    
}
