/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Matrices;

import java.util.Scanner;

/**
 *
 * @author isabel
 */
public class Examen {
    
    public static int pedir(String msg){
        int n;
        Scanner teclado=new Scanner(System.in);
        System.out.print(msg);
        String cadena=teclado.nextLine();
        n=Integer.parseInt(cadena);
        return n;
    }
    
    public static int[][] introduceTablaLiguilla(int partidos){
        int m[][]=new int[10][3];
        for(int fila=0; fila<m.length; fila++){
            System.out.println("Equipo nº "+(fila+1));   
            for(int col=0;col <2; col++)
                m[fila][col]=pedir("Dime un número de partidos en columna "+(col+1)+":   ");
        }    
        
        for(int fila=0; fila<m.length; fila++){
            m[fila][2]=partidos - (m[fila][0] + m[fila][1]);
        }        
        
        return m;    
    }
    
    
    public static void generaTablaLiguilla(int m[][])
    {
        for(int equipo=0;equipo<m.length;equipo++){
            m[equipo][0]*=3;
            m[equipo][1]=0;
        }
        
    }
    
    public static void mostrarMatriz(int m[][])
    {
       for(int i=0;i<m.length;i++){
            System.out.println("\n_______");
            System.out.print("|");
            for(int col=0;col<m[i].length;col++)
                System.out.print(m[i][col]+"|");
        }
        System.out.println("\n_______\n"); 
    }
    
    
    public static int[] generaPuntuacionTotal(int m[][])
    {
        int v[]=new int[m.length];
        
        for(int fila=0;fila<m.length;fila++)
            v[fila]=m[fila][0]+m[fila][1]+m[fila][2];
        
        return v;
    }
}
