/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Matrices;

import tema4.MiArray;
import tema4.Pedir;

/**
 *
 * @author Profesor
 */
public class Ejercicio {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Introducir una matriz de enteros por teclado
        // Nº filas: 3 y Nº columnas: 2
        /*
        int m[][]=new int[3][2];
        System.out.println("Dime el valor de una matriz de enteros de 3x2");
        for(int fila=0; fila<m.length; fila ++ )
        { 
            System.out.println("Fila nº "+(fila+1));
            for(int col=0; col<m[fila].length; col++)
                m[fila][col]=Pedir.entero("Dime un número: ");        
        }
        */
        
        System.out.println("Introducción de una matriz de 3x2");
        int m[][]=MiArray.pedirMatriz(3, 2);
        System.out.println("Matriz introducida:");
        MiArray.mostrarMatriz(m);
        /*
        for(int fila=0;fila<m.length;fila++)
        {
            System.out.println("Fila nº "+(fila+1));
            for(int col=0;col<m[fila].length;col++)
                System.out.print(m[fila][col]+"\t");
            
            System.out.println("");
        }
        */
        
    }
    
}
