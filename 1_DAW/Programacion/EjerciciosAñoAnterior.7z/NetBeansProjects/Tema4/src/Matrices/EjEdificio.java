/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Matrices;

/**
 *
 * @author Profesor
 */
public class EjEdificio {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int edificio[][]={{4,10,7}, {1,2,3,4,4}, {1,2,6}, {4,3,7}};
        
        //Vamos a mostrar el número de personas de la planta 2ª (1)
        //En cada piso de la planta 2ª
        System.out.println("Personas empadronadas en los pisos de la 2ª Planta");
        int plantas=1;
        for(int piso=0; piso < edificio[plantas].length ; piso++)
            System.out.println(edificio[plantas][piso]);
        
        System.out.println("Personas empadronadas en los pisos de la 3ª Planta");
        plantas=2;
        for(int piso=0; piso < edificio[plantas].length ; piso++)
            System.out.println("Planta : 3 Piso: "+(piso+1)+" hay "+ edificio[plantas][piso]);
        
        
        System.out.println("Personas empadronadas en todo el Edificio");
        for(int planta=0; planta < edificio.length ; planta++)
        {
            System.out.println("Planta "+(planta+1));
            for(int piso=0; piso < edificio[planta].length ; piso++)
                System.out.println(edificio[planta][piso]+" personas");
        }    
        
        //Cálculo del número total de personas en el edificio
        int sumaPersonas=0;
        for(int planta=0; planta < edificio.length ; planta++)
        {    
            for(int piso=0; piso < edificio[planta].length ; piso++)
            {    
                sumaPersonas += edificio[planta][piso];
            }    
        }
        System.out.println("El total de personas es: "+sumaPersonas);
        
        //Cálculo de las personas empadronadas en cada planta
        for(int planta=0; planta < edificio.length ; planta++)
        {
            int personasPorPlanta=0;
            for(int piso=0; piso < edificio[planta].length ; piso++)
                personasPorPlanta += edificio[planta][piso];
            
            System.out.println("En la planta "+(planta+1)+" hay "+personasPorPlanta+" personas");
        }
        
        
        //Cálculo del piso donde se encuentran más personas 
        //empadronadas de la 4ª Planta y cuántas son.
        int my4Planta=Integer.MIN_VALUE; // int my4Planta=edificio[3][0];
        int posiPiso=0;
        for(int piso=0; piso < edificio[3].length ; piso++)
            if (my4Planta < edificio[3][piso])
            {
                my4Planta=edificio[3][piso];
                posiPiso=piso;
            }
        
        System.out.print("De la 4ª Planta el piso con mayor número ");
        System.out.print("de personas empadronadas es "+(posiPiso+1));
        System.out.println(" con "+my4Planta+" personas.");
        
        //Cálculo del piso donde se encuentran menos personas 
        //empadronadas de la 4ª Planta y cuántas son.
        int mn4Planta=Integer.MAX_VALUE; // int mn4Planta=edificio[3][0];
        int posPiso=0;
        for(int piso=0; piso < edificio[3].length ; piso++)
            if (mn4Planta > edificio[3][piso])
            {
                mn4Planta=edificio[3][piso];
                posPiso=piso;
            }
        
        System.out.print("De la 4ª Planta el piso con mayor número ");
        System.out.print("de personas empadronadas es "+(posPiso+1));
        System.out.println(" con "+mn4Planta+" personas.");
        
        
        //Cálculo de la planta y el piso con más personas empadronadas
        // del Edificio y el número de personas
        int myEdificio=edificio[0][0];
        int pPlanta=0, pPiso=0;
        
        for(int planta=0; planta < edificio.length ; planta++)
            for(int piso=0; piso < edificio[planta].length ; piso++)
                if (myEdificio < edificio[planta][piso])
                {
                    myEdificio=edificio[planta][piso];
                    pPlanta=planta;
                    pPiso=piso;
                }
        
        System.out.print("Del Edificio completo el piso con mayor número ");
        System.out.print("de personas empadronadas es "+(pPiso+1));
        System.out.print(" en la planta "+(pPlanta+1));
        System.out.println(" con "+myEdificio+" personas.");
        
    int x=10; 
    //Se busca si existe al menos un piso con x personas empadronadas    
    boolean encontrado=false;
    for (int planta=0; planta < edificio.length ; planta++)
    {
        for(int piso=0; piso < edificio[planta].length ; piso++)
            if (edificio[planta][piso]==x)
            {
                encontrado=true;
                break;
            }
        
        if (encontrado) break;
    }
    
    if (encontrado)
            System.out.println("Hay al menos un piso con "+x+" personas");
    else
            System.out.println("No hay ningún piso con "+x+" personas");
        
           
        
    }
    
}
