/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package paqAnimal;

/**
 *
 * @author Profesor
 */
public class Animal {
    protected int peso;
    protected String fecha;

    public Animal(int peso, String fecha) {
        this.peso = peso;
        this.fecha = fecha;
    }
    
    
    
}
