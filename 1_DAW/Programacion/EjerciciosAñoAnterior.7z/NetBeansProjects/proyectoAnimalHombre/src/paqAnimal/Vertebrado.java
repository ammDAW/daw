/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package paqAnimal;

/**
 *
 * @author Profesor
 */
public class Vertebrado extends Animal {
    protected int numVertebras;

    public Vertebrado(int numVertebras, int peso, String fecha) {
        super(peso, fecha);
        this.numVertebras = numVertebras;
    }
    
    public Vertebrado(Vertebrado otro){
        /*
        super(otro.peso,otro.fecha);
        this.numVertebras=numVertebras;
        */
        this(otro.numVertebras,otro.peso,otro.fecha);
    }
    
    
}
