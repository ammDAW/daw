/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package paqAnimal;

import java.util.ArrayList;

/**
 *
 * @author Profesor
 */
public class Hombre extends Vertebrado{
private String nombre;
private boolean vivo;
private int numHijos=0;
private ArrayList datosHijos;

public Hombre(String nombre, boolean vivo, ArrayList datosHijos, int numVert, int peso, String f) {
super(numVert, peso, f);
this.nombre = nombre;
this.vivo = vivo;
this.datosHijos = new ArrayList(datosHijos);
}
public Hombre(String nombre, boolean vivo, ArrayList datosHijo, int numVert, int peso, int d, int m, int anio ){
   this(nombre,vivo,datosHijo,numVert,peso,new String(d+" "+m+" "+anio));
}

}
