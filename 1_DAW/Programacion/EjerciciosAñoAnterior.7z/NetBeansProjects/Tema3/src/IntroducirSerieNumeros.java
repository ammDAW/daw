
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Profesor
 */
public class IntroducirSerieNumeros {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
         //Introducir una serie de números hasta el 0
        // Se desea mostrar esos números e indicar cuántos han sido
        
        //Con While
        
        //1. Leer n
        //2. while (condicion)
        //3.       Bloque de código del while
        //4.       Leer n en el bucle
        
        Scanner teclado=new Scanner(System.in);
        String cadena;
        
        int cont=0; //contador de los números distintos de 0
        int n;
        
        System.out.print("Dime un número :");
        cadena=teclado.nextLine();
        n=Integer.parseInt(cadena);
                
        while (n != 0)
        {
            cont++; //incrementa el contador de los números distintos de 0
            System.out.println(n + " es distinto de 0");
            
            System.out.print("Dime un número :");
            cadena=teclado.nextLine();
            n=Integer.parseInt(cadena);        
        }
        
        System.out.println("Se han introducido "+cont+" números distintos de 0");
        
        //Con do-while
        
        //1. do
        //2.       Leer n en el bucle
        //3,       if (condicion_salida) break; 
        //4.       Bloque de código del bucle
        //5. while(condicion_permanencia);
 

        System.out.println("Realizado con do-while");
        cont=0;
        do{
            //1.Leer n
            System.out.print("Dime un número: ");
            cadena=teclado.nextLine();
            n=Integer.parseInt(cadena);
            //2. Condicion de salida
            if (n==0) break;
            //3. Resto del bloque de código
            cont++;
            System.out.println(n+" es distinto de 0");            
        }while(n!=0);
        System.out.println("Se han introducido "+cont+" números en la serie");
        
      //Con for
      // for(inicialización_variables; condición_permanencia ; incrementos)
      System.out.print("Dime un número: ");
      cadena=teclado.nextLine();
      n=Integer.parseInt(cadena);
            
      for(cont=0; n!=0 ;)
      {
          cont++;
          System.out.println(n+" es distinto de 0");
          
          //Debo seguir leyendo n
          System.out.print("Dime un número: ");
          cadena=teclado.nextLine();
          n=Integer.parseInt(cadena);
      }
      
      
    }
    
}
