
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Profesor
 */
public class While {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //Introducir una serie de números hasta el 0
        // Se desea mostrar esos números e indicar cuántos han sido
        
        Scanner teclado=new Scanner(System.in);
        String cadena;
        
        int cont=0; //contador de los números distintos de 0
        int n;
        
        System.out.print("Dime un número :");
        cadena=teclado.nextLine();
        n=Integer.parseInt(cadena);
                
        while (n != 0)
        {
            cont++; //incrementa el contador de los números distintos de 0
            System.out.println(n + " es distinto de 0");
            
            System.out.print("Dime un número :");
            cadena=teclado.nextLine();
            n=Integer.parseInt(cadena);        
        }
        
        System.out.println("Se han introducido "+cont+" números distintos de 0");
    }
    
}
