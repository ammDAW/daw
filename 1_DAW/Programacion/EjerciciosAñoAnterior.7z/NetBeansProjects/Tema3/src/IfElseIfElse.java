
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Profesor
 */
public class IfElseIfElse {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       Scanner teclado=new Scanner(System.in);
       
        System.out.println("Dime tu nota: ");
        String cadena=teclado.nextLine();
        int nota=Integer.parseInt(cadena);
        
        if (nota<0 || nota>10)
            System.out.println("Nota incorrecta");
        else
            if (nota<3)
                System.out.println("MD");
            else 
                if (nota<5)
                    System.out.println("INSF");
                else
                    if (nota<6)
                        System.out.println("SF");
                    else 
                        if (nota<7)
                            System.out.println("B");
                        else
                            if (nota<9)
                                System.out.println("NT");
                            else
                                System.out.println("SB");
       
    }
    
}
