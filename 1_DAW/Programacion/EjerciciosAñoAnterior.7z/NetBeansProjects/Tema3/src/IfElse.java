/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Profesor
 */
public class IfElse {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int edad=14;
        if (edad>=18)
            System.out.println("Es mayor de edad y puede votar");
        else
            System.out.println("Es menor de edad y no puede votar");
        
        System.out.println("FIN");
    }
    
}
