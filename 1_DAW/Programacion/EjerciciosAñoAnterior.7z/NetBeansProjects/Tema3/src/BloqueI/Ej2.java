/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BloqueI;

import java.util.Scanner;

/**
 *
 * @author Profesor
 */
public class Ej2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
      Scanner teclado=new Scanner(System.in);
      String cadena;
      double base, altura;
      
      //Leer la base
        System.out.print("Dime la base: ");
        cadena=teclado.nextLine();
        base=Double.parseDouble(cadena);
        
      //Leer la altura
        System.out.print("Dime la altura: ");
        cadena=teclado.nextLine();
        altura=Double.parseDouble(cadena);
      
        int perimetro=(int)(2*base+2*altura);
        System.out.println("El perímetro es "+perimetro);
    }
    
}
