/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BloqueI;

/**
 *
 * @author Profesor
 */
public class Ej1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
      int x=243;
      int y=243*243;
      
        System.out.println("El cuadrado de "+x+" es "+y);
      int z;
        z=(int)Math.pow(243,2); //z=Math.pow(x,2);
        
        System.out.println("El cuadrado de "+x+" es "+z);
    }
    
}
