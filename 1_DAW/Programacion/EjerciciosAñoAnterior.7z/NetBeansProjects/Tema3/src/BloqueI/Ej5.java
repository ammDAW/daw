/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BloqueI;

import java.util.Scanner;

/**
 *
 * @author Profesor
 */
public class Ej5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //Conversión de grados Centígrados a Fahrenheit
        Scanner teclado=new Scanner(System.in);
        String cadena;
        int gradosC;
        
        System.out.println("Dime los grados centígrados:");
        cadena=teclado.nextLine();
        gradosC=Integer.parseInt(cadena);
        
        int gradosF=(int)(9.0/5.0*gradosC +32);
        
        System.out.println("Grados Fahrenheit ="+gradosF);
        
    }
    
}
