/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BloqueI;

import java.util.Scanner;

/**
 *
 * @author Profesor
 */
public class Ej4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner teclado=new Scanner(System.in);
        String cadena;
        double dineroCentimos;
        
        System.out.println("Dime el dinero que tienes (inferior a 100€):");
        cadena=teclado.nextLine();
        dineroCentimos=Double.parseDouble(cadena);
        
        int dinero=(int)dineroCentimos;
        
        dineroCentimos-=dinero; //Se coge la parte decimal
        dineroCentimos*=100; //Las dos cifras decimales se pasan a la parte entera
        int centimos=(int)dineroCentimos; // Se extrae la parte entera 
        //centimos++;
        
        int b50=dinero/50;
        dinero%=50; //dinero=dinero%50;
        int b20=dinero/20;
        dinero%=20;
        int b10=dinero/10;
        dinero%=10;
        int b5=dinero/5;
        dinero%=5;
        int mn2=dinero/2;
        int mn1=dinero%2;
        
        
        System.out.println("Céntimos :"+centimos);
        int mn50Ct=centimos/50;
        centimos=centimos%50;
        int mn20Ct=centimos/20;
        centimos=centimos%20;
        int mn10Ct=centimos/10;
        centimos=centimos%10;
        int mn5Ct=centimos/5;
        centimos=centimos%5;
        int mn2Ct=centimos/2;
        int mn1Ct=centimos%2;
                
        System.out.println("Billetes de 50€ :"+b50);
        System.out.println("Billetes de 20€ :"+b20);
        System.out.println("Billetes de 10€ :"+b10);
        System.out.println("Billetes de 5€ :"+b5);
        System.out.println("Monedas de 2€ :"+mn2);
        System.out.println("Monedas de 1€ :"+mn1);
        System.out.println("Monedas de 50 Céntimos:"+mn50Ct);
        System.out.println("Monedas de 20 Céntimos:"+mn20Ct);
        System.out.println("Monedas de 10 Céntimos:"+mn10Ct);
        System.out.println("Monedas de 5 Céntimos:"+mn5Ct);
        System.out.println("Monedas de 2 Céntimos:"+mn2Ct);
        System.out.println("Monedas de 1 Céntimos:"+mn1Ct);
        
    }
    
}
