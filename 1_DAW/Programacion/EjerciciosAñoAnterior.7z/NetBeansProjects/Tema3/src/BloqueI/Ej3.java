/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BloqueI;

import java.util.Scanner;

/**
 *
 * @author Profesor
 */
public class Ej3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
      Scanner teclado=new Scanner(System.in);
      String cadena;
      int a,b,c;
      
      double p;
      /*
      p=(a+b+c)/2.0;
        System.out.println("p ="+p);
      
      int area=(int)Math.sqrt(p);  
      */
      
      //Leer a
        System.out.print("Dime un lado: ");
        cadena=teclado.nextLine();
        a=Integer.parseInt(cadena);
        
      //Leer b
        System.out.print("Dime el otro lado: ");
        cadena=teclado.nextLine();
        b=Integer.parseInt(cadena);
        
      //Leer c
        System.out.print("Dime el tercer lado: ");
        cadena=teclado.nextLine();
        c=Integer.parseInt(cadena);
        
        p=(a+b+c)/2.0; //Es necesario dividirlo entre 2.0 para que p tenga decimales correctos
        
        double area=Math.sqrt(p*(p-a)*(p-b)*(p-c));
        
        System.out.println("Área del triángulo :"+area);
      
    }
    
}
