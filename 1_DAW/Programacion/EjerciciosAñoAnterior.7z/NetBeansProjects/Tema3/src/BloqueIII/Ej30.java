/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BloqueIII;

import Metodos.Mates;

/**
 *
 * @author Profesor
 */
public class Ej30 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        for(int i=1,contPrimos=0; contPrimos<10 ; i++)
            if (Mates.primo(i))
            {
                System.out.println("El número "+i+" es primo");
                contPrimos++;
            }
    }
    
}
