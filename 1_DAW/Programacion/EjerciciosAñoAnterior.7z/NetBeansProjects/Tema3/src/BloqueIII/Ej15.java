/* To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BloqueIII;

import java.util.Scanner;

/**
 *
 * @author Profesor
 */
public class Ej15 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Cálculo del cociente y resto por el método:
        // restas sucesivas
        
        Scanner teclado=new Scanner(System.in);
        String cadena;
        
        System.out.print("Dime el dividendo: ");
        cadena=teclado.nextLine();
        int dividendo=Integer.parseInt(cadena);
        
        System.out.print("Dime el divisor: ");
        cadena=teclado.nextLine();
        int divisor=Integer.parseInt(cadena);
        
        int cont=0; //cuenta las veces que se puede restar
        /*
        //Con while
        while(dividendo>=divisor) //while (dividendo-divisor>=0)
        {
            dividendo-=divisor; //dividendo=dividendo - divisor;
            cont++;
        }
        int resto=dividendo;
        System.out.println("Cociente: "+cont+"\tResto: "+resto);
        */
        // Con for
        /*
        for(cont=0; dividendo>=divisor;cont++)
            dividendo-=divisor;
        */        
        
        for(cont=0; dividendo>=divisor; dividendo-=divisor, cont++);
        int resto=dividendo;
        System.out.println("Cociente: "+cont+"\tResto: "+resto);
        
        
    }
    
}
