/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BloqueIII;

import Metodos.Mates;
import java.util.Scanner;

/**
 *
 * @author Profesor
 */
public class Ej21 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner teclado=new Scanner(System.in);
        String cadena;
        int n;
        
        System.out.print("Dime el valor del que quieres calcular el factorial ");
        cadena=teclado.nextLine();
        n=Integer.parseInt(cadena);
        
        /*
        long fact=1;
        for(int i=1;i<=n;i++)
            fact*=i;
        */
        
        long fact=Mates.factorial(n);
        
        System.out.println("Factorial de "+n+" es "+fact);
    }
    
}
