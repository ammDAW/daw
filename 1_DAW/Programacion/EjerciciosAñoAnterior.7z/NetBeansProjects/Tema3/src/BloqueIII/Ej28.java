/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BloqueIII;

import Metodos.Mates;
import Metodos.Pedir;
import java.util.Scanner;

/**
 *
 * @author Profesor
 */
public class Ej28 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
                
        int n=Pedir.entero("Dime un número y te diré si es primo :");
        
        if (Mates.primo(n))
            System.out.println("El número "+n+" es primo");
        else
            System.out.println("El número "+n+" NO es primo");
        
        /*
        if (n==1) System.out.println("El número 1 NO es primo");
        else
         {
              boolean esPrimo=true;
              for(int i=2;i<n;i++)
              {    
                  if (n%i==0)
                  {
                      esPrimo=false;
                      break;
                  }
              }
              
              if (esPrimo) // if (esPrimo==true) 
                  System.out.println("El número "+n+" es PRIMO");
              else
                  System.out.println("El número "+n+" NO es PRIMO");
          
         }
       */
    }
    
}
