/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BloqueIII;

import java.util.Scanner;

/**
 *
 * @author Profesor
 */
public class Ej4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //Leer a y b
        //Mostrar en orden descendente a - b
        //Con do-while
        
        Scanner teclado=new Scanner(System.in);
        String cadena;
        int a,b;
        
        
        System.out.print("Dime el primer número: ");
        cadena=teclado.nextLine();
        a=Integer.parseInt(cadena);
        
        System.out.print("Dime el segundo número: ");
        cadena=teclado.nextLine();
        b=Integer.parseInt(cadena);
        
       if (a<b)
       {    
        int aux=a;
        a=b;
        b=aux;
       }
       
       int i=a;       
       do{
           System.out.println(i);
           i--;
       }while(i>=b);  
        
    }
    
}
