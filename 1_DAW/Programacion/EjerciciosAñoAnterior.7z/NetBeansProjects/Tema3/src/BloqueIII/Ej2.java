/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BloqueIII;

import java.util.Scanner;

/**
 *
 * @author Profesor
 */
public class Ej2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //Introducir 10 números enteros e indicar cúantos 0 se han introducido
        //while
        Scanner teclado=new Scanner(System.in);
        String cadena;
        int n;
        
        int cont0=0;
        int i=1; //contador del bucle
        while(i<=10)
        {
            System.out.print("Dime el número: ");
            cadena=teclado.nextLine();
            n=Integer.parseInt(cadena);
            
            if (n==0)
                cont0++;
            
            i++;
        }
        System.out.println("De los 10 números, hay "+cont0+" ceros");
        
        //do-while
        cont0=0;
        i=1;
        do{
            System.out.print("Dime el número: ");
            cadena=teclado.nextLine();
            n=Integer.parseInt(cadena);
            
            if (n==0)
                cont0++;
            
            i++;            
        }while(i<=10);
        System.out.println("De los 10 números, hay "+cont0+" ceros");
        
        //for
        for(cont0=0,i=1; i<=10; i++)
        {
            System.out.print("Dime el número: ");
            cadena=teclado.nextLine();
            n=Integer.parseInt(cadena);
            
            if (n==0)
                cont0++;            
        }
        
        System.out.println("De los 10 números, hay "+cont0+" ceros");
    }
    
}
