/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BloqueIII;

/**
 *
 * @author Profesor
 */
public class Ej1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //Suma de las potencias de 2, desde 0 al 10
        
        //while
        int suma=0;
        int i=0;
        while(i<=10)
        {
            suma=suma+(int)Math.pow(2, i);
            i++;
        }
        System.out.println("La suma es "+suma);
        
        //do-while
        suma=0;
        i=0;
        do{
            suma+=(int)Math.pow(2, i);
            i++;
        }while(i<=10);
        System.out.println("La suma es "+suma);
        
        //for
        for(i=0,suma=0;i<=10;i++)
            suma+=(int)Math.pow(2, i);
        
        //for(i=0,suma=0; i<=10; suma+=(int)Math.pow(2,i), i++);
        
        System.out.println("La suma es "+suma);
        
    }
    
}
