/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BloqueIII;

/**
 *
 * @author Profesor
 */
public class Ej10 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Obtener las tres soluciones de la ecuación
        //x3 – 4x2 +x + 6 =0
        //Sabiendo que x está en el rango -10 a 10
        
        int contSol=0;
        for(int x=-1000; x<=1000; x++)
        {
            if (Math.pow(x,3) - 4*Math.pow(x,2) + x + 6 == 0)
            {
                System.out.println("Solución: "+x);
                contSol++;
                if (contSol==3) break;
            }    
        }
        
        //De otra forma sin utilizar break
        contSol=0;
        for(int x=-1000; x<=1000 && contSol <3 ; x++)
        {
            if (Math.pow(x,3) - 4*Math.pow(x,2) + x + 6 == 0)
            {
                System.out.println("Solución: "+x);
                contSol++;                
            }    
        }
        
    }
    
}
