/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BloqueIII;

import java.util.Scanner;

/**
 *
 * @author Profesor
 */
public class Ej3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Calcula la media de 5 números enteros introducidos por teclado
        Scanner teclado=new Scanner(System.in);
        String cadena;
        int n;
        
        int suma=0;
        for(int i=1;i<=5;i++)
        {
            System.out.print("Dime el número "+i+": ");
            cadena=teclado.nextLine();
            n=Integer.parseInt(cadena);
            
            suma+=n;
        }
        double  media=suma/5.0;
        System.out.println("La media de los 5 números "+media);
        
        
        
        
    }
    
}
