/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BloqueIII;

import java.util.Scanner;

/**
 *
 * @author Profesor
 */
public class Ej16 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Introducir un número entero positivo  por teclado
        // Determinar las cifras que tiene
        Scanner teclado=new Scanner(System.in);
        String cadena;
        
        System.out.print("Dime un número entero positivo: ");
        cadena=teclado.nextLine();
        int n=Integer.parseInt(cadena);
       
        int aux=n;
        //while
        int cifras=1;
        while (n>=10)
        {
            n/=10;
            cifras++;
        }
        
        System.out.println("Tiene "+cifras+" cifras");
        
        //do-while
        n=aux;
        cifras=1;
        do{
            n/=10;
            if (n==0) break;
            cifras++;
        }while(n>=10);
        System.out.println("Tiene "+cifras+" cifras");
        
    }
    
}
