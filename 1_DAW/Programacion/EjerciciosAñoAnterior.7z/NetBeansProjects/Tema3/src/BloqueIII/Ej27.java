/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BloqueIII;

import Metodos.Mates;
import Metodos.Pedir;
import java.util.Scanner;

/**
 *
 * @author Profesor
 */
public class Ej27 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
              
        int n=Pedir.entero("Dime un número: ");        
        int m=Pedir.entero("Dime otro número: ");
        
        if ((Mates.sumaDivisores(n)-n==m)  &&  (Mates.sumaDivisores(m)-m==n) )
            System.out.println("Los números "+n+" y "+m+" son AMIGOS");
        else
            System.out.println("Los números "+n+" y "+m+" NO son AMIGOS");
    }
    
}
