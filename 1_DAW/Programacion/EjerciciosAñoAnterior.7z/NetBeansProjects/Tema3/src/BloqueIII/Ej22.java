/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BloqueIII;

import Metodos.Mates;

/**
 *
 * @author Profesor
 */
public class Ej22 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        System.out.println("FACTORIAL DE LOS 5 PRIMEROS NÚMEROS");
        for(int i=1;i<=5;i++)
        {
            long f=Mates.factorial(i);
            System.out.println("Factorial de "+i+" es "+f);
        }
    }
    
}
