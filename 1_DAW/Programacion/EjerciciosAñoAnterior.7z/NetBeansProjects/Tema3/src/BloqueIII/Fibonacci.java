/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BloqueIII;

import java.util.Scanner;

/**
 *
 * @author Profesor
 */
public class Fibonacci {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Introducir un número entero positivo por teclado n
        // Muestra toda la serie Fibonacci hasta el término n
        
        Scanner teclado=new Scanner (System.in);
        
        System.out.print("Dime el último término de la serie : ");
        String cadena=teclado.nextLine();
        int n=Integer.parseInt(cadena);
        
        if (n==1) System.out.print("0");
        else if (n==2) System.out.println("\t1");
        else
        {
         System.out.print("0\t1");
         int valor1=0, valor2=1;
         int i=3;
         while(i<=n)
         {
            int valor3=valor1+valor2; //valor3= 0 + 1
            System.out.print("\t"+valor3);
            
            valor1=valor2; // valor1= 1
            valor2=valor3; // valor2= 0 +1 =1 
            
            i++;
         }
        }
    }
    
}
