/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BloqueIII;

import java.util.Scanner;

/**
 *
 * @author Profesor
 */
public class Ej6 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //Introducir 10 números enteros
        //Sumar los pares, indicar cuántos hay
        //Media de los impares
        
        Scanner teclado=new Scanner(System.in);
        String cadena;
        int n;
        
        int contPares=0,sumaPares=0;
        int contImpares=0;
        double sumaImpares=0.0;
        
        for(int i=1;i<=10;i++)
        {
            System.out.print("Dime un número: ");
            cadena=teclado.nextLine();
            n=Integer.parseInt(cadena);
            
            if (n%2==0)
            {
                contPares++;
                sumaPares+=n;
            }
            else
            {
                contImpares++;
                sumaImpares+=n;
            }
        }
        System.out.println("De los 10 números, se han introducido: ");
        System.out.println(contPares+" pares");
        System.out.println("La suma de los pares es "+sumaPares);
        System.out.println("La media de los impares es "+sumaImpares/contImpares);
        
    }
    
}
