/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BloqueIII;

import java.util.Scanner;

/**
 *
 * @author Profesor
 */
public class Ej9 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //Mostrar n múltiplos de 4
        Scanner teclado=new Scanner(System.in);
        
        System.out.print("Dime cuántos múltiplos de 4 quieres :");
        String cadena=teclado.nextLine();
        int n=Integer.parseInt(cadena);
        
        //while
        int i=1; // i va de 1 a n
        while (i<=n)
        {
            System.out.println(i*4);
            i++;
        }
        
        //Otra forma
        i=1;
        int cont4=0;
        while (cont4<n)
        {
            if (i%4==0)
            {
                System.out.println(i+ " es múltiplo de 4");
                cont4++;
            }
            
            
            i++;
        }
        
        //for
        cont4=0;
        for(i=1;cont4<n;i++)
        {
            if (i%4==0)
            {
                System.out.println(i+" es múltiplo de 4");
                cont4++;
            }
        }
        
        //do-while
        cont4=0;
        i=1;
        do{
            if (i%4==0)
            {
                System.out.println(i+" es múltiplo de 4");
                cont4++;
            }
            i++;
        }while(cont4<n);
        
    }
    
}
