/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BloqueIII;

import Metodos.Mates;
import java.util.Scanner;

/**
 *
 * @author Profesor
 */
public class Ej25 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner teclado=new Scanner(System.in);
        String cadena;
        
        int n;
        System.out.print("Dime un número :");
        cadena=teclado.nextLine();
        n=Integer.parseInt(cadena);
        /*
        int contDivisores=0;
        for(int i=1;i<=n;i++)
            if (n%i==0)
                contDivisores++;
        */
        int contDivisores=Mates.contaDivisores(n);
        System.out.println("El número "+n+" tiene "+contDivisores+" divisores");
        
        /*
        int sumaDivisores=0;
        for(int i=1;i<=n;i++)
            if (n%i==0)
                sumaDivisores+=i;
        */
        System.out.println("La suma de los divisores de "+n+" es "+Mates.sumaDivisores(n));
        
        
        
    }
    
}
