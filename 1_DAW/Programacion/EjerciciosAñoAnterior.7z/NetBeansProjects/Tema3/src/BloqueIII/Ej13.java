
/* To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BloqueIII;

import java.util.Scanner;

/**
 *
 * @author Profesor
 */
public class Ej13 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Introducir el valor del límite
        // Determinar el último término de la serie
        // 1+2+3+4+....+n donde la suma de la serie sea inferior al límite
        
        Scanner teclado=new Scanner(System.in);
        String cadena;
        
        System.out.print("Dime el límite : ");
        cadena=teclado.nextLine();
        int limite=Integer.parseInt(cadena);
        
        int suma=0;
        int i=1;
        while (suma<limite)
        {
            suma+=i;
            i++;
        }
        if (suma==limite) i--;
        else i-=2;
        
        System.out.println("el término es "+i);       
        
    }
    
}
