/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BloqueIII;

/**
 *
 * @author Profesor
 */
public class Ej18 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // dinero 6000€
        // interes 2%
        // Objetivo: 
        // Conseguir 12000€ 
        // ¿años necesarios para conseguir el doble de 6000€?
        
        double dinero=6000;
        double interes=0.02;
        
        int anios;
        for(anios=0; dinero<12000; anios++){
            dinero+=dinero*interes;
        } 
        
        System.out.println("Dinero conseguido :"+dinero+"€ en "+anios+" años");
    }
    
}
