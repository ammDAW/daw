/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BloqueII;

import java.util.Scanner;

/**
 *
 * @author Profesor
 */
public class Ej7 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       Scanner teclado=new Scanner(System.in);
        String cadena;
        double tiempo;
        
        System.out.println("Dime el tiempo de la llamada: ");
        cadena=teclado.nextLine();
        tiempo=Double.parseDouble(cadena);
        
        /*
        double coste;
        if (tiempo<=3)
            coste=0.25;
        else
            coste=0.25+(tiempo-3)*0.06;
        */
        
        /*
        double coste=0.25;
        if (tiempo >3)
            coste+=(tiempo-3)*0.06;
        
        */
        
        /*
        double coste=(tiempo<=3)?0.25:0.25+(tiempo-3)*0.06;        
        System.out.println("El coste de la llamada es: "+coste);
        */
        System.out.println("El coste de la llamada es: "+((tiempo<=3)?0.25:0.25+(tiempo-3)*0.06));
        
        
    }
    
}
