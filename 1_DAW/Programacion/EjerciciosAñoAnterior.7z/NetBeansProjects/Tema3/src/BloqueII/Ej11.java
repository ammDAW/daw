/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BloqueII;

import java.util.Scanner;

/**
 *
 * @author Profesor
 */
public class Ej11 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner teclado=new Scanner(System.in);
        String cadena;
        double km;
        char letra; //letra será 'T' a milla terrestre o 'M' a milla marina
        
        System.out.print("Dime los Kms: ");
        cadena=teclado.nextLine();
        km=Double.parseDouble(cadena);
        
        System.out.print("¿A qué lo quieres convertir (T o M): ");
        cadena=teclado.nextLine();
        letra=cadena.charAt(0);
        
        if (letra=='T')
        {
            double millaTerrestres=km/1.609;
            System.out.println(km +"Kms corresponden a "+millaTerrestres+" Millas Terrestres");
        }
        else 
            if (letra=='M')
            {
              double millaMarina=km/1.852;
              System.out.println(km +"Kms corresponden a "+millaMarina+" Millas Marinas");
            }
            else 
                System.out.println("Letra incorrecta...");
        
        //Introducir un valor boolean por teclado
        cadena=teclado.nextLine();
        boolean w=Boolean.valueOf(cadena);
        System.out.println(w);
        
    }
    
}
