/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BloqueII;

import java.util.Scanner;

/**
 *
 * @author Profesor
 */
public class EjLetras {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner teclado=new Scanner(System.in);
        String cadena;
        char letra;
        
        System.out.println("Dime una letra: ");
        cadena=teclado.nextLine();
        letra=cadena.charAt(0);
        
        //1. Comprobar si está en mayúscula
        if (letra>='A' && letra<='Z') // if (letra>=65 && letra<=90)
            System.out.println(letra+" está en mayúscula");
        
        //2.Comprobar si está en minúscula
        if (letra>='a' && letra<='z') // if (letra>=97 && letra<=122)
            System.out.println(letra+" está en minúscula");
        
        //3. Comprobar si la letra está en mayúscula o minúscula
        if ((letra>='A' && letra<='Z')) // if (letra>=65 && letra<=90)
            System.out.println(letra+" está en mayúscula");
        else 
            if (letra>='a' && letra<='z') // if (letra>=97 && letra<=122)
               System.out.println(letra+" está en minúscula");
            else 
                System.out.println("Error...");
        
        //4. Comprobar si la letra está en mayúscula, minúscula o es dígito
        if ((letra>='A' && letra<='Z')) // if (letra>=65 && letra<=90)
            System.out.println(letra+" está en mayúscula y su minúscula es "+(char)(letra+32));
        else 
            if (letra>='a' && letra<='z') // if (letra>=97 && letra<=122)
               System.out.println(letra+" está en minúscula y su mayúscula es "+(char)(letra-32));
            else
                if (letra>='0' && letra<='9')
                    System.out.println(letra+" es un dígito");
                else 
                    System.out.println("Error...");

        
        
    }
    
}
