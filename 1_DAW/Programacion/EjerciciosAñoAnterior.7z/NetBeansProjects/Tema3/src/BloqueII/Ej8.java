/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BloqueII;

import java.util.Scanner;

/**
 *
 * @author Profesor
 */
public class Ej8 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner teclado=new Scanner(System.in);
        String cadena;
        int a,b;
        
        System.out.println("Dime el coeficiente a: ");
        cadena=teclado.nextLine();
        a=Integer.parseInt(cadena);
        
        System.out.println("Dime el coeficiente b: ");
        cadena=teclado.nextLine();
        b=Integer.parseInt(cadena);
        
        if (a==0 && b==0)
            System.out.println("Solución indeterminada");
        else
            if (a==0)
                System.out.println("Solución imposible");
            else
                System.out.println("Solución: "+(-b/a));
        
        
    }
    
}
