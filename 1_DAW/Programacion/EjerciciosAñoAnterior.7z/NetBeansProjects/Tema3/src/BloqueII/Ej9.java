/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BloqueII;

import java.util.Scanner;

/**
 *
 * @author Profesor
 */
public class Ej9 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner teclado=new Scanner(System.in);
        String cadena;
        int a,b,c;
        
        System.out.println("Dime el coeficiente a: ");
        cadena=teclado.nextLine();
        a=Integer.parseInt(cadena);
        
        System.out.println("Dime el coeficiente b: ");
        cadena=teclado.nextLine();
        b=Integer.parseInt(cadena);

        System.out.println("Dime el coeficiente c: ");
        cadena=teclado.nextLine();
        c=Integer.parseInt(cadena);
        
        double D=Math.pow(b,2)-4*a*c;
        
        if (D<0)
            System.out.println("No hay solución real");
        else
            if (D==0)
                System.out.println("Solo tiene una solución ="+ (-b/2*a));
            else
            {
                double x1=(-b+D)/(2*a);
                double x2=(-b-D)/(2*a);
                System.out.println("Las dos soluciones son "+x1+" y "+x2);
            }
    }
    
}
