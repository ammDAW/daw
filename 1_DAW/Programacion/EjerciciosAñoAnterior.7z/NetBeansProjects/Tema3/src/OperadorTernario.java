
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Profesor
 */
public class OperadorTernario {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       Scanner teclado=new Scanner(System.in);
       /*
        System.out.println("Dime tu edad: ");
        String cadena=teclado.nextLine();
        int edad=Integer.parseInt(cadena);
        
        String respuesta;
        if (edad>=18)
            respuesta="Eres mayor de edad y puedes votar";
        else
            respuesta="Eres menor de edad y NO puedes votar";
        
        System.out.println(respuesta);
       
        respuesta=(edad>=18)?"Eres mayor de edad y puedes votar":"Eres menor de edad y NO puedes votar";
        System.out.println(respuesta);
        
        System.out.println((edad>=18)?"Eres mayor de edad":"Eres menor de edad");
        */
        int i=0; //Muestra del 0 al 4
        while (i<=4)
            System.out.println(i++);
        
        i=0;
        while (i<=4) //Muestra del 1 al 5
            System.out.println(++i);
        
        
        
        
        System.out.println("Hola");
        
    }
    
}
