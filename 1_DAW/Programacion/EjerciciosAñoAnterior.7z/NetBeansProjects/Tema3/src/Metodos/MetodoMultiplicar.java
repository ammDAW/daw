/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Metodos;

import java.util.Scanner;

/**
 *
 * @author Profesor
 */
public class MetodoMultiplicar {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner teclado=new Scanner(System.in);
        System.out.print("Dime un número:");
        String cadena=teclado.nextLine();
        int n=Integer.parseInt(cadena);
        
        MetodoMultiplicar.multiplica(n);
        MetodoMultiplicar.multiplica(7);
        
        int y=10;
        MetodoMultiplicar.multiplica(y);
        int x=3;
        MetodoMultiplicar.multiplica(x);
        
        System.out.println("");
        System.out.println("");
        System.out.println("");

        for(int i=10;i<=100;i++)
            MetodoMultiplicar.multiplica(i);
        
        
    }
    
    public static void multiplica(int x){
        System.out.println("TABLA DE MULTIPLICAR DE "+x);
        for(int i=1;i<=10;i++)
            System.out.println(x+"x"+i+"="+(x*i));
    }
}
