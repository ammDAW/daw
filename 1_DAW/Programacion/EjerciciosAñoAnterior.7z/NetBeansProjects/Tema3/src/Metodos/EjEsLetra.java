/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Metodos;

/**
 *
 * @author Profesor
 */
public class EjEsLetra {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        char ch='T';
        
        if (Mates.esLetra(ch)) // Mates.esLetra(ch)==true
            System.out.println(ch +" es una letra");
        else
            System.out.println(ch+" NO es una letra");
        
        System.out.println("T en minúscula es "+Mates.pasarAMinuscula(ch));
        
        char g=Mates.pasarAMinuscula(ch);
        System.out.println("T en minúscula es "+g);
        
        System.out.println("El 9 es "+Mates.esDigito('9'));
        
        if (Mates.esDigito('9'))
            System.out.println("El 9 es un dígito");
        else
            System.out.println("El 9 no es dígito");
        
        
    }
    
}
