/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Metodos;

import java.util.Scanner;

/**
 *
 * @author Profesor
 */
public class MetodosEstaticosEj1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Método sumaImparesN
        //Dato de entrada: int n //n primeros números impares
        //Dato de salida: int  //La suma de esos impares
        
        Scanner teclado=new Scanner(System.in);
        
        System.out.print("Dime cuántos números impares: ");
        String cadena=teclado.nextLine();
        int n=Integer.parseInt(cadena);
        
        int suma=Mates.sumaImparesN(n);
        System.out.println("La suma de los "+n+" primeros números impares es: "+suma);
        
        suma=Mates.sumaImparesN(5);
        System.out.println("La suma de los 5 primeros números impares es: "+suma);
        
        for(int i=1;i<=10;i++)
            System.out.println("La suma de los "+i+" primeros números impares es "+Mates.sumaImparesN(i));
        
        
        Mates.mostrarMensaje(10);
        
        System.out.println("El menor de 7 y 9 es "+Mates.minimo(7, 9));
        
        Mates.betweenNandM(20,40);
        
        
        
    }
    
}
