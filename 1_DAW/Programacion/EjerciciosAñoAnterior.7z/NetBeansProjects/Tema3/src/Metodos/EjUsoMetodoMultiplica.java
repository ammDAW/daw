/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Metodos;

/**
 *
 * @author Profesor
 */
public class EjUsoMetodoMultiplica {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
       int x=9;
       Mates.multiplica(x);
       
       //2 números enteros
       int a=12;
       int b=20;
       //Muestra las tablas de multiplicar de a hasta b 
       for(int i=a; i<=b;i++)
           Mates.multiplica(i);
       
       //Cuál es el valor mayor de a y b
       int c;
       c=Mates.mayor(a, b);
       System.out.println("El mayor de "+a+" y "+b+" es "+c);
       
       System.out.println("El mayor de "+a+" y "+b+" es "+Mates.mayor(a, b));
        
       
    }
    
}
