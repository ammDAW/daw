/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Metodos;

import java.util.Scanner;

/**
 *
 * @author Profesor
 */
public class EjMetodoLongitudArea {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner teclado=new Scanner(System.in);
        String cadena;
        char caracter;
        
        
        //Con while--- Obligar a que el radio sea positivo
        System.out.print("Dime el valor del radio: ");
        cadena=teclado.nextLine();
        int radio=Integer.parseInt(cadena);
        
        while (radio<=0)
        {
            System.out.println("Error, el radio ha de ser positivo");
            System.out.print("Dime el valor del radio: ");
            cadena=teclado.nextLine();
            radio=Integer.parseInt(cadena);           
        }
        
        //System.out.println("Radio correcto, valor positivo :"+radio);
        //Obligar a que una letra sea 'a' o 'l'
        //Con do-while
        do{
            System.out.println("Dime 'a' si quieres el área del círculo o 'l' si quieres la longitud de la circuferencia :");
            cadena=teclado.nextLine();
            caracter=cadena.charAt(0);
            // if (caracter=='a' || caracter=='A' || caracter=='l' || caracter=='L')
            if (Character.toUpperCase(caracter)=='A' || Character.toLowerCase(caracter)=='l') 
                break;
            
            System.out.println("Has introducido mal la letra, vuelve a introducirla");
        }while(caracter!='a' && caracter!='A' && caracter!='l' && caracter!='L');
        
        //System.out.println("La letra correcta es: "+caracter);        
        
        double s=Mates.longitudAreaCirculo(radio, caracter);
        System.out.println("La solución es: "+s);
        
        System.out.println("La solución es: "+Mates.longitudAreaCirculo(radio, caracter));
    }
    
}
