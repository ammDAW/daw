/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Metodos;

/**
 *
 * @author Profesor
 */
public class EjesPar {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.out.println(Mates.esPar(8));
        
        if (Mates.esPar(8)==true)
            System.out.println("El número 8 es par");
        else
            System.out.println("El número 8 es impar");
        
        if (Mates.esPar(8))// if (Mates.esPar(8)==true)
            System.out.println("El número 8 es par");
        else
            System.out.println("El número 8 es impar");
        
        
        if (! Mates.esPar(8)) // if (Mates.esPar(8)==false)
            System.out.println("El número 8 es impar");
        else
            System.out.println("El número 8 es par");
        
        System.out.println(Mates.esMayuscula('o'));
        
        
    }
    
}
