/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Metodos;

import java.util.Scanner;

/**
 *
 * @author Profesor
 */
public class Ej14 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner teclado=new Scanner(System.in);
        String cadena;
        
        int p1,p2;// punto p
        int q1,q2;// punto q
        
        System.out.println("Dime las coordenadas del punto p");
        System.out.print("Dime el valor de x de p: ");
        cadena=teclado.nextLine();
        p1=Integer.parseInt(cadena);
        System.out.print("Dime el valor de y de p: ");
        cadena=teclado.nextLine();
        p2=Integer.parseInt(cadena);
        
        System.out.println("Dime las coordenadas del punto q");
        System.out.print("Dime el valor de x de q: ");
        cadena=teclado.nextLine();
        q1=Integer.parseInt(cadena);
        System.out.print("Dime el valor de y de q: ");
        cadena=teclado.nextLine();
        q2=Integer.parseInt(cadena);
        
        double d=Mates.distanciaEuclidea(p1, p2, q1, q2);
        System.out.println("Distancia entre p y q es :"+d);        
        
    }
    
}
