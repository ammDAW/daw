/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Metodos;

/**
 *
 * @author Profesor
 */

//Mates es una librería que contiene métodos o funciones matemáticas propias
public class Mates {
    
    //multiplica muestra la tabla de multiplicar de n
    public static void multiplica(int n){
        System.out.println("TABLA DE MULTIPLICAR DE "+n);
        for(int i=1;i<=10;i++)
            System.out.println(n+"x"+i+"="+(n*i));
    }
    
    public static int mayor(int x,int y){
        int my;
        if (x>y)
            my=x;
        else
            my=y;
        
        return my;
    }
    
    public static int sumaImparesN(int n)
    {
        int sumaImpares=0;
        int contImpares=0;
        
        for(int i=1; contImpares<n; i++)
        {
            if (i%2 !=0) //i%2==1
            {
                sumaImpares+=i;
                contImpares++;
            }
        }
        
        return sumaImpares;
    }
    
    
    public static void mostrarMensaje(int n)
    {
       for(int i=1; i<=n; i++)
            System.out.println("Método ejecutándose");
    }
    
    public static int minimo(int x,int y)
    {
        int mn=(x<y)?x:y;
        return mn;
    }
    
    public static void betweenNandM(int n,int m)
    {
        if (n>m) //es necesario intercambiar los valores de n y m
        {
            int aux=n;
            n=m;
            m=aux;
        }
        
        for(int i=n;i<=m;i++)
            System.out.print(i+"\t");
        
        System.out.println("");
    }
    
    public static int doble(int x){
        int y=2*x;
        return y;
    }
    
    
    public static double longitudAreaCirculo(int r, char letra)
    {
        double salida;
           if (letra=='a')
               salida=Math.PI * Math.pow(r,2);
           else
               salida=2*Math.PI*r;
           
        return salida;
    }
    
    public static boolean esPar(int n){
        boolean result;                               
           result=(n%2==0)?true:false;  
        return result;
    }
    
    public static boolean esMayuscula(char c)
    {
        boolean result;
          if (c>='A' && c<='Z')
              result=true;
          else
              result=false;
        return result;
    }
    
    public static boolean esMinuscula(char c)
    {
        boolean result;
          if (c>='a' && c<='z')
              result=true;
          else
              result=false;
        return result;
    }
    
    public static boolean esLetra(char c)
    {
        boolean result;
          if ( Mates.esMayuscula(c) || Mates.esMinuscula(c)) //En un método se puede llamar a otro método de la misma clase o de otra
              result=true;
          else 
              result=false;
        return result;
    }
    
    public static char pasarAMinuscula(char c)
    {
        char cAdevolver;
        if (Mates.esMayuscula(c))
            cAdevolver= (char)(c+32);
        else
            cAdevolver=c;
        return cAdevolver;
    }
    
    public static boolean esDigito(char c)
    {
        boolean result=false;
          if (c>='0' && c<='9')
              result=true;
          
        return result;
    }
    
    public static double distanciaEuclidea(int x1, int y1, int x2, int y2){
        double dist;
         dist=Math.sqrt(Math.pow(x2-x1,2)+Math.pow(y2-y1,2));
        return dist;
    }
    
    public static long factorial(int x)
    {
        long f=1;
          for(int i=1;i<=x;i++)
              f*=i;
        return f;
    }
    
    public static int contaDivisores(int n)
    {
        int contDivisores=0;
        for(int i=1;i<=n;i++)
            if (n%i==0)
                contDivisores++;
        return contDivisores;
    }
    
    public static int sumaDivisores(int n)
    {
        int sumaDivisores=0;
        for(int i=1;i<=n;i++)
            if (n%i==0)
                sumaDivisores+=i;
        return sumaDivisores;
    }
    
    public static boolean primo(int n)
    {
        if (n==1) return false;
        else
         {
              boolean esPrimo=true;
              for(int i=2;i<n;i++)
              {    
                  if (n%i==0)
                  {
                      esPrimo=false;
                      break;
                  }
              }
              if (esPrimo==true) return true;
              else return false;
              // return esPrimo;   
         }
    }
}
