/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto_refuerzo_tema_5;

/**
 *
 * @author Profesor
 */
public class Clase1 {
    private int prop=0;

    public Clase1(int valor) {
        this.prop=valor;
    }

    public int getProp() {
        return this.prop;
    }
    
    
    
}
