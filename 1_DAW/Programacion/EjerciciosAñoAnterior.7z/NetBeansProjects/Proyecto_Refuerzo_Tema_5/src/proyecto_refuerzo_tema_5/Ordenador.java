/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto_refuerzo_tema_5;

/**
 *
 * @author Profesor
 */
public class Ordenador {
   
    
    public void precio(int y)
    {
        System.out.println("Un valor que es "+y);
    }
}
