/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto_refuerzo_tema_5;

/**
 *
 * @author Profesor
 */
public class Proyecto_Refuerzo_Tema_5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       /* 
        Clase1 obj1=new Clase1(7);
        System.out.println("Obj1 ="+obj1.getProp());
        
        Clase1 obj2=new Clase1(9);
        System.out.println("Obj1 ="+obj1.getProp());
        System.out.println("Obj2 ="+obj2.getProp());
        
        obj2=obj1;
        System.out.println("Obj1 ="+obj1.getProp());
        System.out.println("Obj2 ="+obj2.getProp());
        */
       
       Ordenador sobremesa;
       Ordenador portatil;
       sobremesa=new Ordenador();
       sobremesa.precio(900);
       
       portatil=new Ordenador();
       portatil.precio(1100);
       
       portatil=sobremesa;
       
       sobremesa=null;
       
       portatil.precio(800);
       //sobremesa.precio(8);
       
    }
    
}
