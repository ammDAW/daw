/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package paqueteWho;

import paqueteHora.Hora;

public class WhoMsg {
    private String mensaje;
    Hora hora;
    private static String telefono="+34 777223344";
    private static String nombre;

    //b.ii.1
    public WhoMsg(String mensaje, Hora hora) {
        this.mensaje = mensaje;
        this.hora = hora;
        WhoMsg.nombre="Perico";
    }
    //b.ii.2
    public WhoMsg(String mensaje, int h, int min)
    {
        //this(mensaje,new Hora(h,min);
        this.mensaje=mensaje;
        this.hora=new Hora(h,min);
    }

    //b.iii.
    public String getMensaje() {
        return mensaje;
    }

    public Hora getHora() {
        return hora;
    }

    public static String getTelefono() {
        return telefono;
    }

    public static String getNombre() {
        return nombre;
    }

    public void setMensaje(String mensaje) {
        this.mensaje = mensaje;
    }

    public void setHora(Hora hora) {
        this.hora = hora;
    }

    public static void setTelefono(String telefono) {
        WhoMsg.telefono = telefono;
    }

    public static void setNombre(String nombre) {
        WhoMsg.nombre = nombre;
    }
    
    //b.iv.
    @Override
    public String toString()
    {
        return WhoMsg.telefono+"\t ~"+WhoMsg.nombre+"\n"+this.mensaje+"\t"+this.hora;
    }
    
    public boolean equals(String mensaje, Hora hora){
        if (this.mensaje.equalsIgnoreCase(mensaje) && this.hora.equals(hora))
            return true;
        else
            return false;
       // if (this.mensaje.equals(mensaje) && this.hora.getH()==hora.getH() && this.hora.getMin()==otra.hora.getMin())
    }
    
    public boolean equals(WhoMsg otro)
    {
        return this.equals(otro.mensaje, otro.hora);
    }
    
    public boolean equals(String mensaje, int h, int min){
        return this.equals(mensaje, new Hora(h,min));
    }
    
    public WhoMsg clone()
    {
        return new WhoMsg(this.mensaje, this.hora.addMin());
    }
    
}
