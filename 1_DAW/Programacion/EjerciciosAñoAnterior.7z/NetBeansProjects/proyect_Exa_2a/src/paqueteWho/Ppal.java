/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package paqueteWho;

import paqueteHora.Hora;

/**
 *
 * @author Profesor
 */
public class Ppal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //c.i.
        Hora h1=new Hora(12,89); //Salida: Minutos incorrectos 
        //c.ii.
        Hora h2=new Hora(12,48);
        //c.iii
        Hora h3=new Hora();
        //c.iv
        Hora h4=new Hora(h2);
        //c.v
        try{
            h4.setMin(67);
        } catch(IllegalArgumentException t) {
           System.out.println(t.getMessage()); //Salida: Minutos Incorrectos
        }
        //c.vi
        System.out.println("h1 ="+h1); //Salida: h1=0:0        
        System.out.println("h2 ="+h2); //Salida: h2=12:48
        System.out.println("h3 ="+h3); //Salida: h3=0:0
        System.out.println("h4 ="+h4); //Salida: h4=12:48
        //c.vii
        WhoMsg w1=new WhoMsg("Hola a todos",h4);
        //c.viii
        System.out.println("w1="+w1); //Salida: +34 777223344 ~Perico
                                      //        Hola a todos  12:48
                                      
        //c.ix
        WhoMsg w2=new WhoMsg("Bienvenido",12,24);
        //c.x.
        WhoMsg.setNombre("Chris");
        //c.xi.
        WhoMsg w3=w2.clone(); // WhoMsg w3=new Hora(w2.clone());
        //c.xii.
        System.out.println("w1="+w1);
         //Salida: +34 777223344 ~Chris
         //        Hola a todos  12:48
        System.out.println("w2="+w2);
         //Salida: +34 777223344 ~Chris
         //        Bienvenido     12:24
        System.out.println("w3="+w3);
         //Salida: +34 777223344 ~Chris
         //        Bienvenido     12:24
         //c.xiii
         if (w1.equals(w2)) 
             System.out.println("Los mensajes son iguales");
         else
             System.out.println("Los mensajes son distintos");
        //Salida: Los mensajes son distintos
        //c.xiv.
         if (w3.equals(w2.getMensaje(),w2.hora.addMin())) 
             System.out.println("Los mensajes son iguales");
         else
             System.out.println("Los mensajes son distintos");
         //Salida: Los mensajes son distintos
         //c.xv.
         if (w3.equals("Bienvenido", new Hora(12,25))) 
             System.out.println("Los mensajes son iguales");
         else
             System.out.println("Los mensajes son distintos");
         //Salida: Los mensajes son distintos
         //c.xvi
         System.out.println("Hora de w1="+w1.hora);
         //System.out.println("Hora de w1="+w1.getHora());
         //Salida: 12:48
    }
    
}
