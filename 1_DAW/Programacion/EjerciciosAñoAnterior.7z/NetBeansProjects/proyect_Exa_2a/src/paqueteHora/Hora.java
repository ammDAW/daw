/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package paqueteHora;

public class Hora {
    private int h,min;
    
    //a.ii.1.
    public Hora(int h, int min){
        try{
            this.setH(h);
            this.setMin(min);
        }
        catch(IllegalArgumentException ty){
            this.h=0;
            this.min=0;
            System.out.println(ty.getMessage());
        }
    }
    
    //a.ii.2.
    public Hora(){
        this(0,0);  // this.h=this.min=0;
    }
    
    //a.ii.3.
    public Hora(Hora otra){
        this(otra.h,otra.min); //this.h=otra.h; this.min=otra.min;
    }
    
    //a.iii.
    public int getH() {
        return this.h;
    }

    public int getMin() {
        return this.min;
    }

    public void setH(int h) throws IllegalArgumentException {
        if (h<0 || h>23)
            throw new IllegalArgumentException("Hora incorrecta");
        this.h = h;
    }

    public void setMin(int min) throws IllegalArgumentException{
        if (min<0 || min>59)
            throw new IllegalArgumentException("Minutos Incorrectos");
        this.min = min;
    }
    
    //a.iv.

    @Override
    public String toString() {
        return  this.h +" : "+ this.min;
    }
    
    public void finalize(){
        System.out.println(this+" se ha destruído");
    }
    
    public boolean equals(Hora otra){
        return (this.h==otra.h && this.min==otra.min);
    }
    
    public Hora addMin()
    {
        Hora otra=new Hora(this);
        otra.min++;
        if (otra.min==60)
        {
            otra.min=0;
            otra.h++;
            if (otra.h==24) 
                otra.h=0;
        }
        return otra;
    }
}
