/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package paqueteHora;

/**
 *
 * @author Profesor
 */
public class Proyect_Exa_2a {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       Hora h1=new Hora(23,23);
       Hora h2=new Hora(89,89);
       Hora h3=new Hora();
       Hora h4=new Hora(h1);
       
        System.out.println("h1 ="+h1);
        System.out.println("h2 ="+h2);
        System.out.println("h3 ="+h3);
        System.out.println("h4 ="+h4);
        
        try{
            h1.setMin(67);
        } catch(IllegalArgumentException e)
        {
            System.out.println(e.getMessage());
        }
        System.out.println("h1 ="+h1);
        
        Hora h6=new Hora(h1.addMin());
        System.out.println("h6="+h6);
    }
    
}
