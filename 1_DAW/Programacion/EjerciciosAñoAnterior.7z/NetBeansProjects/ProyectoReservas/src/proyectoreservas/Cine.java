/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package proyectoreservas;

import java.util.ArrayList;

/**
 *
 * @author Alumno
 */
public class Cine {
    private Reserva[] reservas=new Reserva[20];
    private String nombre;
    private int numReservas=0;

    public Cine(String nombre) {
        this.nombre = nombre;
    }

    public Reserva[] getReservas() {
        return reservas;
    }

    
    public String getNombre() {
        return nombre;
    }

    public void setReservas(Reserva reservas[]) throws IllegalArgumentException{
        if (reservas.length>10)
            throw new IllegalArgumentException("Error, hay más de 10 reservas");
        this.reservas = reservas;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    @Override
    public String toString() {
        String cadena="Cine{\nNombre= " + this.nombre+" \nReservas:";
        for(int i=0;i<this.reservas.length;i++)
        {
            if (this.reservas[i]!=null)
            { 
              if (this.reservas[i] instanceof ReservaEstandar)  
                cadena+="\nReserva Estandard ="+this.reservas[i].toString();
              else
                cadena+="\nReserva Especial ="+this.reservas[i].toString();
            }
        }
        return cadena+"\n}";
    }
    
    public int nuevaReserva(Reserva reserv)
    {
        if (this.reservas.length==10)
            return -1;
        for (int i=0;i<this.reservas.length;i++)
        {
            if (this.reservas[i]!=null)
            {    
                reserv.setId(i+1);
                this.reservas[i]=reserv;
                this.numReservas++;
                break;
            }    
        }
        return 0;
    }
    
    public void cancelarReserva(int id)
    {
       boolean encontrada=false;    
    
       for (int i=0;i<this.reservas.length;i++)
       {    
        if (this.reservas[i].getId()==id)
        {    
            this.reservas[i]=null;  
            this.numReservas--;
            encontrada=true;
            break;
        }   
       }     
        if (encontrada) System.out.println("Reserva borrada con éxito");
         else System.out.println("Esa reserva con el número "+id+" no existe");
                
    }
    
    public int caculoReservas()
    {
        int totalPrecio=0;        
        for(Reserva reserv: this.reservas)
        {           
            totalPrecio+=reserv.getPrecio();
        }
        return totalPrecio;
    }
    
    public void mostrarReservas()
    {
        System.out.println("Listado de Reservas");
        int i=1;
        for(Reserva reserv: this.reservas)
        {
           if (reserv != null)
           {    
            if (reserv instanceof ReservaEstandar)
                System.out.println(i+" Reserva Estandard ="+reserv);
            else
                System.out.println(i+" Reserva Especial ="+reserv);    
            i++;
           } 
        }
        
        System.out.println("Total de reservas "+this.numReservas);
    }
    
    
}
