/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package proyectoreservas;

/**
 *
 * @author Profesor
 */
public class Ppal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
      
      //Se crea un nuevo cine cuyo nombre es Rex  
      Cine c=new Cine("Rex");
      
      //Se crean 2 Reservas para posteriormente inlcuirlas al cine
      ReservaEstandar r1=new ReservaEstandar("Juan","Guzman");
      ReservaEspecial r2=new ReservaEspecial("DESC0001","Dani","Mtnez");
      
      
      
      //Se muestran los datos de la reserva nº 2
      System.out.println(r2);
      
     //De momento, el cine está sin reservas 
     System.out.println(c);
     
     //Se añade la reserva nº 1, puede ser que las reservas estén agotadas
     if (c.nuevaReserva(r1)!=-1) System.out.println("Reserva realizada con éxito");
     else System.out.println("Las reservas están agotadas");
     
     
     
        System.out.println(c.getReservas());
        /*
      c.mostrarReservas();
      
      
     /* 
     //Comprobación de que se ha incluído la reserva nº 1
     System.out.println(c);
     
     /*
     //Se incluye otra reserva, la nº 2
     if (c.nuevaReserva(r2)!=-1) System.out.println("Reserva realizada con éxito");
     else System.out.println("Las reservas están agotadas");
     System.out.println(c);
     
     
     //Se incluye otra reserva, la nº 3
     if (c.nuevaReserva(new ReservaEspecial("DESC0005","Cristian","Sarmiento"))!=-1) 
         System.out.println("Reserva realizada con éxito");
     else System.out.println("Las reservas están agotadas");
     System.out.println(c);
     
     /*
     //Se muestran todas las reservas del cine c
     c.mostrarReservas();
      
      /*
     //Se cancela la reserva con nº 2
     c.cancelarReserva(2);
       
     
     //Se comprueba que la reserva nº 2 no está en las reservas del cine
     c.mostrarReservas();
       
     
     //Se incluye otra reserva, la nº 4
     if (c.nuevaReserva(new ReservaEspecial("DESC0001","Narciso","Andrade"))!=-1) 
         System.out.println("Reserva realizada con éxito");
     else System.out.println("Las reservas están agotadas");
     
     //Se comprueba que existen 3 reservas, la n1 1, 3 y la 4
     System.out.println(c);
     /*
     //Calcula el precio total 
     System.out.println("Precio Total "+c.caculoReservas());
      */
    }
}
