/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package proyectoreservas;

/**
 *
 * @author Profesor
 */
public class ReservaEspecial  extends Reserva{
    private String descuento;

    public ReservaEspecial(String descuento, String nombre, String apellidos) throws IllegalArgumentException{
        super(nombre, apellidos);
        if (descuento.toUpperCase().equals("DESC0001") || descuento.toUpperCase().equals("DESC0005") )
          this.descuento = descuento;
        else
            throw new IllegalArgumentException("Error, código de descuento incorrecto");
    }
    
    
    @Override
    public int getPrecio(){
        if (this.descuento.equals("DESC0001")) return super.precio-2;
        else return super.precio-5;
    }

    @Override
    public String toString() {
        return  super.toString()+ " Descuento=" + this.descuento + " Precio Total= "+this.getPrecio()+"€";
    }
    
    
}
