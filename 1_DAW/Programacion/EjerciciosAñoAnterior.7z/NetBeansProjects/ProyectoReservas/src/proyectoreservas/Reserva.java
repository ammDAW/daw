/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package proyectoreservas;

/**
 *
 * @author Profesor
 */
public abstract class Reserva {       
    protected String nombre;
    protected String apellidos;
    protected final int precio=8;
    //El id ha ser un número asignado conforme se añada la reserva al cine
    protected int id=0; 
            
    public Reserva(String nombre, String apellidos) {
        this.nombre = nombre;
        this.apellidos = apellidos;        
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
    
    
    public String getNombre() {
        return nombre;
    }

    public String getApellidos() {
        return apellidos;
    }

    public abstract int getPrecio();

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    @Override
    public String toString() {
        return "Id ="+this.id+" Nombre=" + this.nombre + " " + this.apellidos + " Precio=" + precio + "€";
    }
      
    
}
