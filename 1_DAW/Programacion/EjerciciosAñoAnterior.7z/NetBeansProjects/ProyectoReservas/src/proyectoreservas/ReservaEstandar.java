/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package proyectoreservas;

/**
 *
 * @author Profesor
 */
public class ReservaEstandar extends Reserva {

    public ReservaEstandar(String nombre, String apellidos) {
        super(nombre, apellidos);
    }
    
    
    @Override
    public int getPrecio(){ return super.precio;}
}
