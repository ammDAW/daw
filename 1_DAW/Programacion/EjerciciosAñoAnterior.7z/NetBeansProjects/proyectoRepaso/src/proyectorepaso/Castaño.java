/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyectorepaso;

/**
 *
 * @author Profesor
 */
public abstract class Castaño {
    protected int edad;
    protected String nombre;

    public Castaño(int edad, String nombre) {
        this.edad = edad;
        this.nombre = nombre;
    }
    
    public abstract void mostrarEdad();
    
    public void mostrarNombre(){
        System.out.println("Nombre "+this.nombre);
    }
}
