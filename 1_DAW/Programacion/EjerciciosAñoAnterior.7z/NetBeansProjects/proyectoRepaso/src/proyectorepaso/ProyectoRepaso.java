/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyectorepaso;

import java.util.Scanner;

/**
 *
 * @author Profesor
 */
public class ProyectoRepaso {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
      /*  
        //Introducir 10 números enteros por teclado
        // Se guardarán en un array
        // Indicar las posiciones de aquellos números en el array
        // que terminen en 4
        
        Scanner teclado=new Scanner(System.in);
        String cadena;
        int n;
        int vector[]=new int[10];
        
        
       for(int i=0;i<=9;i++)
       {    
        n=0;   
        boolean entero=false;
        while(!entero)
        {    
         try{ 
          System.out.print("Dime un número entero: ");
          cadena=teclado.nextLine();
          n=Integer.parseInt(cadena);
          entero=true;
         }catch(NumberFormatException e){
          System.out.println("Error, no has introducido un número entero");
         }
        }
        vector[i]=n;
       }
       
       
       for(int m: vector)
       {  
           String strm=String.valueOf(m);
           int longitud=strm.length();
           char ultimaLetra=strm.charAt(longitud -1);
           if (ultimaLetra=='4')
               System.out.println(m);
       }    
         
      */
      
      
      
    }
    
}
