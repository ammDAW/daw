/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyectorepaso;

/**
 *
 * @author Profesor
 */
public class HeredaCastaño extends Castaño {

    public HeredaCastaño(int edad, String nombre) {
        super(edad, nombre);
    }
    
    @Override
    public void mostrarEdad(){
        System.out.println(this.edad);
    }
    
    public void metodoPropioClaseHija(){
        System.out.println("Soy un método de la HeredaCastaño");
    }
}
