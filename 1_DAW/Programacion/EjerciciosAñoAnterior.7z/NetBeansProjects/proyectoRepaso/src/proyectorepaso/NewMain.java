/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyectorepaso;

/**
 *
 * @author Profesor
 */
public class NewMain {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
      /*  
       HeredaCastaño hijo=new HeredaCastaño(18,"Javier");
       
       hijo.mostrarNombre();
       hijo.mostrarEdad();
       
       Castaño padre=hijo;
       padre.mostrarNombre();
       padre.mostrarEdad();
       
       Castaño luna=new HeredaCastaño(67,"La luna");
       luna.mostrarEdad();
       luna.mostrarNombre();
       
       ((HeredaCastaño)luna).metodoPropioClaseHija();
       */
      
        System.out.println("Dime el codigo del pántano y te diré su nombre: ");
        int n=3;
        switch(n)
        {
            case 1: System.out.println("Pantano Alfonso XII");break;
            case 2: case 3: case 4: System.out.println("Pantanos Bajos");break;
            case 5: System.out.println("Pantano de Santomera"); break;
            default: System.out.println("Pantano de La Cierva");
        }
                
       
       
    }
    
}
