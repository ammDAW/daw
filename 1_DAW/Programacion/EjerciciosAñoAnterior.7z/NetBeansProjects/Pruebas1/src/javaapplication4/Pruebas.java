/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication4;

import	java.util.Vector;
/**
 *
 * @author Paqui Elena
 */
public class Pruebas {
 
/**	
* Clase	con métodos de utilidad	sobre Arrays de	cadenas	de caracteres	
*
*/		
    //	Atributos	de	la	clase		
    private	Vector<String>	elements;		
    /**	
    *	Constructor		
    */		
    public Pruebas(String[] data){		
        //	Verificamos	que	la	lista	tenga	valores		
        if	((data	== null) || (data.length == 0))	{
            throw	new	IllegalArgumentException();		
        }		
        this.elements =	new Vector<String>();		
            for	(String	element	:  data){		
                elements.addElement(element);		
            }		
    }		

    /**	
    *	@return	Devuelve la cadena que	tiene	más	caracteres	
    */		
    public String getMaxLength(){
        String max ="";
        String	element;
        for(int	i=0;i<elements.size();i++){
            element=elements.get(i);
            if (element.length() > max.length()){
                max	=	element;
            }		
        }		

       return	max;		
    }		
		
    /**	
    *	@return	Devuelve	la	suma	de	la	longitud	de	todas	las	cadenas	
    */		
    public	int	getTotalLength(){		
    int	total	=   0;		
    String	cadena;		
        for	(int	i	=	0;	i	<	elements.size();	i++)	{
            cadena=elements.get(i);
            total	=total	+	cadena.length();
        }		
        return	total;					
    }		
			
    /**	
    *	@param	searched	Cadena	buscada	
    *	@return	Devuelve	la	posición	de	un	elemento	dentro	del	array	
    *	@throws	java.util.NoSuchElementException	Si	el	elemento	no	existe	en	la	lista	
    */		
    public	int	getIndexOf(String	searched)	throws	java.util.NoSuchElementException	{		
        int	pos =	0;
        int	i=0;
        String	cadena;
        boolean	encontrado=false;		
        //	Comprobamos	que	el	argumento	sea	válido		
        if	(searched	==	null){
            throw	new	IllegalArgumentException();		
        }		
        //	Recorremos	la	información	hasta	encontrar	el	elemento		
        while(	(!encontrado)	&&	(i<elements.size())	){
            cadena	=	elements.get(i);
            if	(cadena.equals(searched)){
                encontrado=true;
            }else{
                i++;
            }	
        }
        if(encontrado){
            return	i;
        }else{
            //	El	elemento	no	existia,	lanzamos	la	excepción	
            throw	new	java.util.NoSuchElementException(searched);
        }	
    }
}		   
