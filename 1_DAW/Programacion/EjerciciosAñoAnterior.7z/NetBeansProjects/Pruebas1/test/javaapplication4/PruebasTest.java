/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication4;

import org.junit.After;
import org.junit.AfterClass;
import	org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.Ignore;
import static org.junit.Assert.*;


/**
 *
 * @author Paqui Elena
 */
public class PruebasTest {
    String datos[]={"CASA","PERRO","ESTA ES LA MAS LARGA","NO SE","ORDENADOR"};
    public PruebasTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

/**	
*	Verificamos	que	en	caso	de	recibir	un	null	como	argumento	en	el	
*	constructor	la	clase	lanza	una	IllegalArgumentException	
*/		
@Test(expected	=	java.lang.IllegalArgumentException.class)
public	void	initTest()	{		
    new	Pruebas(null);
}	
    
/**	
*	Verificamos	que	la	cadena	más	larga	sea	la	cadena	"ESTA	ES	LA	MAS	LARGA"	
*/		
@Test		
public	void	getLengthTest()	{
    Pruebas prueba=new Pruebas(datos);
    Assert.assertEquals("ESTA ES LA MAS LARGA",	prueba.getMaxLength());
}	

/**	
*	Prueba	sobre	el	método	que	devuelve	la	suma	total	de	todas	las	cadenas	
*	almacenadas	Suponemos	que	el	calculo	del	tamaño	total	es	un	método	
*/		
@Test(timeout	= 1)
public	void	getTotalLengthTest()	{	
    Pruebas	prueba=new	Pruebas(datos);
    Assert.assertEquals(43,	prueba.getTotalLength());
}	

/**	
*	Prueba	sobre	el	método	que	devuelve	la	posición	de	una	cadena.	
*	Verificamos	que	si	le	pasamos	null	como	argumento	lanza	la	excepción	
*	correcta	
*/		
@Test(expected	= java.lang.IllegalArgumentException.class)		
public	void	getIndexOfTest()	{	
    Pruebas	prueba=new	Pruebas(datos);
    prueba.getIndexOf(null);	
}

/**	
*	Prueba	sobre	el	método	que	devuelve	la	posición	de	una	cadena	Verificamos	
*	que	si	le	pasamos	una	cadena	que	no	existe	como	argumento	lanza	la	
*	excepción	correcta	
*/		

@Test(expected	=	java.util.NoSuchElementException.class)		
public	void	getIndexOfTest2()	{	
    Pruebas	prueba=new	Pruebas(datos);
    //Assert.assertEquals(0,	prueba.getIndexOf("EsteElementoNoExiste"));	
    prueba.getIndexOf("EsteElementoNoExiste");
}

/**	
*	Prueba	sobre	el	método	que	devuelve	la	posición	de	una	cadena.		
*	Verificamos	que	si	le	pasamos	una	cadena	que	existe	devuelve	la	posición	correcta	
*/
@Test		
public	void	getIndexOfTest3()	{	
    Pruebas	prueba=new	Pruebas(datos);
    Assert.assertEquals(4,	prueba.getIndexOf("ORDENADOR"));
}	


}