/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyectoherencia3;

/**
 *
 * @author Profesor
 */
public class Triangulo extends Figura {
    protected double hipotenusa;

    public Triangulo(int base, int altura) {
        //super.base=base;
        //super.altura=altura;
        super(base, altura);
        this.hipotenusa=Math.hypot(super.base,super.altura);       
    }

    public Triangulo() {
        //super SIEMPRE SERÁ LA PRIMERA INSTRUCCIÓN DE UN CONSTRUCTOR
       // super(); //super(0,0);
       // this.hipotenusa=Math.hypot(super.base,super.altura); //También this.hipotenusa=0
        this(0,0);//  SIN UTILIZAR super*/
    }
    
    public Triangulo(Figura otraF)
    {
        super(otraF);
        this.hipotenusa=Math.hypot(super.base, super.altura);
    }
    
    
    public Triangulo(Triangulo other)
    {
        super(other.base,other.altura);
        this.hipotenusa=other.hipotenusa;
    }

    @Override
    public String toString() {
        return "{" + super.toString()+ "Hipotenusa=" + this.hipotenusa + '}';
    }
    
    public String toString(int n)
    {
        return "Hola"+n;
    }
    
    public double getHipotenusa() {
        return hipotenusa;
    }
   
    @Override
    public double area()
    {
        return (super.base*super.altura)/2.0f;
    }
    
    @Override
    public double perimetro(){
       return super.base+super.altura+this.hipotenusa;   
    }
    
    
    
    
    
}
