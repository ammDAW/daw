/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyectoherencia3;

/**
 *
 * @author Profesor
 */
public class ProyectoHerencia3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Figura figurita1=new Figura(4,5);
        System.out.println("La base de figurita1 ="+figurita1.getBase());
        System.out.println("Figurita 1 ="+figurita1);
        System.out.println("El área de la Figurita 1 es: "+figurita1.area());
        System.out.println("El perímetro de la Figurita 1 es: "+figurita1.perimetro());
        
        System.out.println("-----------------------------------------\n");
          
        
        Triangulo t=new Triangulo(4,5);
        System.out.println("La base del triángulo t es "+t.getBase());
        System.out.println("Triángulo t ="+t);
        System.out.println("El área del Triángulo t es: "+t.area());
        System.out.println("El perímetro del Triángulo t es: "+t.perimetro());
        System.out.println("Hipotenusa del Triángulo t es: "+t.getHipotenusa());
        
        System.out.println("LA FIGURITA1 DE TIPO FIGURA SE TRANSFORMA EN UN TRIÁNGULO....");
        figurita1=t;
        System.out.println("La base de figurita1 ="+figurita1.getBase());
        System.out.println("Figurita 1 ="+figurita1);
        System.out.println("El área de la Figurita 1 es: "+figurita1.area());
        System.out.println("El perímetro de la Figurita 1 es: "+figurita1.perimetro());
        
        
        System.out.println("______________________________________");
        
        Figura f;
        Triangulo t2=new Triangulo(8,8);
        f=t2;
        System.out.println("Base de f= "+f.getBase());
        
        
        /*
        figurita1=t; //Que figurita1 que es de tipo Figura se transforma en un Triángulo, t
        System.out.println("\n\n----FIGURITA1 COMO TRIANGULO T---");
        System.out.println("La base de figurita1 ="+figurita1.getBase());
        System.out.println("Figurita 1 ="+figurita1);
        System.out.println("El área de la Figurita 1 es: "+figurita1.area());
        System.out.println("El perímetro de la Figurita 1 es: "+figurita1.perimetro());
       // System.out.println("Hipotenusa "+((Triangulo)figurita1).getHipotenusa());
        
        //Figura f=new Triangulo(4,5);
        //System.out.println("f= "+f);

      */
    }
    
}
