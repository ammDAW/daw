/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package paqueteFecha;

/**
 *
 * @author Profesor
 */
public class Persona {
    private int id;
    private String nombre;
    private static int numPersonas=0;
       
    public Persona(String nombre)
    {
        this.nombre=nombre;
        Persona.numPersonas++;
        this.id=Persona.numPersonas;
    }

    public int getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public static int getNumPersonas() {
        return numPersonas;
    }
    
    @Override
    public String toString(){
        return this.id+" "+this.nombre+" de un total de "+Persona.numPersonas;
    }
}
