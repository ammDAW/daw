/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package paqueteFecha;

/**
 *
 * @author Profesor
 */
public class Fecha {
    private int dia,mes,anio;
    private final static String nombreMeses[]={"","Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre"};
    private static int diasMeses[]={0,31,28,31,30,31,30,31,31,30,31,30,31};
    
    public Fecha(int dia, int mes, int anio)
    {
        if (Fecha.fechaCorrecta(dia, mes, anio)){
            this.dia=dia; this.mes=mes; this.anio=anio;
        }
        else 
        {
            this.dia=1; this.mes=1; this.anio=2000;
        }
    }
    
    public static boolean fechaCorrecta(int d, int m, int a)
    {
      if (a<2000) return false;
      if (m<1 || m>12) return false;
      if (Fecha.bisiesto(a))
          Fecha.diasMeses[2]=29;
      if (d<1 || d>Fecha.diasMeses[m])
          return false;
      
      Fecha.diasMeses[2]=28;
      return true;
      
    }
    
    private static boolean bisiesto(int a){
        return (a%4==0)?true:false; 
    }
    
    public String toString(int n)
    {
        String cadena=null;
        String strDia=String.valueOf(this.dia);
        if (this.dia<10) strDia='0'+strDia;
        String strMes=String.valueOf(this.mes);
        if (this.mes<10) strMes='0'+strMes;
        String strAnio=String.valueOf(this.anio);
        String strAnioCorto=strAnio.substring(2, 4);
        
        switch(n)
        {
            case 1: cadena=strDia+"-"+strMes+"-"+strAnioCorto; break;
            case 2: cadena=strDia+"-"+strMes+"-"+strAnio; break;    
            case 3: cadena=strDia+"-"+Fecha.nombreMeses[this.mes]+"-"+strAnioCorto; break;
            case 4: cadena=strDia+" de "+Fecha.nombreMeses[this.mes]+" de "+strAnioCorto; break;    
            default: cadena=strDia+"-"+strMes+"-"+strAnio;
        }
        return cadena;
    }
    
    public int toDias()
    {
        return 4;
    }
    
    
    public Fecha fechaMayor(Fecha otra)
    {
        if (this.toDias() > otra.toDias())
            return this;
        else
            return otra;
    }
    
    public Fecha fechaMenor(Fecha otra)
    {
        if (this.anio <otra.anio)
            return this;
        else if (this.anio == otra.anio)
            if (this.mes < otra.mes)
                return this;
            else if (this.mes == otra.mes && this.dia < otra.dia)
                return this;
        
        
        return otra;
    }
    
}
