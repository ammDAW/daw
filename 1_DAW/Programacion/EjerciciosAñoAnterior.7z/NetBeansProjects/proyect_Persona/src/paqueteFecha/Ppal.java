/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package paqueteFecha;

/**
 *
 * @author Profesor
 */
public class Ppal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Fecha f=new Fecha(8,12,2001);
        System.out.println("Fecha f="+f.toString(1));
        
        
        /*
        Persona p=new Persona("Pepe");
        Persona pp=new Persona("Carlos");
        System.out.println("Persona p= "+p);
        System.out.println("Persona pp= "+pp);
        System.out.println("Número de personas creadas "+Persona.getNumPersonas());
        */
    }
    
}
