/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package NieNif;

import paqueteFecha.Fecha;

/**
 *
 * @author Profesor
 */
public class Proyect_Persona {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
     /* 
      Nif alex=null;  
      boolean nifIncorrecto=true;
      
      while(nifIncorrecto)
      {    
        try{  
         String nifAlex=Pedir.cadena("Dime el nif de Alex: ");
         alex=new Nif(nifAlex);
         nifIncorrecto=false;         
        }catch(IllegalArgumentException t)
        {
          System.out.println("Error, vuelve a introducir el nif");
        }
        
      }
      
        System.out.println("El nif de alex es "+alex);
      */
        int dni=Pedir.entero("Dime tu dni: ");
        Nif nacho=new Nif(dni);
        System.out.println("Nif de nacho ="+nacho);
        
        
        Nie zhiFeng=new Nie("Y1662630C");
        System.out.println("NIE de Zhi-Feng "+zhiFeng);
        
        
        Persona p1=new Persona("Ignacio","Valle","Martínez",'V',"SOLTERO",new Fecha(21,3,2000), "1");
        ;
       // Persona p2=new Persona(zhiFeng,"Zhi-Feng");
        
       // Persona p3=new Persona(new Punto(8,9),"Una persona llamada PUNTO");
        
        System.out.println("Persona p1="+p1);
       // System.out.println("Persona p2="+p2);
    }
    
}
