/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package NieNif;

/**
 *
 * @author Profesor
 */
public class Nif {
    private String nif;
    private final static String LETRAS="TRWAGMYFPDXBNJZSQVHLCKE"; //Propiedad estática constante
    
    public Nif(String nif) throws IllegalArgumentException
    {
        nif=nif.toUpperCase().trim();
        if (nif.length() !=9)
            throw new IllegalArgumentException("Error, longitud incorrecta en el NIF");
        String strDni=nif.substring(0, 8);
        
        int dni;
        try{
            dni=Integer.parseInt(strDni);  
        }catch(NumberFormatException t)
        {
            throw new IllegalArgumentException("Error, el DNI no es un número");
        }
        
        char letra=nif.charAt(8);
        int posLetra=dni%23;
        
        if (letra!=Nif.LETRAS.charAt(posLetra))
            throw new IllegalArgumentException("Error, letra Incorrecta");
        
        this.nif=nif;
    }

    
    public Nif(int dni)throws IllegalArgumentException
    {
      if (dni <1 || dni > 99999999)
            throw new IllegalArgumentException("Error, Dni incorrecto");
      
      int posLetra=dni%23;
      char letra=Nif.LETRAS.charAt(posLetra);
      
      String strDni=String.valueOf(dni);
      int numDigitos=strDni.length();
      
      for (int i = numDigitos; i < 8; i++) {
            strDni='0'+strDni;
      }
          
      this.nif=strDni + letra;
    }
    
    
    @Override
    public String toString() {
        return "Nif{" + "nif=" + nif + '}';
    }
    
    
}
