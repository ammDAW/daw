/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package NieNif;

import java.util.Objects;
import paqueteFecha.Fecha;

/**
 *
 * @author Profesor
 */
public class Persona {
    
    
    /*PRIMERA FORMA
    private Nif nif=null;
    private Nie nie=null;
    private String nombre;

    public Persona(Nif nif, String nombre) {
        this.nif = nif;
        this.nombre = nombre;        
    }
    
    public Persona(Nie nie, String nombre) {
        this.nie = nie;
        this.nombre = nombre;        
    }
 */
  //Usando instanceof y la clase Object
    private static int numPersonas=0;
    private int id;
    private Nif nif=null;
    private Nie nie=null;
    private String nombre, apellido1, apellido2;
    private char sexo; //debe ser 'H', 'M'
    private String estado; // "VIUDO","SOLTERO","CASADO","DIVORCIADO"
    private Fecha fechaNac; 
    
    public Persona(String nombre, String apellido1, String apellido2, char sexo, String estado, Fecha fechaNac,Object obj)
    {
      try{  
        this.nombre=nombre.toUpperCase().trim(); 
        this.apellido1=apellido1.toUpperCase().trim();
        this.apellido2=apellido2.toUpperCase().trim();
        this.setSexo(sexo);
        this.setEstado(estado);
        this.fechaNac=fechaNac;
        if (obj instanceof Nif)
            this.nif=(Nif)obj;         
        else if (obj instanceof Nie)
            this.nie=(Nie)obj;
        else { this.nif=new Nif(1); this.nie=null;}
        Persona.numPersonas++;
        this.id=numPersonas;
      } catch(IllegalArgumentException e)
      {
          this.nombre=""; this.apellido1=""; this.apellido2="";
          this.sexo='H';
          this.estado="SOLTERO";
          this.fechaNac=new Fecha(1,1,2000);
          this.nif=new Nif(1); 
          this.nie=null;
      }
         
    }

    public static int getNumPersonas() {
        return numPersonas;
    }

    public int getId() {
        return id;
    }

    public Nif getNif() {
        return nif;
    }

    public Nie getNie() {
        return nie;
    }

    public String getNombre() {
        return nombre;
    }

    public String getApellido1() {
        return apellido1;
    }

    public String getApellido2() {
        return apellido2;
    }

    public char getSexo() {
        return sexo;
    }

    public String getEstado() {
        return estado;
    }

    public Fecha getFechaNac() {
        return fechaNac;
    }

    public static void setNumPersonas(int numPersonas) {
        Persona.numPersonas = numPersonas;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setNif(Nif nif) {
        this.nif = nif;
    }

    public void setNie(Nie nie) {
        this.nie = nie;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setApellido1(String apellido1) {
        this.apellido1 = apellido1;
    }

    public void setApellido2(String apellido2) {
        this.apellido2 = apellido2;
    }

    public void setSexo(char sexo) throws IllegalArgumentException {
        if (sexo!='V' && sexo!='M' && sexo!='v' && sexo!='m')
            throw new IllegalArgumentException("Sexo incorrecto");
        this.sexo = sexo;
    }

    public void setEstado(String estado) throws IllegalArgumentException {
        if (!(estado.equalsIgnoreCase("CASADO") || estado.equalsIgnoreCase("VIUDO") || estado.equalsIgnoreCase("SOLTERO") || estado.equalsIgnoreCase("DIVORCIADO")))
             throw new IllegalArgumentException("Estado incorrecto");
        this.estado = estado;
    }

    public void setFechaNac(Fecha fechaNac) {
        this.fechaNac = fechaNac;
    }

    @Override
    public String toString() {
        String cadena=(this.nif!=null)?("Nif=" + nif ):("Nie=" + nie);
        return "[" + "Id=" + id + cadena + " Nombre=" + nombre +' '+ apellido1 +' '+ apellido2 + "\tSexo=" + sexo + " \t Estado Civil=" + estado + "\t Fecha de Nacimiento=" + fechaNac.toString(1) + ']';
    }
    
    
    
    
   
        
    
}
