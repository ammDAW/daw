/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package NieNif;

/**
 *
 * @author Profesor
 */
public class Nie {
    private String nie;
    private final static String LETRAS="TRWAGMYFPDXBNJZSQVHLCKE"; //Propiedad estática constante
    
    public Nie(String nie) throws IllegalArgumentException
    {
        nie=nie.toUpperCase().trim();
        if (nie.length() !=9)
            throw new IllegalArgumentException("Error, longitud incorrecta en el NIE");
        
        char prLetra=nie.charAt(0);
        if (prLetra!='X' && prLetra!='Y' && prLetra!='Z')
            throw new IllegalArgumentException("La primera letra no corresponde a un NIE");
        
        String strDni=nie.substring(1, 8);
        
        int dni;
        try{
            dni=Integer.parseInt(strDni);  
        }catch(NumberFormatException t)
        {
            throw new IllegalArgumentException("Error, no hay 7 dígitos");
        }
               
        switch(prLetra)
        {
            case 'Y': strDni='1'+strDni; break;
            case 'Z': strDni='2'+strDni;
        }
        
        dni=Integer.parseInt(strDni);
        char letra=nie.charAt(8);
        int posLetra=dni%23;
        
        if (letra!=Nie.LETRAS.charAt(posLetra))
            throw new IllegalArgumentException("Error, letra Incorrecta");
        
        this.nie=nie;
    }

    @Override
    public String toString() {
        return "Nie{" + "nie=" + nie + '}';
    }

    

}
