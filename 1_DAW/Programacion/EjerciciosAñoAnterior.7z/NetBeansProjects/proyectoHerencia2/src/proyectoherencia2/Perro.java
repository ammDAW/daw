/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyectoherencia2;

/**
 *
 * @author Profesor
 */
public class Perro extends Mamifero{
    @Override
    public void dormir()
    {
    super.dormir(); //ejecuta dormir de mamífero que es el mismo de Animal, NO está sobreescrito
    //Si el método dormir se sobreescribiera en mamífero 
      System.out.println("El perro debe dormir en función del ejercicio que realice");
    }
    
    public void ladrar(){
        System.out.println("Es una labor social de guardia");
    }
    
    public void grunir(){
        System.out.println("Es un sonido ronco y sostenido");
    }
    
}
