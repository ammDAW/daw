/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyectoherencia2;

/**
 *
 * @author Profesor
 */
public class ProyectoHerencia2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Animal serpiente=new Animal();
        System.out.println("El Animal: serpiente..................");
        serpiente.comer();
        serpiente.dormir();
        serpiente.reproducir();
        
        Mamifero elefante=new Mamifero();
        System.out.println("El mamífero: elefante .................");
        elefante.comer();
        elefante.dormir();
        elefante.reproducir();
        
        Perro toby=new Perro();
        System.out.println("El perro: toby .................");
        toby.comer();
        toby.dormir();
        toby.reproducir();
        toby.ladrar();
        toby.grunir();
        
        serpiente=elefante;//Se puede, serpiente es Animal y elefante es Mamífero
        System.out.println("SERPIENTE COMO ELEFANTE --Un Animal se comporta como MAMÍFERO................");
        serpiente.comer();
        serpiente.dormir();
        serpiente.reproducir();
        
        serpiente=toby; //Se puede, serpiente es Animal y toby es un Perro
        System.out.println("SERPIENTE COMO TOBY--Un Animal se comporta como PERRO................");
        serpiente.comer();
        serpiente.dormir();
        serpiente.reproducir();
        //serpiente.ladrar(); //NO se puede, serpiente solo se puede comportar
        //con los métodos declarados de Animal, nunca los añadidos por PERRO 
        
        
        
    }
    
}
