/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package herenciaanimal;

/**
 *
 * @author Profesor
 */
public class HerenciaAnimal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Animal a=new Animal(); 
        Cat b=new Cat();
        Dog c=new Dog();
        
        a.makeSound();//Gr...
      // El método eat NO es de la clase Animal a.eat();
      
        b.makeSound(); //Meou
        b.eat(); //eats fish
        
        c.makeSound(); //Woof
        //El método eat es de Gato c.eat();
        
        a=b; //a toma forma de un Gato b
        a.makeSound();//Meou
        // a.eat(); aunque a tome forma de Cat, no puede utilizar el método eat
        // ya que eat() NO está definido en Animal
        
        a=c; //a se transforma en perro
        a.makeSound(); // Woof
        
        Animal mula;
        Cat gatito=new Cat();
        Dog perro=new Dog();
        
        mula=gatito;
        mula.makeSound(); //Meow
        
        mula=perro;
        mula.makeSound();//Woof
        
        Animal vaca=new Cat();
        vaca.makeSound(); //Meow
        
        vaca=new Dog();
        vaca.makeSound();//Woof
        
        
        
    }
    
}
