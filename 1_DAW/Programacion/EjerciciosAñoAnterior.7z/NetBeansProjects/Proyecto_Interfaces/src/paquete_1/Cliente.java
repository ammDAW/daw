/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package paquete_1;

/**
 *
 * @author Profesor
 */
public class Cliente implements CallBack{
    @Override
    public void callback(){
        System.out.println("Devuelve la llamada");        
    }
    
    public void metodoPropioCliente(){
        System.out.println("Método propio de la clase: Cliente");
    }
}
