/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package paquete_1;

/**
 *
 * @author Profesor
 */
public class Proyecto_Interfaces {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Cliente c=new Cliente();
        c.callback();
        c.metodoPropioCliente();
        
        CallBack in=c;
        in.callback();
        ((Cliente)in).metodoPropioCliente();
        
        CallBack on=new Cliente();//Se reserva una zona de memoria para el objeto Cliente
                                  // y la variable on (interface) apunta a esa zona de memoria
                                  //on, puede ejecutar su método: on.callback();
        on.callback();
        
        
    }
    
}
