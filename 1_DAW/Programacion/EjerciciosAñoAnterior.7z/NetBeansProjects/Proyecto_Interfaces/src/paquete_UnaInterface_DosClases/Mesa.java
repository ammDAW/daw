/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package paquete_UnaInterface_DosClases;

/**
 *
 * @author Profesor
 */
public class Mesa implements DevLlamada{
    private int numPatas;

    public Mesa(int numPatas) {
        this.numPatas = numPatas;
    }

    public int getNumPatas() {
        return numPatas;
    }

    public void setNumPatas(int numPatas) {
        this.numPatas = numPatas;
    }

    @Override
    public String toString() {
        return "Mesa{" + "numPatas=" + numPatas + '}';
    }
    
    
    @Override
    public void devLlamada(int x){
        System.out.println("Clase: Mesa");
        System.out.println("x+x"+(x+x));
    }
}
