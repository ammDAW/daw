/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package paquete_UnaInterface_DosClases;

/**
 *
 * @author Profesor
 */
public class Cliente1 implements DevLlamada{
    private String nombre;

    public Cliente1(String nombre) {
        this.nombre = nombre;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    @Override
    public String toString() {
        return "Cliente1{" + "nombre=" + nombre + '}';
    }
    
    
    @Override
    public void devLlamada(int x){
        System.out.println("devLlamada "+x);
    }
    
    public void metodoPropio(){
        System.out.println("Método propio de la clase: Cliente1");
    }
}
