/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package paquete_UnaInterface_DosClases;

/**
 *
 * @author Profesor
 */
public class Ppal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Cliente1 c1=new Cliente1("Jesús");
        c1.devLlamada(23);
        c1.metodoPropio();
        System.out.println("c1="+c1);
        c1.setNombre("Pepe");
        
        DevLlamada d=c1;
        d.devLlamada(34);
        
        /*
        Cliente2 c2=new Cliente2();
        d=c2;
        d.devLlamada(45);
        */
        
        Mesa m=new Mesa(3);
        System.out.println("m="+m);
        m.setNumPatas(4);
        m.devLlamada(23);
        
        
        
    }
    
}
