/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package paquete_UnaInterface_DosClases;

/**
 *
 * @author Profesor
 */
public class Cliente2 implements DevLlamada{
    @Override
    public void devLlamada(int x){
        System.out.println("Otra versión de devLlamada");
        System.out.println("Cuadrado "+(x*x));
    }
    
}
