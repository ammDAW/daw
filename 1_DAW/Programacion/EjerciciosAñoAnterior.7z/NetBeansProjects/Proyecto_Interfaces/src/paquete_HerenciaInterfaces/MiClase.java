/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package paquete_HerenciaInterfaces;

/**
 *
 * @author Profesor
 */
public class MiClase implements B{
   @Override
   public void metodo1(){System.out.println("Hola");}
   @Override
   public void metodo2(){System.out.println("Método 2");}
   
   @Override
   public void metodo3(){System.out.println("Método 3");}
   
}
