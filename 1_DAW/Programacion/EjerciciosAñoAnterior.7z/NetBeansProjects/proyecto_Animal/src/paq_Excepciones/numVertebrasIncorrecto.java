/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package paq_Excepciones;

/**
 *
 * @author isabel
 */
public class numVertebrasIncorrecto extends Exception{

    public numVertebrasIncorrecto() {
        super("El número de vértebras ha de ser superior a 0 o inferior a 1000");
    }

    public numVertebrasIncorrecto(String message) {
        super(message);
    }
    
}
