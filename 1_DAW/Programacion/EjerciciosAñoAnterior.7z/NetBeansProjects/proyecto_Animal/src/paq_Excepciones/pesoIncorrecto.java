/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package paq_Excepciones;

/**
 *
 * @author isabel
 */
public class pesoIncorrecto extends Exception {

    public pesoIncorrecto() {
        super("El peso debe ser superior a 0 o inferior a 5000");
    }

    public pesoIncorrecto(String message) {
        super(message);
    }
    
}
