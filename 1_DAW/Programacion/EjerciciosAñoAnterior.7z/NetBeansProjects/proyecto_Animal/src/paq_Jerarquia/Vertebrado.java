/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package paq_Jerarquia;

import paq_Clases.Fecha;
import paq_Excepciones.numVertebrasIncorrecto;
import paq_Excepciones.pesoIncorrecto;

/**
 *
 * @author isabel
 */
public class Vertebrado extends Animal{
    protected int numVertebras;
    
    public Vertebrado(int numVertebras, int peso, Fecha fechaNac) throws pesoIncorrecto, numVertebrasIncorrecto {
        super(peso, fechaNac); 
        if (numVertebras < 0 || numVertebras > 1000)
            throw new numVertebrasIncorrecto();
                
        this.numVertebras = numVertebras;
    }

    public Vertebrado(int numVertebras, int peso, int d, int m, int a) throws pesoIncorrecto, numVertebrasIncorrecto {
        super(peso, d, m, a); //super(peso, new Fecha(d,m,a);
        if (numVertebras < 0 || numVertebras > 1000)
            throw new numVertebrasIncorrecto();
        this.numVertebras = numVertebras;
    }

    public Vertebrado(int numVertebras) throws pesoIncorrecto, numVertebrasIncorrecto {
        super();// super(0,new Fecha()); super(0,1,1,2000);
        if (numVertebras < 0 || numVertebras > 1000)
            throw new numVertebrasIncorrecto();
        this.numVertebras = numVertebras;
    }

    public Vertebrado(int numVertebras, Animal otro) throws pesoIncorrecto, numVertebrasIncorrecto {
        super(otro); // super(otro.peso, otro.fechaNac);
        if (numVertebras < 0 || numVertebras > 1000)
            throw new numVertebrasIncorrecto();

        this.numVertebras = numVertebras;
    }

    public Vertebrado(Vertebrado otro) throws pesoIncorrecto, numVertebrasIncorrecto 
    {
        super(otro);// super(Animal otroAnimal);  otroAnimal=otro;
        if (numVertebras < 0 || numVertebras > 1000)
            throw new numVertebrasIncorrecto();

        this.numVertebras=otro.numVertebras;
        
    }

    public Vertebrado() throws pesoIncorrecto{
        super();
        this.numVertebras=0;
    }
  
    
    public int getNumVertebras() {
        return numVertebras;
    }

    public void setNumVertebras(int numVertebras) throws numVertebrasIncorrecto{
        if (numVertebras < 0 || numVertebras > 1000)
            throw new numVertebrasIncorrecto();
        this.numVertebras = numVertebras;
    }
        
    @Override
    public String toString() {
        return super.toString()+" Número de Vertebras=" + this.numVertebras;
    }
    
    
}
