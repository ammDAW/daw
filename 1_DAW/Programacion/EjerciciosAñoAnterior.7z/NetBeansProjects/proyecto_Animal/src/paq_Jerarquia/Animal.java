/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package paq_Jerarquia;

import paq_Clases.Fecha;
import paq_Excepciones.pesoIncorrecto;

/**
 *
 * @author isabel
 */
public class Animal {
    protected int peso;
    protected Fecha fechaNac;

    public Animal(int peso, Fecha fechaNac) throws pesoIncorrecto{
        if (peso<0 || peso>5000)
            throw new pesoIncorrecto();
        this.peso = peso;
        this.fechaNac = fechaNac;
    }
    
    public Animal(int peso, int d, int m, int a) throws pesoIncorrecto{
        this(peso,new Fecha(d,m,a));
    }
    
    public Animal() throws pesoIncorrecto{
        this(0,new Fecha());
    }
    
    public Animal(Animal otro) throws pesoIncorrecto{
        this(otro.peso,otro.fechaNac);
    }

    public int getPeso() {
        return this.peso;
    }

    public Fecha getFechaNac() {
        return this.fechaNac;
    }

    public void setPeso(int peso) throws pesoIncorrecto{
       if (peso<0 || peso>5000) 
           throw new pesoIncorrecto();
        this.peso = peso;
    }

    public void setFechaNac(Fecha fechaNac) {
        this.fechaNac = fechaNac;
    }

    @Override
    public String toString() {
        return "Peso=" + this.peso + " Fecha de Nacimiento= " + this.fechaNac;
    }
    
        
}
