/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package paq_Jerarquia;

import java.util.ArrayList;
import paq_Clases.Fecha;
import paq_Clases.Hijo;
import paq_Excepciones.MorirException;
import paq_Excepciones.NumHijosIncorrecto;
import paq_Excepciones.numVertebrasIncorrecto;
import paq_Excepciones.pesoIncorrecto;

/**
 *
 * @author Profesor
 */
public class Hombre extends Vertebrado{
    private String nombre;
    private boolean vivo;
    private int numHijos=0;
    private ArrayList <Hijo> datosHijos;

    public Hombre(String nombre, boolean vivo, ArrayList<Hijo> datosHijos, int numVertebras, int peso, Fecha fechaNac) throws pesoIncorrecto, numVertebrasIncorrecto, NumHijosIncorrecto {
        super(numVertebras, peso, fechaNac);
        this.nombre = nombre;
        this.vivo = vivo;
        if (datosHijos.size()>=20)
            throw new NumHijosIncorrecto("Nunca se pueden tener más de 20 hijos");
        this.datosHijos = datosHijos;
        this.numHijos=this.datosHijos.size();
    }

    public Hombre(String nombre, boolean vivo, ArrayList<Hijo> datosHijos, int numVertebras, int peso, int d, int m, int a) throws pesoIncorrecto, numVertebrasIncorrecto {
        super(numVertebras, peso, d, m, a);
        this.nombre = nombre;
        this.vivo = vivo;
        
        this.datosHijos = datosHijos;
        this.numHijos=this.datosHijos.size();
    }

    public Hombre(String nombre, boolean vivo, ArrayList<Hijo> datosHijos, int numVertebras) throws pesoIncorrecto, numVertebrasIncorrecto {
        super(numVertebras);
        this.nombre = nombre;
        this.vivo = vivo;
        this.datosHijos = datosHijos;
        this.numHijos=this.datosHijos.size();
    }

    public Hombre(String nombre, boolean vivo, ArrayList<Hijo> datosHijos, int numVertebras, Animal otro) throws pesoIncorrecto, numVertebrasIncorrecto {
        super(numVertebras, otro);
        this.nombre = nombre;
        this.vivo = vivo;
        this.datosHijos = datosHijos;
        this.numHijos=this.datosHijos.size();
    }

    public Hombre(String nombre, boolean vivo, ArrayList<Hijo> datosHijos, Vertebrado otro) throws pesoIncorrecto, numVertebrasIncorrecto {
        super(otro);
        this.nombre = nombre;
        this.vivo = vivo;
        this.datosHijos = datosHijos;
        this.numHijos=this.datosHijos.size();
    }
    
    public Hombre(Hombre otro) throws pesoIncorrecto, numVertebrasIncorrecto
    {
        super(otro);
        this.nombre=otro.nombre;
        this.vivo=otro.vivo;
        this.datosHijos=otro.datosHijos;
        this.numHijos=otro.numHijos;
    }

    public Hombre(String nombre) throws pesoIncorrecto, numVertebrasIncorrecto {    
        super();
        this.nombre=nombre;
        this.vivo=true;
        this.datosHijos=new ArrayList ();
        this.numHijos=0;
    }
    
    
    public String getNombre() {
        return nombre;
    }

    public boolean isVivo() {
        return vivo;
    }

    public int getNumHijos() {
        return numHijos;
    }

    public ArrayList<Hijo> getDatosHijos() {
        return datosHijos;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setVivo(boolean vivo) {
        this.vivo = vivo;
    }

    public void setDatosHijos(ArrayList<Hijo> datosHijos) throws NumHijosIncorrecto{
        if (datosHijos.size()>=20)
            throw new NumHijosIncorrecto("Nunca se pueden tener más de 20 hijos");

        this.datosHijos = datosHijos;
        this.numHijos=this.datosHijos.size();
    }
    
    public void morir() throws MorirException{
        if (this.vivo)
            this.vivo=false;
        else
            throw new MorirException("No se puede morir más de una vez");
    }
    
    public void tenerHijos(Hijo h){
        if (this.datosHijos.contains(h))
            System.out.println("Ese hijo ya está dado de alta");
        else
            this.datosHijos.add(h);
    }
    
    public int edadHijoMenor(Fecha actual){
        int edadMenor=Integer.MAX_VALUE;
        for(Hijo h: this.datosHijos)
            if (h.edad(actual) < edadMenor)
                edadMenor=h.edad(actual);
        return edadMenor;
    }
    
    public Hijo hijoMenor(Fecha actual){
        Hijo hj=null;
        int edadMenor=this.edadHijoMenor(actual);
        for(Hijo h: this.datosHijos)
            if (h.edad(actual)==edadMenor)
            {
                   hj=h; 
                   break;
            }
        return hj;
    }
    
    public String nombreHijoMenor(Fecha actual)
    {
        return this.hijoMenor(actual).getNombre();
    }
    
    
    public int lugarHijo(Hijo hj){
        boolean encontrado=false;
        int indice=-1;
        
        if (this.datosHijos.contains(hj))
        {
            encontrado=true;
            indice =0;
            for(Hijo h: this.datosHijos){
                if (h.equals(hj))
                    break;
                indice++;            
            }    
        }
              
        return (encontrado)?indice:-1;
        
        /* También este código compuesto por una sola línea
            return this.datosHijos.indexOf(hj);
        */
    }
    
    public int lugarHijo(String nombre){
        boolean encontrado=false;
        int indice=-1;
        /*
        for(int i=0;i<this.datosHijos.size();i++)
            if (this.datosHijos.get(i))
       */
        return 0;
        
        
    }
    
    
    
}
