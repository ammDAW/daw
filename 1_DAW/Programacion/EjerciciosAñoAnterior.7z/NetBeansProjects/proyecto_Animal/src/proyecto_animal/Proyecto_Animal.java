/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto_animal;

import paq_Clases.Fecha;
import paq_Clases.Hijo;
import paq_Estatico.Pedir;
import paq_Excepciones.numVertebrasIncorrecto;
import paq_Excepciones.pesoIncorrecto;
import paq_Jerarquia.Animal;
import paq_Jerarquia.Vertebrado;

/**
 *
 * @author isabel
 */
public class Proyecto_Animal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
      
       Fecha hoy=new Fecha(2,5,2019);
       Fecha fechaNac=new Fecha(3,3,2001);
       /*
       Hijo pepe=new Hijo("Pepe",fechaNac);
       System.out.println("Edad ="+pepe.edad(hoy));
       */
       
       Animal rino=null;
       
       boolean animalCorrecto=false;
       while (!animalCorrecto)
       {  
        int peso=Pedir.entero("Dime el peso");
        try{
          rino=new Animal(peso, fechaNac);
          animalCorrecto=true;
        }
        catch(pesoIncorrecto t){
           System.out.println("El rinocente debe pesar entre 0kgr a 5000kgrs");
        }
       }
       
       System.out.println("Animal rino "+rino);
      
      
      Vertebrado gatito=null;
      boolean vertebradoCorrecto=false;
      while(! vertebradoCorrecto){
        int peso=Pedir.entero("Dime el peso: ");
        int numVertebras=Pedir.entero("Dime el número de vértebras: ");
        try{ 
          gatito=new Vertebrado(numVertebras,peso,fechaNac);
          vertebradoCorrecto=true;
        }
        catch(numVertebrasIncorrecto | pesoIncorrecto e){
          System.out.println(e.getMessage());          
        }
        catch(Exception e){
          System.out.println("El error producido es desconocido "+e.getMessage());
        }
      }
       System.out.println("Vertebrado gatito "+gatito);
       
      Vertebrado perrito=null;
      vertebradoCorrecto=false;
      while(! vertebradoCorrecto){
        int peso=Pedir.entero("Dime el peso: ");
        int numVertebras=Pedir.entero("Dime el número de vértebras: ");
        try{ 
          perrito=new Vertebrado(numVertebras,peso,8,5,2019);
          vertebradoCorrecto=true;
        }
        catch(numVertebrasIncorrecto | pesoIncorrecto e){
          System.out.println(e.getMessage());          
        }
        catch(Exception e){
          System.out.println("El error producido es desconocido "+e.getMessage());
        }
      }
       System.out.println("Vertebrado perrito "+perrito);
       
     System.out.println("Creación de un canario");
      Vertebrado canario=null;
      vertebradoCorrecto=false;
      while(! vertebradoCorrecto){
        int numVertebras=Pedir.entero("Dime el número de vértebras: ");
        try{ 
          canario=new Vertebrado(numVertebras);
          vertebradoCorrecto=true;
        }
        catch(numVertebrasIncorrecto | pesoIncorrecto e){
          System.out.println(e.getMessage());          
        }
        catch(Exception e){
          System.out.println("El error producido es desconocido "+e.getMessage());
        }
      }
       System.out.println("Vertebrado canario "+canario);
        
       
        System.out.println("Creación del rinoceronte");
        Vertebrado rinoceronte=null;
      vertebradoCorrecto=false;
      while(! vertebradoCorrecto){
        int numVertebras=Pedir.entero("Dime el número de vértebras: ");
        try{ 
          rinoceronte=new Vertebrado(numVertebras,rino);
          vertebradoCorrecto=true;
        }
        catch(numVertebrasIncorrecto | pesoIncorrecto e){
          System.out.println(e.getMessage());          
        }
        catch(Exception e){
          System.out.println("El error producido es desconocido "+e.getMessage());
        }
      }
       System.out.println("Vertebrado rinoceronte "+rinoceronte);

      
       Vertebrado cerdito=null;
       try{ 
          cerdito=new Vertebrado(rinoceronte);          
        }
        catch(numVertebrasIncorrecto | pesoIncorrecto e){
          System.out.println(e.getMessage());          
        }
        catch(Exception e){
          System.out.println("El error producido es desconocido "+e.getMessage());
        } 
         System.out.println("Vertebrado cerdito "+cerdito);   
       
       
    }
    
}
