/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto_animal;

import java.util.Scanner;

/**
 *
 * @author Profesor
 */
public class NewMain {

    public static char enCaracter(String cadena, int indice) throws RuntimeException
    {
        char letra;
        if (!(indice>=0 && indice<cadena.length()))
           throw new RuntimeException("Error, índice fuera de rango");    
        letra=cadena.charAt(indice);
        return letra;
            
    }
    
public static double acceso(double v[],int x) throws Exception{
        try{
            if (x>=0 && x<v.length)
                return v[x];
            else throw new RuntimeException("El índice "+x+" no existe");                    
        }
        catch(RuntimeException ex){
            throw ex;
        }
    } 
    
    public static int metodo()throws NumberFormatException{
    int valor=0;
    try{
        valor++;
        valor+=Integer.parseInt("W");
        valor++;
        System.out.println("Después de try "+valor);
    }catch(NumberFormatException e){
        valor+=Integer.parseInt("42");        
        System.out.println("Después de catch "+valor);
        throw e;
    }    
    finally{
        valor++;
        System.out.println("Finally "+valor);
    }
      valor++;
        System.out.println("Antes de salir "+valor);
     return valor;
    }
    
    
    public static int sumatorio(int n){
        if (n==1) return 1;
        else return n+sumatorio(n-1);
    }
    
    public static long factorial(int n){
        if (n==1) return 1;
        else return n*factorial(n-1);
    }

    public static int cifras(int n){
        if (n<10) return 1;
        else return 1+cifras(n/10);
    }
    
    public static int fibonacci(int n){
        if (n==1)return 1;
        else if (n==2) return 1;
        else return fibonacci(n-2)+fibonacci(n-1);
    }
    
    public static void main(String[] args) {
        
        System.out.println("Sumatorio hasta 5 "+sumatorio(5));
        System.out.println("Factorial hasta 5 "+factorial(5));
        System.out.println("Cifras de 1234 "+cifras(1234));
        System.out.println("término 6 de la serie de Fibonacci "+fibonacci(6));
        
       /* 
       Scanner teclado=new Scanner(System.in);
       System.out.print("Dime una palabra: ");
       String cadena=teclado.nextLine();
       
       try{ 
        System.out.println("La octava letra de "+cadena+" es: "+enCaracter(cadena,7));
       }
       catch(RuntimeException e){
          e.printStackTrace();
       }
       
      
       double v[]=new double[10];
       try{
       acceso(v,16);
       }
       catch(RuntimeException e)
       {
          System.out.println("RuntimeException"+e.getMessage());
       }
       catch(Exception ex){
           System.out.println("Exception"+ex.getMessage());
       }
 /*
      try{
          System.out.println(metodo());
      }
      catch(Exception e){
          System.out.println("Excepción de metod()");
          e.printStackTrace();
      }
*/
    }
    
}
