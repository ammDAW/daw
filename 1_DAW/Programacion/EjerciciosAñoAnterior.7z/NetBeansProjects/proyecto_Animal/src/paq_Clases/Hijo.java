/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package paq_Clases;

/**
 *
 * @author isabel
 */
public class Hijo {
    private String nombre;
    private Fecha fechaNac;

    //Constructor Patrón
    public Hijo(String nombre, Fecha fechaNac) {
        this.nombre = nombre;
        this.fechaNac = fechaNac;
    }

    //Llama al constructor Hijo(String, Fecha)
    public Hijo() {
        this("",new Fecha());
    }
    
    public Hijo(Hijo otro){
        this(otro.nombre, otro.fechaNac);
    }
    
    public Hijo(String nombre, int d, int m, int a)
    {  
        this(nombre,new Fecha(d,m,a));
        /*
        this.fechaNac=new Fecha(d,m,a);
        this.nombre=nombre;   
        */   
    }

    public String getNombre() {
        return this.nombre;
    }

    public Fecha getFechaNac() {
        return this.fechaNac;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setFechaNac(Fecha fechaNac) {
        this.fechaNac = fechaNac;
    }

    @Override
    public String toString() {
        return "Nombre=" + this.nombre + " Fecha de Nacimiento =" + this.fechaNac;
    }
    
    public int edad(Fecha fecha){
        int numDiasHastaFecha=fecha.toDias();
        int numDiasHastaFechaNac=this.fechaNac.toDias();
        
        int diferencia=numDiasHastaFecha - numDiasHastaFechaNac;
        int edad=diferencia/365;
        return edad;
    }
    
}
