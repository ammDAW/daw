/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package paq_Clases;

/**
 *
 * @author Alberto
 */
public class Fecha {
    
    private int dia, mes, anio;
    private static int MESES[]={0,31,28,31,30,31,30,31,31,30,31,30,31};
    /*
    Añadimos un dato para el mes 0 con 0 días, para que corresponda la posición del vector con el número real del mes.
    Por lo mismo, añadimos un dato extra a nombres para que la correspondencia siga ocurriendo
    */
    private final static String NOMBRES[]={" ","Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre"};
    
    public Fecha(int dia, int mes, int anio) {
        try {
            if (Fecha.esFechaCorrecta(dia, mes, anio)) {
                this.dia=dia;
                this.mes=mes;
                this.anio=anio;
            }
        } catch (IllegalArgumentException error) {
            System.out.println("No se acepta esta fecha, asignamos fecha por defecto. ");
            this.dia=1;
            this.mes=1;
            this.anio=2000;
        }
    }
    
    public Fecha() {
        this.dia=1;
        this.mes=1;
        this.anio=2000;
    }
    
    public Fecha(Fecha otra) {
        this(otra.dia, otra.mes, otra.anio);
    }
    
    private static boolean esBisiesto(int anio) {
        return (anio%4==0 && (anio%100!=0 || anio%400==0));
    }
    
    private static boolean esFechaCorrecta(int dia, int mes, int anio) throws IllegalArgumentException {
        boolean esFecha=false;
        if (anio>=1900 && anio<=3000) {
            if (mes>0 && mes<13) {
                if (Fecha.esBisiesto(anio))
                    MESES[2]=29;
                if (dia>0 && dia<=MESES[mes])
                    esFecha=true;
                MESES[2]=28;
            }
        } if(esFecha==false) {
            MESES[2]=28;
            throw new IllegalArgumentException("La fecha introducida es incorrecta. ");
        }
        return esFecha;
    }

    public int getDia() {
        return this.dia;
    }

    public int getMes() {
        return this.mes;
    }

    public int getAnio() {
        return this.anio;
    }
    
    public void setDia(int dia) throws IllegalArgumentException {
        if (Fecha.esBisiesto(anio))
                    MESES[2]=29;
        if (dia>0 && dia<=MESES[this.mes]){
            this.dia=dia;
            MESES[2]=28;
        }
        else {
            MESES[2]=28;
            throw new IllegalArgumentException("El día introdudido es incorrecto. ");
            }
    }
    
    public void setMes(int mes) throws IllegalArgumentException {
        if (0<mes && mes<13)
            this.mes=mes;
        else
            throw new IllegalArgumentException("El mes introdudido es incorrecto. ");
    }
    
    public void setAnio(int anio) throws IllegalArgumentException {
        if (anio>1900 && anio<3000)
            this.anio=anio;
        else
            throw new IllegalArgumentException("El año introdudido es incorrecto. ");
    }
    
    public void setFecha(int dia, int mes, int anio) {
        try {
            if (Fecha.esFechaCorrecta(dia, mes, anio)) {
                this.dia=dia;
                this.mes=mes;
                this.anio=anio;
            }
        } catch (IllegalArgumentException error) {
            System.out.println("No se acepta el cambio de fecha, asignamos fecha por defecto. ");
            this.dia=1;
            this.mes=1;
            this.anio=2000;
        }
    }
    
    public void setFecha(Fecha otra) {
        this.setFecha(otra.dia, otra.mes, otra.anio);
    }
    
    public void setFecha() {
        System.out.println("No se han introducido datos, cambiamos a fecha por defecto. ");
        this.dia=1;
        this.mes=1;
        this.anio=2000;
    }
    
    /*
    Creamos un toString por defecto para un uso rápido cuando sea necesario.
    */
    
    @Override
    public String toString() {
        return ("La fecha del día es "+this.dia+" de "+NOMBRES[this.mes]+" del "+this.anio);
    }
    
    public String toString(int caso) throws IllegalArgumentException {
        String fecha, dia, mes;
        if (this.dia<10)
            dia="0"+this.dia;
        else
            dia=String.valueOf(this.dia);
        if (this.mes<10)
            mes="0"+this.mes;
        else
            mes=String.valueOf(this.mes);
        
        switch (caso) {
            case 1: fecha=dia+"-"+mes+"-"+String.valueOf(anio).substring(2, 4); break;
            case 2: fecha=dia+"-"+mes+"-"+this.anio; break;
            case 3: fecha=dia+"-"+Fecha.NOMBRES[this.mes]+"-"+this.anio; break;
            case 4: fecha=dia+" de "+Fecha.NOMBRES[this.mes]+" de "+this.anio; break;
            case 5: fecha=dia+"/"+mes+"/"+String.valueOf(anio).substring(2, 4); break;
            case 6: fecha=dia+"/"+mes+"/"+this.anio; break;
            default: fecha="Selección de opción incorrecta, la fecha no se puede mostrar. ";
        }     
        return fecha;
    }
    public boolean equals(int dia, int mes, int anio) {
        return (this.dia==dia && this.mes==mes && this.anio==anio);
    }
    
    public boolean equals(Fecha otra) {
        return (this.dia==otra.dia && this.mes==otra.mes && this.anio==otra.anio);
    }
    
    @Override
    public Fecha clone() {
        return new Fecha(this);
    }
    
    @Override
    public void finalize() {
        System.out.println("Se ha destruido el objeto actual. ");
    }
    
    /*
    El método toDias comienza a contar desde el 1900 para permitir un rango de fechas más amplio
    */
    
    public int toDias() {
        int diaspasados=0;
        for (int i = 1900; i < this.anio; i++) {
            if (Fecha.esBisiesto(i))
                MESES[2]=29;
            for (int j = 0; j <= 12; j++) {
                diaspasados+=MESES[j];
            }
            MESES[2]=28;
        }
        if (Fecha.esBisiesto(this.anio)) 
            MESES[2]=29;
        for (int j = 0; j < this.mes; j++) {
            diaspasados+=MESES[j];
        }
        MESES[2]=28;   
        diaspasados+=this.dia;
        return diaspasados;
    }
    
    public Fecha fechaMayor(Fecha otra) {
        Fecha mayor=new Fecha();
        if (this.toDias()>otra.toDias())
            mayor.setFecha(this);
        else
            mayor.setFecha(otra);
        return mayor;
    }
    
    public Fecha fechaMenor(Fecha otra) {
        Fecha menor=new Fecha();
        if (this.toDias()<otra.toDias())
            menor.setFecha(this);
        else
            menor.setFecha(otra);
        return menor;
    }
    
    public int diasEntreFechas(Fecha otro) {
        if (this.equals(otro))
            return 0;
        else {
            Fecha mayor=new Fecha();
            Fecha menor=new Fecha();
            mayor.setFecha(this.fechaMayor(otro));
            menor.setFecha(this.fechaMenor(otro));
            return mayor.toDias()-menor.toDias()-1;
        }
    }
    
    public void fechaSiguiente() {
        this.dia+=1;
        if (Fecha.esBisiesto(this.anio)) {
            MESES[2]=29;
        }
        if (this.dia>MESES[this.mes]) {
            this.dia=1;
            this.mes+=1;
            if (this.mes>12) {
                this.mes=1;
                this.anio+=1;
            }
        }
        MESES[2]=28;
    }
    
    /*
    fechaSiguiente y fechaAnterior están hechos para modificar la fecha y no devolver una nueva, puesto que en el enunciado
    ponía que incrementa o decrementa en un día actual, y lo tomé literalmente en cuanto a que modificaba la fecha
    */
    
    public void fechaAnterior() {
        this.dia-=1;
        if (Fecha.esBisiesto(this.anio)) {
            MESES[2]=29;
        }
        if (this.dia<1) {
            this.dia=MESES[this.mes-1];
            this.mes-=1;
            if (this.mes-1<1) {
                this.anio-=1;
                this.mes=12;
                this.dia=MESES[12];
            }
        }
        MESES[2]=28;
    }
}