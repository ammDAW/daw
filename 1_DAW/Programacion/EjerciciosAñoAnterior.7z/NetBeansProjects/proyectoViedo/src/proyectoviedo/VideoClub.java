/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyectoviedo;

import java.util.ArrayList;

/**
 *
 * @author Profesor
 */
public class VideoClub {
    private String nombre;
    private ArrayList <Cliente> clientes=new ArrayList();

    public VideoClub(String nombre) {
        this.nombre = nombre;
        this.clientes=new ArrayList();
    }

       
    public VideoClub(String nombre, ArrayList<Cliente> clientes) {
        this.nombre = nombre;
        this.clientes = new ArrayList(clientes);
    }

    
    public String getNombre() {
        return nombre;
    }

    public ArrayList<Cliente> getClientes() {
        return clientes;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setClientes(ArrayList<Cliente> clientes) {
        this.clientes = new ArrayList(clientes);
    }

    
    @Override
    public String toString() {
        String cadena= "Nombre=" + this.nombre+"\n";
        if( !this.clientes.isEmpty())
            for(Cliente cl: this.clientes)
                cadena+=cl+"\t";
                        
        return cadena;
    }
    
    
    
    
    
}
