/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyectoviedo;

import java.util.ArrayList;

/**
 *
 * @author Profesor
 */
public class Ppal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       Cliente c1=new Cliente("Sergio",12);
       Cliente c2=new Cliente("Luis",34);
       Cliente c3=new Cliente("Alberto",67);
       Cliente c4=new Cliente("Julio",12);
       Cliente c5=new Cliente("Paco",45);
       
       ArrayList <Cliente> lista=new ArrayList();
       lista.add(c1);
       lista.add(c2);
       lista.add(c3);
       lista.add(c4);
       lista.add(c5);
       
        System.out.println("------LISTADO DE CLIENTES----------------");
        for(Cliente c: lista)
            System.out.println("Cliente "+c);
        
        VideoClub circo=new VideoClub("Teatro Circo",lista);
        System.out.println("-------------Videoclub---------------------");
        System.out.println(circo);
        
        VideoClub azorin=new VideoClub("Lo veo todo",lista);
        System.out.println("-------------Videoclub---------------------");
        System.out.println(azorin);
          
        System.out.println("-------------Videoclub---------------------");
        System.out.println(circo);
        lista=circo.getClientes();
        for(int i=0;i<lista.size();i++)
            if (lista.get(i).equals("Sergio"))
                lista.get(i).setNombre("Antonio");
       
        System.out.println("-------------Videoclub---------------------");
        System.out.println(circo);
        
        
        System.out.println("-------------Videoclub---------------------");
        System.out.println(azorin);
       
        
        
        
       
       
    }
    
}
