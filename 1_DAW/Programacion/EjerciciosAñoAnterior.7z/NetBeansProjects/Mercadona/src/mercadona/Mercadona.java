/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mercadona;

import paq_Clases.Bebida;
import paq_Clases.Bolleria;
import paq_Clases.Drogueria;
import paq_Clases.Fecha;
import paq_Clases.Fruta;
import paq_Excepciones.FechaCaducidadException;
import paq_Excepciones.PaisFabricacionException;
import paq_Excepciones.PesoException;
import paq_Excepciones.PrecioException;

/**
 *
 * @author isabel
 */
public class Mercadona {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       Cesta cs=new Cesta();
       Fruta f1=null;
       try{
           f1=new Fruta(2,"peras","SP",2,new Fecha(7,6,2019));
       }catch(PesoException | PaisFabricacionException | FechaCaducidadException | PrecioException e){
           System.out.println(e.getMessage());
       }       
       catch(Exception t){
           System.out.println("Error desconocido");
       }
       
       Fruta f2=new Fruta(2,"manzanas","FR",2,new Fecha(10,6,2019));
       Bolleria b1=new Bolleria("donut","FR",0.5,new Fecha(1,6,2019));
       Bebida b2=new Bebida("RedBull","UK",1.25,new Fecha(12,3,2023));
       Drogueria dr=new Drogueria("detergente","SP",2,new Fecha(23,3,2020));
       cs.addArticulo(dr);
       cs.addArticulo(f1);
       cs.addArticulo(f2);
       cs.addArticulo(b1);
       cs.addArticulo(b2);
       cs.mostrarArticulosCaducados(new Fecha(30,5,2019));
       System.out.println("Total de calorías :"+cs.obtenerTotalCalorias());
       System.out.println("Precio de Artículos Tóxicos :"+cs.precioArticulosToxicos()); 
       cs.mostrarArticulosAgrupados();
       cs.mostrarArticulosPais("SP");
       System.out.println("La fruta que más pesa es :"+cs.obtenerFrutaMayorPeso());
    }
    
}
