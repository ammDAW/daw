/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mercadona;

import java.util.ArrayList;
import paq_Clases.Alimentacion;
import paq_Clases.Articulo;
import paq_Clases.Bebida;
import paq_Clases.Bolleria;
import paq_Clases.Drogueria;
import paq_Clases.Fecha;
import paq_Clases.Fruta;
import paq_Interfaces.Vendible;

/**
 *
 * @author isabel
 */
public class Cesta {
    private ArrayList<Articulo> listaArticulos;
   
    public Cesta() {
        this.listaArticulos=new ArrayList();
    }
    
    public void addArticulo(Articulo a){
        if (!this.listaArticulos.contains(a)){
            this.listaArticulos.add(a);
        }
    }
    
    public void mostrarArticulosCaducados(Fecha hoy){
        System.out.println("LISTA DE ARTÍCULOS CADUCADOS");
        for(Articulo a: this.listaArticulos){
            a.comprobarCaducidad(hoy);
            if (a.isCaducado()) System.out.println("-"+a);
        }    
    }
    
    public int obtenerTotalCalorias(){
        int sumaCalorias=0;
        for(Articulo a: this.listaArticulos){
            if (a instanceof Alimentacion) sumaCalorias+=((Alimentacion) a).getCalorias();                       
            else if (a instanceof Bebida) sumaCalorias+=((Bebida)a).getCalorias();
           /* También
            if (a instanceof Bolleria) sumaCalorias+=((Bolleria) a).getCalorias();                       
            else if (a instanceof Fruta) sumaCalorias+=((Fruta)a).getCalorias();
            else if (a instanceof Bebida) sumaCalorias+=((Bebida)a).getCalorias();
           */ 
        }
        return sumaCalorias;
    }
    
    public double precioArticulosToxicos(){
        double sumaPrecioToxicos=0;
        System.out.println("LISTADO DE PRODUCTOS TOXICOS");
        for(Articulo a: this.listaArticulos){
            if (a instanceof Bebida)
            {
               System.out.println("- "+a+"\t"+((Bebida) a).getAdvertencia()); 
               sumaPrecioToxicos+=a.getPrecioIva();
            }
            else if (a instanceof Drogueria)
            {
                System.out.println("- "+a+"\t"+((Drogueria) a).getAdvertencia());
                sumaPrecioToxicos+=a.getPrecioIva();
            }
        }
        return sumaPrecioToxicos;
    }
    
    public void mostrarArticulosAgrupados(){
        System.out.println("LISTADO DE FRUTA ");
        for(Articulo a: this.listaArticulos)
            if (a instanceof Fruta)
                System.out.println("-"+a.toString());
            
        System.out.println("LISTADO DE BOLLERÍA ");    
        for(Articulo a: this.listaArticulos)
            if (a instanceof Bolleria)
                System.out.println("-"+a.toString());

        System.out.println("LISTADO DE BEBIDA ");    
        for(Articulo a: this.listaArticulos)
            if (a instanceof Bebida)
                System.out.println("-"+a.toString());

        System.out.println("LISTADO DE DROGUERÍA ");    
        for(Articulo a: this.listaArticulos)
            if (a instanceof Drogueria)
                System.out.println("-"+a.toString());
    }
    
    public String obtenerFrutaMayorPeso(){
      String nombreFruta=null;
      int pesoMayor=0;
      for(Articulo a:this.listaArticulos)
          if (a instanceof Fruta)
              if (pesoMayor < ((Fruta) a).getPeso())
              {
                  nombreFruta=a.getNombre();
                  pesoMayor=((Fruta) a).getPeso();
              }
      
      return nombreFruta;
    }    
    
   public void mostrarArticulosPais(String pais){
       System.out.println("LISTADO DE ARTÍCULOS CUYO ORIGEN ES DE "+pais);
       for(Articulo a: this.listaArticulos)
           if (a.getPais().equalsIgnoreCase(pais))
               System.out.println("-"+a);
   } 
}