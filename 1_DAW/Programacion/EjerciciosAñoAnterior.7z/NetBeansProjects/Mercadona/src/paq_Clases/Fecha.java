package paq_Clases;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author jmompou
 */
public class Fecha {
        
private int dia, mes, anio;
private static int meses[]={0,31,28,31,30,31,30,31,31,30,31,30,31};

public Fecha(int dia, int mes, int anio){
    this.dia=dia; this.mes=mes;this.anio=anio;
}

public Fecha(){this(1,1,2000);}

private static boolean bisiesto(int anio)
{
    return (anio%4==0)?true:false;
}
  

@Override
public String toString(){
    return this.dia+"-"+this.mes+"-"+this.anio;
}

public int toDias(){
int Numero_dias=0;
Fecha fecha_referencia=new Fecha();
int ano=fecha_referencia.anio;

while(!(ano==this.anio)){ 
    if (Fecha.bisiesto(ano)){
        Numero_dias++;
      }
ano++;
}

  
for (int i=1;i<this.mes;i++)
    Numero_dias+=meses[i];


return Numero_dias+=this.dia+(this.anio-fecha_referencia.anio)*365;


}

public boolean fechaMayor(Fecha hoy){
    boolean mayor;
    if (this.toDias() > hoy.toDias())
        mayor=true;
    else 
        mayor=false;
    return mayor;
    
    //return (this.toDias()>hoy.toDias());
}




}
