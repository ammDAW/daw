/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package paq_Clases;

import paq_Excepciones.FechaCaducidadException;
import paq_Excepciones.PaisFabricacionException;
import paq_Excepciones.PrecioException;

/**
 *
 * @author isabel
 */
public class Bolleria extends Alimentacion {

    public Bolleria(String nombre, String pais, double precio, Fecha fechaCaducidad) throws PaisFabricacionException, PrecioException, FechaCaducidadException {
        super(nombre, pais, precio, fechaCaducidad);
        this.calorias=50;
        this.iva=0.12;        
    }
    @Override
    public double getPrecioIva(){ return (this.precio*(1+this.iva));}
    @Override
    public int getCalorias(){return this.calorias;}

    @Override
    public String toString() {
        return "Bollería{" +"Nombre= "+nombre+" Pais= "+pais+" Precio="+precio+" Fecha de Caducidad= "+fechaCaducidad+ " Iva=" + getPrecioIva() + '}';
    }
    
    
}
