/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package paq_Clases;

import paq_Excepciones.FechaCaducidadException;
import paq_Excepciones.PaisFabricacionException;
import paq_Excepciones.PesoException;
import paq_Excepciones.PrecioException;

/**
 *
 * @author isabel
 */
public class Fruta extends Alimentacion{
    private int peso;
   
    public Fruta(int peso, String nombre, String pais, double precio, Fecha fechaCaducidad) throws PaisFabricacionException, PrecioException, FechaCaducidadException, PesoException {
        super(nombre, pais, precio, fechaCaducidad);
        if (peso <=0)
            throw new PesoException();
        if (peso <10)
            this.precio*=0.1;
        this.peso = peso;
        this.iva=0.04;
        this.calorias=0;
    }
    public int getPeso() {
        return peso;
    }
   
    @Override
    public double getPrecioIva(){ return ((this.precio)*(1+this.iva));}

    @Override
    public int getCalorias(){return this.calorias;}

    @Override
    public String toString() {
        return "Fruta{" +"Nombre= "+nombre+" Pais= "+pais+" Precio="+precio+" Fecha de Caducidad= "+fechaCaducidad+" Peso= " + peso + " Iva=" + getPrecioIva() + '}';
    }
    
    
    
}
