/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package paq_Clases;

import paq_Excepciones.FechaCaducidadException;
import paq_Excepciones.PaisFabricacionException;
import paq_Excepciones.PrecioException;
import paq_Interfaces.Calorica;
import paq_Interfaces.Intoxicable;

/**
 *
 * @author isabel
 */
public class Bebida extends Articulo implements Calorica, Intoxicable{
    private int calorias;

    public Bebida(String nombre, String pais, double precio, Fecha fechaCaducidad) throws PaisFabricacionException, PrecioException, FechaCaducidadException {
        super(nombre, pais, precio, fechaCaducidad);
        Articulo.numArticulos++;
        String strNumero=String.valueOf(Articulo.numArticulos);
        while (strNumero.length()<3) strNumero='0'+strNumero;
        this.codigo=strNumero+'-'+"BE"+"-"+pais;
        this.calorias = 200;
        this.iva=0.21;
    }
    
     @Override
    public double getPrecioIva(){ return (this.precio*(1+this.iva));}
    
    @Override
    public int getCalorias(){return this.calorias;}

    @Override
    public String toString() {
        return "Bebida{" +"Nombre= "+nombre+" Pais= "+pais+" Precio="+precio+" Fecha de Caducidad= "+fechaCaducidad+ " Iva=" + getPrecioIva() + '}';
    }
    
    @Override
    public String getAdvertencia(){ return "Si la bebida lleva alcohol NO conduzcas";}
}
