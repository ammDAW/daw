/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package paq_Clases;

import paq_Excepciones.FechaCaducidadException;
import paq_Excepciones.PaisFabricacionException;
import paq_Excepciones.PrecioException;
import paq_Interfaces.Caducable;
import paq_Interfaces.Vendible;


public abstract class Articulo implements Vendible, Caducable {
    protected static int numArticulos=0;
    protected static String paises[]={"SP","FR","UK"};
    protected String codigo;
    protected String nombre;
    protected String pais;
    protected double precio;
    protected Fecha fechaCaducidad;
    protected boolean caducado;
    protected double iva;

    public Articulo(String nombre, String pais, double precio, Fecha fechaCaducidad) throws PaisFabricacionException, PrecioException, FechaCaducidadException  {
        this.nombre = nombre;
        //if (!pais.equalsIgnoreCase("SP") && !pais.equalsIgnoreCase("FR") && !pais.equalsIgnoreCase("UK") )
        boolean encontrado=false;
        for(int i=0;i<paises.length;i++)
            if (paises[i].equalsIgnoreCase(pais))
            {
                encontrado=true;                
                break;
            }
        
        if (!encontrado) throw new PaisFabricacionException("País erróneo");
        this.pais = pais;
        
        if (precio <=0) throw new PrecioException("Precio erróneo");
        this.precio = precio;
        
        if (! fechaCaducidad.fechaMayor(new Fecha(31,5,2019)))
            throw new FechaCaducidadException("El artículo nuevo está caducado ya");
        
        this.fechaCaducidad = fechaCaducidad;
        this.caducado=false;
    }

    public Articulo(String codigo) {
        this.codigo = codigo;
    }

    public static int getNumArticulos() {
        return numArticulos;
    }

    public static String[] getPaises() {
        return paises;
    }

    public String getCodigo(){
        return this.codigo;
    }
    
    public String getNombre() {
        return nombre;
    }

    public String getPais() {
        return pais;
    }

    public double getPrecio() {
        return precio;
    }

    public Fecha getFechaCaducidad() {
        return fechaCaducidad;
    }

    public boolean isCaducado() {
        return caducado;
    }

    
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setPais(String pais) throws PaisFabricacionException{
        boolean encontrado=false;
        for(int i=0;i<paises.length;i++)
            if (paises[i].equalsIgnoreCase(pais))
            {
                encontrado=true;                
                break;
            }
        
        if (!encontrado) throw new PaisFabricacionException("País erróneo");

        this.pais = pais;
    }

    public void setPrecio(double precio) throws PrecioException{
        if (precio <1) throw new PrecioException("Precio erróneo");
        this.precio = precio;
    }

    public void setFechaCaducidad(Fecha fechaCaducidad) throws FechaCaducidadException{
         if (! fechaCaducidad.fechaMayor(new Fecha(31,5,2019)))
            throw new FechaCaducidadException("El artículo nuevo está caducado ya");
       
        this.fechaCaducidad = fechaCaducidad;
    }

    public void setCaducado(boolean caducado) {
        this.caducado = caducado;
    }
    
    @Override
    public void comprobarCaducidad(Fecha hoy){
        if (! this.fechaCaducidad.fechaMayor(hoy)){
            this.caducado=true;           
        }    
    }
    
    
}
