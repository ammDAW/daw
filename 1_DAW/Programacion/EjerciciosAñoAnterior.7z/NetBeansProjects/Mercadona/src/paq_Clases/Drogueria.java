/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package paq_Clases;

import paq_Excepciones.FechaCaducidadException;
import paq_Excepciones.PaisFabricacionException;
import paq_Excepciones.PrecioException;
import paq_Interfaces.Intoxicable;

/**
 *
 * @author isabel
 */
public class Drogueria extends Articulo implements Intoxicable{
    public Drogueria(String nombre, String pais, double precio, Fecha fechaCaducidad) throws PaisFabricacionException, PrecioException, FechaCaducidadException {
        super(nombre, pais, precio, fechaCaducidad);
        Articulo.numArticulos++;
        String strNumero=String.valueOf(Articulo.numArticulos);
        while (strNumero.length()<3) strNumero='0'+strNumero;
        this.codigo=strNumero+'-'+"DR"+"-"+pais;
        this.iva=0.21;
    }
    
     @Override
    public double getPrecioIva(){ return (this.precio*(1+this.iva));}
    
    
    @Override
    public String toString() {
        return "Droguería{" +"Nombre= "+nombre+" Pais= "+pais+" Precio="+precio+" Fecha de Caducidad= "+fechaCaducidad+ " Iva=" + getPrecioIva() + '}';
    }
    
    @Override
    public String getAdvertencia(){ return "En caso de intoxicación, debe llamar al número 900";}
}
