/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package paq_Clases;

import paq_Excepciones.FechaCaducidadException;
import paq_Excepciones.PaisFabricacionException;
import paq_Excepciones.PrecioException;
import paq_Interfaces.Calorica;

/**
 *
 * @author isabel
 */
public abstract class Alimentacion extends Articulo implements Calorica{
    protected int calorias;

    public Alimentacion(String nombre, String pais, double precio, Fecha fechaCaducidad) throws PaisFabricacionException, PrecioException, FechaCaducidadException {
        super(nombre, pais, precio, fechaCaducidad);
        Articulo.numArticulos++;
        String strNumero=String.valueOf(Articulo.numArticulos);
        while (strNumero.length()<3) strNumero='0'+strNumero;
        this.codigo=strNumero+'-'+"AL"+this.pais;
    }
    
    
}
