/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package paq_Interfaces;

import paq_Clases.Fecha;
import paq_Excepciones.FechaCaducidadException;

/**
 *
 * @author isabel
 */
public interface Caducable {
    public void comprobarCaducidad(Fecha hoy);
}
