/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mvc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author Profesor
 */
public class Conexion {
    private Connection conexion=null;
    
    public Conexion(){
      String url="jdbc:mysql://localhost:3306/java";
      String user="root";
      String password="";

      try{  
          Class.forName("com.mysql.jdbc.Driver");
          this.conexion=DriverManager.getConnection(url, user, password);
      }
      catch(ClassNotFoundException e){
          System.out.println("Error, la biblioteca NO está añadida");
      }
      catch(SQLException e)
      {
          System.out.println("La base de datos o las credenciales son incorrectas");
      }
      catch(Exception x)
      {
          System.out.println("Error desconocido");
      }
    }
       
    public void desconectar(){
      try{
         this.conexion.close();
      }catch(SQLException e){
          System.out.println("Es posible que Usted NO estuviera conectado");
      }
    }
    
    public void listadoCompletoEmpleados(){
        //Realizar SELECT * FROM emp;
        //1. Diseño del SELECT
        
        String select="SELECT * FROM emp";
        
        //2. Crear o preparar la instrucción SELECT en Java
        try{
          PreparedStatement sentencia=conexion.prepareStatement(select);
          ResultSet cursor=sentencia.executeQuery();
            System.out.println("---LISTADO DE EMPLEADOS---");
            System.out.println("Id\tNombre\tDepartamento");
            cursor.last();            
            int numFilas=cursor.getRow();
            cursor.beforeFirst();
            for(int registro=1; registro<=numFilas; registro++){
                cursor.next();
                System.out.println(cursor.getInt(1)+"\t"+cursor.getString(2)+"\t"+cursor.getInt(3));     
            }
           /*
            while(cursor.next())
            {
              System.out.println(cursor.getInt("id")+"\t"+cursor.getString("nombre")+"\t"+cursor.getInt("depart"));   
            }*/            
        }catch(SQLException e){
            System.out.println("La instrucción está mal diseñada "+select);
        }
    }
    
    public void busquedaIdEmpleado(int id){
        //Diseñar el select
        String select="SELECT * FROM emp WHERE id="+id;
        //Se prepara la sentencia y se ejecuta
        try{
           PreparedStatement sentencia=this.conexion.prepareStatement(select);
           ResultSet cursor=sentencia.executeQuery();
           cursor.last();
           int numFilas=cursor.getRow();
           if (numFilas==0)
               System.out.println("El empleado con la id="+id+" no existe");
           else           
               System.out.println(cursor.getInt("id")+"\t"+cursor.getString("nombre")+"\t"+cursor.getInt("depart"));    
                  
        }catch(SQLException e){
            System.out.println("Select mal diseñado: "+select);
        }
    }
    
    public void listadoEmpleadosPorNombre(String name){
        //Diseño del select
        String select="SELECT * FROM emp WHERE nombre='"+name+"'";
        //Se prepara la sentencia y se ejecuta
        try{
            PreparedStatement sentencia=this.conexion.prepareStatement(select);
            ResultSet cursor=sentencia.executeQuery();
            cursor.last();
            int numFilas=cursor.getRow();
            if (numFilas==0)
                System.out.println("No existen empleados llamados "+name);
            else{
                System.out.println("LISTADO DE EMPLEADOS CUYO NOMBRE ES "+name);
                System.out.println("Id\tNombre\tDepartamento");
                cursor.beforeFirst();
                while(cursor.next())
                   System.out.println(cursor.getInt(1)+"\t"+cursor.getString(2)+"\t"+cursor.getInt(3));         
                
                System.out.println("\nSe han mostrado: "+numFilas+" empleados");
            }
        }catch(SQLException ex){
            System.out.println("Select mal diseñado "+select);
        }       
    }
    
    public void listadoEmpleadosPorDepartamentos(){
        //Diseño de select
        String select="SELECT emp.id id, emp.nombre nombre, departamento.nombre departamento";
        select+=" FROM emp, departamento WHERE emp.depart=departamento.id";
        //Prepara la sentencia y la ejecuta
        try{
            PreparedStatement sentencia=this.conexion.prepareStatement(select);
            ResultSet cursor=sentencia.executeQuery();
            cursor.last();
            int numFilas=cursor.getRow();
            if (numFilas==0)
                System.out.println("La tabla de empleados está vacía");
            else{
                System.out.println("LISTADO DE EMPLEADOS");
                System.out.println("Id\tNombre\tDepartamento");
                cursor.beforeFirst();
                while(cursor.next())
                   System.out.println(cursor.getInt(1)+"\t"+cursor.getString(2)+"\t"+cursor.getString(3));         
                
                System.out.println("\nSe han mostrado: "+numFilas+" empleados");
            }
        }catch(SQLException ex){
            System.out.println("Select mal diseñado "+select);
        }
        
    }

    //Usando el executeUpdate
    //Se utiliza para DML (excepto SELECT), DDL (create table, drop table, alter table, create view, ..)
    //Se utiliza también para DCL (grant, create user...)
    public void modificarNombreEmpleado(String name, int id){
        String update="UPDATE emp SET nombre='"+name+"' ";
        update+=" WHERE id="+id;
      
        //Prepara la sentencia y la ejecuta
        //Ejecuta executeUpdate
       try{ 
          PreparedStatement sentencia=this.conexion.prepareStatement(update);
          int numFilasAfectadas=sentencia.executeUpdate();
          System.out.println("Se han modificado "+numFilasAfectadas+" empleados");
       }catch(SQLException ex){
           System.out.println("Error, sentencia SQL mal formada"+update);
       }       
    } 
    
    public void insertarNuevoDpto(String name){
        String insert="INSERT INTO departamento(nombre) VALUES ('"+name+"')";
               
      
        //Prepara la sentencia y la ejecuta
        //Ejecuta executeUpdate
       try{ 
          PreparedStatement sentencia=this.conexion.prepareStatement(insert);
          int numFilasAfectadas=sentencia.executeUpdate();
          System.out.println("Se han insertado "+numFilasAfectadas+" dptos");
       }catch(SQLException ex){
           System.out.println("Error, sentencia SQL mal formada"+insert)    ;
       }       
    }
    
    public void insertarNuevoEmpleado(String nombreEmpleado, String nombreDpto){
       String selectIdDpto="SELECT id FROM departamento WHERE nombre='"+nombreDpto+"'";        
       int idDpto=0;
       try{
           PreparedStatement sentencia1=this.conexion.prepareStatement(selectIdDpto);
           ResultSet cursor=sentencia1.executeQuery();
           cursor.last();
           int numFilas=cursor.getRow();
                 
           if (numFilas==0){ //El Departamento NO Existe 
              insertarNuevoDpto(nombreDpto);           
              String select="SELECT id FROM departamento WHERE nombre='"+nombreDpto+"'";
              try{
                 PreparedStatement sentencia2=this.conexion.prepareStatement(select);
                 ResultSet cursor1=sentencia2.executeQuery();
                 cursor1.last();
                 idDpto=cursor1.getInt("id");
              }catch(SQLException ex){
               System.out.println("Error, el id no se pudo encontrar " );
             }
              
           }
           else //El departamento existe
               idDpto=cursor.getInt("id"); 
           
           String insert="INSERT INTO emp(nombre,depart) ";
           insert+="VALUES ('"+nombreEmpleado+"',"+idDpto+")";
           try{
               PreparedStatement sentencia3=conexion.prepareStatement(insert);
               int x=sentencia3.executeUpdate();
               System.out.println("Insertados "+x+" empleados");
           } catch(SQLException et){
               System.out.println("Insert mal diseñado "+insert);
           }
       }catch(SQLException ex){
           System.out.println("Select mal formado "+selectIdDpto);
       }
       
    }
    
    public ArrayList <Emp> devuelveEmpleadosDpto(int idDpto){
        //Devuelve un ArrayList con los valores de aquellos empleados que 
        // pertenezcan al mismo departamento
        ArrayList <Emp> lista=new ArrayList();
        
        String select="SELECT * FROM emp WHERE depart="+idDpto;
        try{
            PreparedStatement sentencia=conexion.prepareStatement(select);
            ResultSet cursor=sentencia.executeQuery();
            cursor.last();
            int numFilas=cursor.getRow();
            if (numFilas==0)
                System.out.println("El departamento no existe o no tiene empleados");
            else{
             cursor.beforeFirst();
             while(cursor.next())
                 lista.add(new Emp(cursor.getInt(1), cursor.getString(2),cursor.getInt(3)));
            }
        }
        catch(SQLException e){
            System.out.println("Select mal diseñado "+select);
        }
        
        
        return lista;
    }
    
}
