/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mvc;

/**
 *
 * @author Profesor
 */
public class Emp {
    private int id;
    private String nombre;
    private int depart;

    public Emp(int id, String nombre, int depart) {
        this.id = id;
        this.nombre = nombre;
        this.depart = depart;
    }

    public int getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public int getDepart() {
        return depart;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setDepart(int depart) {
        this.depart = depart;
    }

    @Override
    public String toString() {
        return "Identificador ->" + id + " Nombre=" + nombre + " Departamento=" + depart;
    }
    
    
}
