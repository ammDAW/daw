/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mvc;

import java.util.ArrayList;

/**
 *
 * @author Profesor
 */
public class Vista {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Conexion conexion=new Conexion();
        
       /*
        conexion.listadoCompletoEmpleados();
      
        conexion.busquedaIdEmpleado(10);
        
        conexion.listadoEmpleadosPorNombre("Fatima");
        
        conexion.listadoEmpleadosPorDepartamentos();
        
       
        conexion.modificarNombreEmpleado("Sergio", 1);
        conexion.listadoCompletoEmpleados();
        
        conexion.insertarNuevoDpto("Contabilidad");
        
        conexion.insertarNuevoEmpleado("Castaño", "Administracion");
        conexion.listadoCompletoEmpleados();
        
        */
        ArrayList <Emp>  array=conexion.devuelveEmpleadosDpto(1);
        System.out.println("----LISTADO DE EMPLEADOS DEL DEPARTAMENTO "+1);
        System.out.println("Nombre");
        for(Emp e: array)
            System.out.println("-"+e.getNombre());
                   
        conexion.desconectar();        
    }
    
}
