/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejemplodb;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author Profesor
 */
public class EjemploDB {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    /*     
     // Comprobar si el Driver está en la Biblioteca   
      try{  
       Class.forName("com.mysql.jdbc.Driver");
      }
      catch(ClassNotFoundException e){
          System.out.println("Error, la biblioteca NO está añadida");
      }
      //Cargar el driver, seleccionar la BD's, usuario y contraseña
      // y establece la conexión
      Connection conexion=null;
      String url="jdbc:mysql://localhost:3306/java";
      String user="root";
      String password="";
      try{
         conexion=DriverManager.getConnection(url, user, password);
      }catch(SQLException e)
      {
          System.out.println("La base de datos o las credenciales son incorrectas");
      }
        
        System.out.println("Usted está ya conectado a MySQL");
      
     */
    
     //Resumen de lo anterior
      Connection conexion=null;
      String url="jdbc:mysql://localhost:3306/java";
      String user="root";
      String password="";

      try{  
          Class.forName("com.mysql.jdbc.Driver");
          conexion=DriverManager.getConnection(url, user, password);
      }
      catch(ClassNotFoundException e){
          System.out.println("Error, la biblioteca NO está añadida");
      }
      catch(SQLException e)
      {
          System.out.println("La base de datos o las credenciales son incorrectas");
      }
      catch(Exception x)
      {
          System.out.println("Error desconocido");
      }
     
      if (conexion!=null){
        System.out.println("Usted está conectado");
        
        //Realizar SELECT * FROM emp;
        //1. Diseño del SELECT
        
        String select="SELECT * FROM emp";
        
        //2. Crear o preparar la instrucción SELECT en Java
        try{
          PreparedStatement sentencia=conexion.prepareStatement(select);
          ResultSet cursor=sentencia.executeQuery();
            System.out.println("---LISTADO DE EMPLEADOS---");
            System.out.println("Id\tNombre\tDepartamento");
            while(cursor.next())
            {
              System.out.println(cursor.getInt("id")+"\t"+cursor.getString("nombre")+"\t"+cursor.getInt("depart"));   
            }            
        }catch(SQLException e){
            System.out.println("La instrucción está mal diseñada "+select);
        }        
      }
      
      //Desconexión
      try{
         conexion.close();
      }catch(SQLException e){
          System.out.println("Es posible que Usted NO estuviera conectado");
      }
      
      
    }   
}
