/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package paquete_Funciones;

import java.util.ArrayList;

/**
 *
 * @author Profesor
 */
public class Ppal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Funcion f1=new Funcion("El Rey León",4);
        Funcion f2=new Funcion("Los vengadores",5);
        
        ArrayList <Funcion> funcionesExteriores=new ArrayList();
        funcionesExteriores.add(f1);
        funcionesExteriores.add(f2);
        
        //Mostrar las funciones
        if (funcionesExteriores.isEmpty())
            System.out.println("No hay funciones todavía ....");
        else
            for(int i=0; i < funcionesExteriores.size(); i++)
                System.out.println(funcionesExteriores.get(i));
        
        //Mostrar de todas las funciones del ArrayList el nombre de la Funcion
        System.out.println("LISTADO DE LOS NOMBRES DE LAS FUNCIONES DE LA LISTA");
        if (funcionesExteriores.isEmpty())
            System.out.println("No hay funciones todavía ....");
        else
            for(int i=0; i < funcionesExteriores.size(); i++)
                System.out.println((i+1)+" "+funcionesExteriores.get(i).getNombre());
        
        //Para cada Funcion f dentro de la lista funcionesExteriores
        System.out.println("LISTADO DE FUNCIONES USANDO FOREACH");
        for(Funcion f: funcionesExteriores)
            System.out.println(f);
        /* 
        int v []={12,13,14,15,16,17,18,19,20};
        for(int x: v)
            System.out.println(x);
        */
        
        System.out.println("LISTADO DE FUNCIONES USANDO ForEach");
        funcionesExteriores.forEach((f) -> System.out.println(f));
        
        System.out.println("LISTADO DE LOS NOMBRES DE TODAS LAS FUNCIONES DE LA LISTA");
        for(Funcion f: funcionesExteriores)
            System.out.println(f.getNombre());

        System.out.println("LISTADO DE LOS NOMBRES DE TODAS LAS FUNCIONES");
        funcionesExteriores.forEach((f) -> System.out.println(f.getNombre()));
        
        //
        System.out.println("LISTADO DE AQUELLAS FUNCIONES DE LA LISTA CUYO PRECIO SEA SUPERIOR A 4€");
        for(Funcion f: funcionesExteriores)
            if (f.getPrecio()> 4)
                System.out.println(f);
        
        //Comprobar si la función f1 se encuentra en la lista de funciones
        if (funcionesExteriores.contains(f1))
            System.out.println("La Función "+f1+" está en la lista");
        else
            System.out.println("La Función "+f1+" NO está en la lista");
        
        //Se quiere quitar la función f1 de la lista
        if (funcionesExteriores.contains(f1))
            funcionesExteriores.remove(f1);
        
        //Se quiere añadir la función f2, eso sí que NO esté repetida
        if (!(funcionesExteriores.contains(f2)))
             funcionesExteriores.add(f2);
        else
            System.out.println("La función "+f2+" ya existe en la lista");
        
        
        
    }
    
}
