/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package paqueteTeatro;


import java.util.ArrayList;
import paquete_Funciones.Funcion;

/**
 *
 * @author Profesor
 */
public class Teatro {
    private String nombre;
    private ArrayList <Funcion> listaFunciones=new ArrayList();

          
    public Teatro(String nombre)
    {
        this.nombre=nombre;        
    }
       
    public String getNombre() {
        return this.nombre;
    }

    public ArrayList<Funcion> getListaFunciones() {
        return this.listaFunciones;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setListaFunciones(ArrayList<Funcion> listaFunciones) {
        this.listaFunciones = listaFunciones;
    }
    
    public void addFuncion(Funcion f){
     if ( ! this.listaFunciones.contains(f))   
        this.listaFunciones.add(f);
     else
        System.out.println("La función "+f+" Ya existe en el teatro");
    }
    
    public boolean containsFuncion(Funcion f){
        return this.listaFunciones.contains(f);
    }
    
    public void removeFuncion(Funcion f) throws IllegalArgumentException
    {
       /* 
        if (this.listaFunciones.contains(f))
            this.listaFunciones.remove(f);
        else
            throw new IllegalArgumentException("La función no se puede borrar");
        */
        
        //Con for(Funcion f: this.listaFunciones) 
        // No permite realizar modificaciones en la lista 
        // Añadir o quitar una función
        
        boolean encontrado=false;
        for(int i=0; i<this.listaFunciones.size(); i++)
            if (this.listaFunciones.get(i).equals(f))
            {  
                this.listaFunciones.remove(f);
                encontrado=true;
                break;
            }
      
        
        if (!encontrado)
            throw new IllegalArgumentException("NO se puede borrar la función");
        
    }
    
    
    public String toString(){
        String cadena=this.nombre+"\n";
        if (!this.listaFunciones.isEmpty())
        {
            cadena+="LISTADO DE LAS FUNCIONES \n";
            for(Funcion f : this.listaFunciones)
                cadena+=f+"\n";
        }
        return cadena;
    }
}
