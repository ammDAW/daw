/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package paqueteTeatro;

import java.util.ArrayList;
import paquete_Funciones.Funcion;

/**
 *
 * @author Profesor
 */
public class PpalTeatro {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Teatro t=new Teatro("Romea");
        Funcion f1=new Funcion("Star Wars III",12);
        
        //Añadir la función f1 al teatro t
        t.addFuncion(f1);
        
        //Obtener la lista de funciones del teatro t
        ArrayList <Funcion> lista=t.getListaFunciones();
        //Muestra todas la funciones del teatro t
        for(Funcion f: lista)
            System.out.println(f);
        
        //Muestra todas las funciones del teatro t
        System.out.println("LISTADO DE FUNCIONES DEL TEATRO "+t.getNombre());
        for(Funcion f: t.getListaFunciones())
             System.out.println(f);
        
        
        if (t.containsFuncion(f1))
            System.out.println("La función "+f1+" se representará en "+t.getNombre());
        
        //Muestra solo los nombres de las funciones del teatro t
        for(Funcion f: lista)
            System.out.println("Función "+f.getNombre());
        
        //Añadir más funciones
        Funcion f2=new Funcion("La casa de Bernarda Alba",7);
        Funcion f3=new Funcion("Romeo y Julieta",10);
        t.addFuncion(f2);
        t.addFuncion(f3);
        t.addFuncion(new Funcion("Los Simpsons",3));
        //Mostrar el nombre de aquellas funciones cuyo precio sea inferior a 7
        
        System.out.println("Listado de Funciones del Teatro "+t.getNombre()+" cuyo precio sea inferior a 7");
        for(Funcion f: lista) // lista=t.getFunciones();
            if (f.getPrecio() < 7)
                System.out.println("Función "+f.getNombre());
        
        
         //Realiza el listado completo
        for(Funcion f: t.getListaFunciones())
            System.out.println(f);
        
        //Se elimina la función f2 del teatro t
        System.out.println("El teatro "+t.getNombre()+" quiere eliminar la función "+f2);
        t.removeFuncion(f2);
        
        //Realiza el listado completo
        for(Funcion f: t.getListaFunciones())
            System.out.println(f);
        
        
        Funcion f4=new Funcion("The Luthiers",15);
        
        try{
           t.removeFuncion(f4);
        }
        catch(IllegalArgumentException e)
        {
            System.out.println("Error "+e.getMessage());
        }
        
        System.out.println("------------------------------------");
        System.out.println("Teatro "+t);
        
        
    }   
    
}
