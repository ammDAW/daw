/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto_db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author Profesor
 */
public class Conexion {
    private Connection conexion=null;
    
    public Conexion(){
        try{
           //Comprobar si existe la librería para utilizar el Driver 
           Class.forName("com.mysql.jdbc.Driver");
           System.out.println("Driver cargado");
           String url="jdbc:mysql://localhost:3360/java";
           String user="root";
           String password="";
           this.conexion=DriverManager.getConnection(url, user, password);
           System.out.println("Conexión establecida..");
        }catch(ClassNotFoundException e){
            System.out.println("La biblioteca NO está cargada...");            
        }catch(SQLException f){
            System.out.println("La base de datos no existe o los credenciales del usario son incorrectos");
        }
    }
    
}
