/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyectocomplejo;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Profesor
 */
public class ComplejoTest {
    
    public ComplejoTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of getR method, of class Complejo.
     */
    @Test
    public void testGetR() {
        System.out.println("getR");
        Complejo instance = new Complejo();
        int expResult = 1;
        int result = instance.getR();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of getI method, of class Complejo.
     */
    @Test
    public void testGetI() {
        System.out.println("getI");
        Complejo instance = new Complejo();
        int expResult = 0;
        int result = instance.getI();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setR method, of class Complejo.
     */
    @Test
    public void testSetR() {
        System.out.println("setR");
        int r = 0;
        Complejo instance = new Complejo();
        instance.setR(r);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setI method, of class Complejo.
     */
    @Test
    public void testSetI() {
        System.out.println("setI");
        int i = 0;
        Complejo instance = new Complejo();
        instance.setI(i);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setComplejo method, of class Complejo.
     */
    @Test
    public void testSetComplejo_int_int() {
        System.out.println("setComplejo");
        int r = 0;
        int i = 0;
        Complejo instance = new Complejo();
        instance.setComplejo(r, i);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setComplejo method, of class Complejo.
     */
    @Test
    public void testSetComplejo_Complejo() {
        System.out.println("setComplejo");
        Complejo c = null;
        Complejo instance = new Complejo();
        instance.setComplejo(c);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of toString method, of class Complejo.
     */
    @Test
    public void testToString() {
        System.out.println("toString");
        Complejo instance = new Complejo();
        String expResult = "{1+0i}";
        String result = instance.toString();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of equals method, of class Complejo.
     */
    @Test
    public void testEquals_int_int() {
        System.out.println("equals");
        int r = 0;
        int i = 0;
        Complejo instance = new Complejo();
        boolean expResult = false;
        boolean result = instance.equals(r, i);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of equals method, of class Complejo.
     */
    @Test
    public void testEquals_Complejo() {
        System.out.println("equals");
        Complejo c = null;
        Complejo instance = new Complejo();
        boolean expResult = false;
        boolean result = instance.equals(c);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of sumaComplejo method, of class Complejo.
     */
    @Test
    public void testSumaComplejo_int_int() {
        System.out.println("sumaComplejo");
        int c = 0;
        int d = 0;
        Complejo instance = new Complejo();
        Complejo expResult = new Complejo();
        Complejo result = instance.sumaComplejo(c, d);
        assertTrue(expResult.equals(result));
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of sumaComplejo method, of class Complejo.
     */
    @Test
    public void testSumaComplejo_Complejo() {
        System.out.println("sumaComplejo");
        Complejo g = new Complejo();
        Complejo instance = new Complejo();
        Complejo expResult = new Complejo(2,0);
        Complejo result = instance.sumaComplejo(g);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of complejoResta method, of class Complejo.
     */
    @Test
    public void testComplejoResta_int_int() {
        System.out.println("complejoResta");
        int r = 0;
        int i = 0;
        Complejo instance = new Complejo();
        Complejo expResult = null;
        Complejo result = instance.complejoResta(r, i);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of complejoResta method, of class Complejo.
     */
    @Test
    public void testComplejoResta_Complejo() {
        System.out.println("complejoResta");
        Complejo c = null;
        Complejo instance = new Complejo();
        Complejo expResult = null;
        Complejo result = instance.complejoResta(c);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of complejoProducto method, of class Complejo.
     */
    @Test
    public void testComplejoProducto_int_int() {
        System.out.println("complejoProducto");
        int r = 0;
        int i = 0;
        Complejo instance = new Complejo();
        Complejo expResult = null;
        Complejo result = instance.complejoProducto(r, i);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of complejoProducto method, of class Complejo.
     */
    @Test
    public void testComplejoProducto_Complejo() {
        System.out.println("complejoProducto");
        Complejo c = null;
        Complejo instance = new Complejo();
        Complejo expResult = null;
        Complejo result = instance.complejoProducto(c);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of complejoCociente method, of class Complejo.
     */
    @Test
    public void testComplejoCociente_int_int() {
        System.out.println("complejoCociente");
        int r = 0;
        int i = 0;
        Complejo instance = new Complejo();
        Complejo expResult = null;
        Complejo result = instance.complejoCociente(r, i);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of complejoCociente method, of class Complejo.
     */
    @Test
    public void testComplejoCociente_Complejo() {
        System.out.println("complejoCociente");
        Complejo c = new Complejo();
                
        Complejo instance = new Complejo();
        Complejo expResult = null;
        Complejo result = instance.complejoCociente(c);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }
    
}
