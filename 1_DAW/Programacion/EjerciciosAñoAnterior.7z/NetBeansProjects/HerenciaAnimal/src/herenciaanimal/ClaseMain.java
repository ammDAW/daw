/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package herenciaanimal;

/**
 *
 * @author Profesor
 */
public class ClaseMain {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
      
    //Animal a; //a=new Animal(); Error, porque Animal es abstracta y no se 
              //pueden crear objetos de tipo Animal
      Animal gato=new Cat();
      Animal perro=new Dog();
      
       gato.makeSound(); //Meow
       gato.dormir(); //Nanas
       //gato.eat();    El método eat() es de Cat
       
       perro.makeSound();//Woof
       perro.dormir();//Nanas
       
      Animal a;
      Cat b=new Cat();
      a=b;
      a.makeSound();
      a.dormir();
      ((Cat)a).eat(); //UpCasting
      
      
    
    }
    
}
