package packageB;

import java.util.LinkedList;
import java.util.List;

public class ClassB {
    public static final String my_TEXT = "text";
    List l = new LinkedList();
    
    String s = my_TEXT;

    
    public void method() {
        String local = my_TEXT;
    }
    
    public static int statMethod() {
        int c = 3;
        System.out.println(c);
        return 3;
        
    }
}
