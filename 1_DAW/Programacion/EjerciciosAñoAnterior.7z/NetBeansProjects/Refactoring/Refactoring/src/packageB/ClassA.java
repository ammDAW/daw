package packageB;

import java.util.LinkedList;
import java.util.List;

public class ClassA {

    public void method() {
        int x = new_name;
        int y = new_name + 3;
        System.out.println(new_name);
    }
    private final int new_name = 3 + 3;

    public void method2() {
        int x = new_name;
    }

    String constExpr = "CONST";

    public static void method3() {
        String s = "Text";
    }
    
    String konst = "a";
}
