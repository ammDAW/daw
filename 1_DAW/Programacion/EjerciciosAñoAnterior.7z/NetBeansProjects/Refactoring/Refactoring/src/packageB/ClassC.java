package packageB;

public class ClassC {

    public void method() {
        final double new_name = 3.3;
        double d = new_name;
        System.out.println(new_name);
        d = new_name + new_name;
    }
}
