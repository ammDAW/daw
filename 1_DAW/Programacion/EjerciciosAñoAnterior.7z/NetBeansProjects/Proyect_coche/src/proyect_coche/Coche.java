/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyect_coche;

/**
 *
 * @author Profesor
 */
public class Coche {
    private int numPuertas, precio;
    private String marca, modelo, color, combustible, cambio;
    private static String marcas[]={"SEAT","PEUGEOT","AUDI","VOLKSWAGEN","FIAT","HYUNDAI","MERCEDES","BMW"};
    
    //número de puertas -> Obligatorio: 3,4 ó 5
    //precio -> Obligatorio NUNCA menor 0
    //marca y modelo -> No valores obligatorios
    //combustible -> Obligatorio: GASOLINA DIESEL
    //cambio -> Obligatorio: MANUAL AUTOMÁTICO

    public Coche(int numPuertas, int precio, String marca, String modelo, String color, String combustible, String cambio) {
      //Para la depuración de errores hay 2 opciones:
      //El código de los set se pone aquí para cada de las propiedades
      //o
      //se utilizan los métodos set  
      try{  
        this.setNumPuertas(numPuertas);
        this.setPrecio(precio);
        this.setMarca(marca);
        this.modelo = modelo.toUpperCase();
        this.color = color.toUpperCase();
        this.setCombustible(combustible);
        this.setCambio(cambio);
      }
      catch(IllegalArgumentException ty)
      {
         this.numPuertas=3;
         this.precio=0;
         this.marca="";
         this.modelo="";
         this.color="BLANCO";
         this.combustible="GASOLINA";
         this.cambio="MANUAL";
          System.out.println(ty.getMessage());
      }
    }

    public Coche() {
        this(3,0,"","","BLANCO","GASOLINA","MANUAL");
    }

    public Coche(Coche otro)
    {
        this(otro.numPuertas,otro.precio,otro.marca,otro.modelo,otro.color,otro.combustible,otro.cambio);
    }
    
    
    public int getNumPuertas() {
        return this.numPuertas;
    }

    public int getPrecio() {
        return this.precio;
    }

    public String getMarca() {
        return this.marca;
    }

    public String getModelo() {
        return this.modelo;
    }

    public String getColor() {
        return this.color;
    }

    public String getCombustible() {
        return this.combustible;
    }

    public String getCambio() {
        return this.cambio;
    }

    public void setNumPuertas(int numPuertas) throws IllegalArgumentException {
        //if (numPuertas!=3 && numPuertas!=4 && numPuertas!=5)
        //if (!(numPuertas>=3 && numPuertas<=5))
        if (numPuertas<3 || numPuertas>5)
            throw new IllegalArgumentException("Número de puertas incorrecto");
        this.numPuertas = numPuertas;
    }

    public void setPrecio(int precio) throws IllegalArgumentException {
        if (precio <0)
        {
           
            IllegalArgumentException t=new IllegalArgumentException();
            throw t;
        }    
        else
            this.precio = precio;
    }

    public void setMarca(String marca) throws IllegalArgumentException{
        marca=marca.toUpperCase();
        /*
        if (!(marca.equals("PEUGEOT") || marca.equals("SEAT") || marca.equals("RENAULT")))
                throw new IllegalArgumentException("Color Incorrecto");
        */
        boolean encontrado=false;
        for (int i = 0; i < Coche.marcas.length; i++) {
            if (marca.equals(Coche.marcas[i]))
            {
                encontrado=true;
                break;
            }
        }
        
        if (!encontrado) 
            throw new IllegalArgumentException("Marca incorrecta");
        this.marca = marca;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public void setColor(String color) {              
        this.color = color;
    }

    public void setCombustible(String combustible) throws IllegalArgumentException {
        combustible=combustible.toUpperCase();
        if (!combustible.equals("DIESEL") && !combustible.equals("GASOLINA"))
            throw new IllegalArgumentException("Combustible Incorrecto");
        else//opcional, throw sale del método
        this.combustible = combustible;
    }

    public void setCambio(String cambio) {
        cambio=cambio.toUpperCase();
        if (cambio.equals("MANUAL") || cambio.equals("AUTOMATICO"))
           this.cambio = cambio;
        else
            System.out.println("Error, cambio incorrecto, ha de ser MANUAL o AUTOMÁTICO");
    }

    @Override
    public String toString() {
        return "{" + "Número de Puertas=" + this.numPuertas + " \tPrecio=" + this.precio + " \tMarca=" + this.marca + " \t Modelo=" + this.modelo + " \tColor=" + this.color + " \tTipo de combustible=" + this.combustible + "\tTipo de cambio=" + this.cambio + '}';
    }
    
    
    public boolean equals(Coche otro)
    {
       return this.equals(otro.numPuertas,otro.precio,otro.marca,otro.modelo,otro.color,otro.combustible,otro.cambio);
    }
    
    public boolean equals(int numPuertas, int precio, String marca, String modelo, String color, String combustible, String cambio)
    {            
        if (this.numPuertas==numPuertas && this.precio==precio && this.marca.equals(marca) && this.modelo.equals(modelo) && this.combustible.equals(combustible) && this.cambio.equals(cambio))
           return true;
        else
            return false;
    }
       
    @Override
    public Coche clone()
    {
        //Coche clonado=new Coche(this); //Llamo al constructor Coche(Coche otro)
        //return clonado; 
        return new Coche(this);
        
    }
    
    @Override
    public void finalize(){
        System.out.println("El coche "+this+" se ha destruído");
    }
    
}
