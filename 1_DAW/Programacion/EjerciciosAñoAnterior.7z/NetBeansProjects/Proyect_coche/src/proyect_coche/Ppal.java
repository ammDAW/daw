/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyect_coche;

/**
 *
 * @author Profesor
 */
public class Ppal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       /*
        Coche munioz=new Coche(4,24000,"PEUGEOT","407","GRIS","DIESEL","MANUAL");
        Coche defecto=new Coche();
        
        System.out.println("Coche de Muñoz :"+munioz);
        System.out.println("Coche por Defecto: "+defecto);
        
        Coche copiaMunioz=new Coche(munioz);
        System.out.println("Coche Copia de Muñoz :"+copiaMunioz);
        
        defecto.setColor("ROJO");
        System.out.println("El coche por Defecto: "+defecto);
        
        munioz.setCambio("PALANQUERO");
        System.out.println("El cambio del coche Muñoz :"+munioz.getCambio());
      
       
        try{
          munioz.setPrecio(-18000);
          System.out.println("Coche de Muñoz :"+munioz);
        }
        catch(IllegalArgumentException t)
        {            
            System.out.println("Error, NUNCA el precio de un coche ha de ser NEGATIVO");
            System.out.println(t.getMessage());
        }
        
       
       try{ 
           munioz.setCombustible("HÍBRIDO");
       }catch(IllegalArgumentException tt)
       {
           System.out.println("Error "+tt.getMessage());
       }
       */
       
       Coche lere=new Coche(5,30000,"FIAT","LERE","ROJO","DIESEL","MANUAL");
       System.out.println("Coche lere="+lere);
       
       Coche sergio=lere.clone();
        System.out.println("Sergio "+sergio);
        
       
    }
    
}
