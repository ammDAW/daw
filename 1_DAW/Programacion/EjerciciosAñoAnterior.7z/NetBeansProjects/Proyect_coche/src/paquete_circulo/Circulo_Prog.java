/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package paquete_circulo;

import Punto.Punto;

/**
 *
 * @author Profesor
 */
public class Circulo_Prog {
       private Punto centro;
    private int radio;

    public Circulo_Prog(Punto centro, int radio) throws IllegalArgumentException {
        this.centro = centro;
        this.setRadio(radio);     
    }
    
    public Circulo_Prog()
    {
        this(new Punto(),0);
    }
    
    public Circulo_Prog(int x, int y, int radio){     
        this(new Punto(x,y),radio);
    }
    
    public Circulo_Prog(int radio)
    {        
        this(new Punto(),radio);
    }
    
    public Circulo_Prog(Circulo_Prog otro)
    {
        //this(otro.centro,otro.radio);
        this(otro.centro.getX(), otro.centro.getY(), otro.radio);
    }

    public Punto getCentro() {
        return this.centro;
    }

    public int getRadio() {
        return this.radio;
    }

    public void setCentro(Punto centro) {
        this.centro = centro;
    }

    public void setRadio(int radio) throws IllegalArgumentException{
        if (radio <0)
            throw new IllegalArgumentException("Error, radio no puede ser negativo");
        this.radio = radio;
    }

    @Override
    public String toString() {
        return "Circulo_Prog{" + "centro=" + this.centro + ", radio=" + this.radio + '}';
    }
 
}
