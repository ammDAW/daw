/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package paquete_circulo;

import Punto.Punto;

/**
 *
 * @author Profesor
 */
public class EjCirculo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //Constructor Circulo(Punto,int)
        Punto p=new Punto(8,9);
        Circulo c1=new Circulo(p,5);
        System.out.println("Círculo c1="+c1);
        
        //El constructor detecta un error, en el radio y crea un 
        //círculo por defecto
        Circulo c3=new Circulo(p,-9);
        System.out.println("C3= "+c3);
        
        //Circulo() por defecto
        Circulo c2=new Circulo();
        System.out.println("c2="+c2);
        
        //Circulo(int,int,int)
        Circulo c4=new Circulo(4,5,6);
        System.out.println("c4="+c4);
        
        //Circulo(int,int,int)
        //Centro de c5, (x,y)
        //x será la coordenada x del centro del círculo c3
        //y será la coordenada y del punto opuesto del centro del círculo c3
        //radio 7
        Circulo c5=new Circulo(c3.getCentro().getX(), c3.getCentro().ptoOpuesto().getY(),7);
        System.out.println("c5="+c5);
      
        
        //Si el círculo c2 es igual al c3
        if (c2.equals(c3))
            System.out.println("c2 y c3 son iguales");
        else
            System.out.println("Son distintos");
        
        //Si el círculo c2 es igual al círculo formado por el punto p (8,9) y radio 4
        if (c2.equals(p, 4))
            System.out.println("c2 y el formado por el punto p y radio 4");
        else
            System.out.println("Son distintos");
        
        //Si el círculo c1 es igual al círculo formado por el centro con coordenadas 8,9
        // y radio 5
        
        if (c1.equals(8,9,5)) // if (c1.equals(new Punto(8,9), 5) //if (c1.equals(new Circulo(new Punto(8,9),5))
            System.out.println("Son iguales");
        else
            System.out.println("Son distintos");
        
        
        try{
           c1.ampliaCirculo(-8);
           System.out.println("c1="+c1);
        }catch(IllegalArgumentException t)
        {
            System.out.println("Error "+t.getMessage());
        }
        
        System.out.println("c1="+c1);
        
        Circulo_Prog cPropaga;
        try{
            cPropaga=new Circulo_Prog(p,-9);
            System.out.println("Sin error");
        }catch(IllegalArgumentException t)
        {
            System.out.println("Error "+t.getMessage());
            cPropaga=new Circulo_Prog();
        }
        
        System.out.println("Circulo cPropaga="+cPropaga);
        
    }
    
}
