/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package paqPpal;

/**
 *
 * @author Profesor
 */
public class Empleado {
    protected int id;
    protected String nombre;
    protected String apellido;
    protected int edad;
    protected static int contEmpleados=0;

    public Empleado(String nombre, String apellido, int edad) {
      try{  
        this.nombre = nombre;
        this.apellido = apellido;
        this.setEdad(edad);
      }
      catch(IllegalArgumentException e)
      {
          this.edad=18;
          System.out.println(e.getMessage()+" Creado un empleado con edad a 18");
      }
      Empleado.contEmpleados++;
      this.id=Empleado.contEmpleados;      
    }

    public int getId() {
        return this.id;
    }

    public String getNombre() {
        return this.nombre;
    }

    public String getApellido() {
        return this.apellido;
    }

    public int getEdad() {
        return this.edad;
    }

    public static int getContEmpleados() {
        return Empleado.contEmpleados;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public void setEdad(int edad) throws IllegalArgumentException{
       if (!(edad >= 18 && edad <= 70)) 
           throw new IllegalArgumentException("Edad inapropiada");
       //else
        this.edad = edad;
    }

    @Override
    public String toString() {
        return "Empleado{" + "Id=" + this.id + " Nombre=" + this.nombre + " " + this.apellido + " Edad=" + this.edad + '}';
    }
    
    public void concentrarse(){
        System.out.println("Es necesario concentrarse");
    }
    
}
