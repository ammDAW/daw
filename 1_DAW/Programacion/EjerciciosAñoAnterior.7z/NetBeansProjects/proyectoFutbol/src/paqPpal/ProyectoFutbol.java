/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package paqPpal;

import paqClases.Equipo;
import paqClases.Futbolista;

/**
 *
 * @author Profesor
 */
public class ProyectoFutbol {
    public static void main(String[] args) {
        //a
        Equipo e=new Equipo("Real Murcia");
        //b
        Futbolista f1=new Futbolista(10,"Delantero","Andres","Messi",32);
        Futbolista f2=new Futbolista(7,"Delantero","Cristiano","Ronaldo",34);
        Futbolista f3=new Futbolista(1,"Portero","Diego","Alves",33);
        Futbolista f4=new Futbolista(3,"Defensa","Diego","Godin",33);
        //c
        f4.concentrarse();
        //d
        f4.jugar();
        //e
        e.addFutbolista(f1);
        e.addFutbolista(f2);
        e.addFutbolista(f3);
        e.addFutbolista(f4);
        //f
        int cont=e.mostrarFutbolistasRangoEdad(32, 33);
        System.out.println("Hay en total "+cont+" futbolistas del equipo: "+e.getNombre()+" cuya edad está comprendida entre 32 y 33");
        
        //g 
        e.mostrarFutbolistasDemarcacion("Delantero");
        
        
        
        
    }
    
}
