/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package paqClases;

import paqPpal.Empleado;

/**
 *
 * @author Profesor
 */
public class Futbolista extends Empleado{
    protected int dorsal;
    protected String demarcacion;

    public Futbolista(int dorsal, String demarcacion, String nombre, String apellido, int edad) {
        super(nombre,apellido,edad);        
        this.dorsal = dorsal;
        this.demarcacion = demarcacion;
    }

    public int getDorsal() {
        return this.dorsal;
    }

    public String getDemarcacion() {
        return this.demarcacion;
    }

    public void setDorsal(int dorsal) {
        this.dorsal = dorsal;
    }

    public void setDemarcacion(String demarcacion) {
        this.demarcacion = demarcacion;
    }

    @Override
    public String toString() {
        return "Futbolista{" + super.toString()+ " Dorsal=" + this.dorsal + " Demarcacion=" + this.demarcacion + '}';
    }
    
    @Override
    public void concentrarse(){
        System.out.println("Un futbolista necesita concentrarse");
    }
    
    public void jugar(){
        System.out.println("Un futbolista debe seguir las normas de su entrenador");
    }
    
}
