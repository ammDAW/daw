/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package paqClases;

import java.util.ArrayList;

/**
 *
 * @author Profesor
 */
public class Equipo {
    private String nombre;
    private ArrayList <Futbolista> jugadores;

    public Equipo(String nombre) {
        this.nombre = nombre;
        this.jugadores=new ArrayList();
    }

    public String getNombre() {
        return this.nombre;
    }

    public ArrayList<Futbolista> getJugadores() {
        return this.jugadores;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setJugadores(ArrayList<Futbolista> jugadores) {
        this.jugadores = new ArrayList(jugadores);
    }
    
    public void addFutbolista(Futbolista f){
        if (! this.jugadores.contains(f))
            this.jugadores.add(f);
        else
            System.out.println("El futbolista "+f+" ya pertenece al equipo");
    }
    
    public boolean contieneFutbolista(Futbolista f){
        return this.jugadores.contains(f);
    }
    
    public String toString(){
        String cadena="Nombre "+this.nombre+"\n";
        if (this.jugadores.isEmpty())
            cadena+="No tiene todavía jugadores";
        else
            for(Futbolista f: this.jugadores)
               cadena+=f.toString()+"\n";
                
        return cadena;        
    }
    
    public int mostrarFutbolistasRangoEdad(int edadMn, int edadMy){
        int cont=0;
        
        for(Futbolista f:this.jugadores)
            if (f.getEdad()>= edadMn && f.getEdad() <= edadMy)
            {     
                System.out.println("Dorsal "+f.getDorsal()+" Nombre "+f.getNombre());
                cont++;
            } 
            
       
        return cont;        
    }
    
    public void mostrarFutbolistasDemarcacion(String demarcacion){
        /*
        for(Futbolista f: this.jugadores)
            if (f.getDemarcacion().equalsIgnoreCase(demarcacion))
                System.out.println(f);
        */
        for(int i=0;i<this.jugadores.size();i++)
        {
            if (this.jugadores.get(i).getDemarcacion().equalsIgnoreCase(demarcacion))
                System.out.println(this.jugadores.get(i));
        }
    }
    
    
}
