/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto_carritocompra;

/**
 *
 * @author Profesor
 */
public class Viaje implements Vendible{
    protected String origen;
    protected String destino;
    protected int nDias;
    protected double precio;
    protected double iva;

    public Viaje(String origen, String destino, int nDias, double precio) {
        this.origen = origen;
        this.destino = destino;
        this.nDias = nDias;
        this.precio = precio;
        this.iva=0.21;
    }

    public String getOrigen() {
        return origen;
    }

    public String getDestino() {
        return destino;
    }

    public int getnDias() {
        return nDias;
    }

    public double getPrecio() {
        return precio;
    }

    public double getIva() {
        return iva;
    }

    public void setOrigen(String origen) {
        this.origen = origen;
    }

    public void setDestino(String destino) {
        this.destino = destino;
    }

    public void setnDias(int nDias) {
        this.nDias = nDias;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public void setIva(double iva) {
        this.iva = iva;
    }

    @Override
    public String toString() {
        return "Viaje{" + "Origen=" + origen + ", Destino=" + destino + ", Número de Dias=" + nDias + ", Precio=" + precio + ", Iva=" + iva +" Total:  "+this.precioIva()+"}";
    }
       
    @Override
    public double precioIva(){
        return this.iva*(1+this.precio);
    }
    
    
}
