/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto_carritocompra;

/**
 *
 * @author Profesor
 */
public class Proyecto_CarritoCompra {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       //1. 
       Alimentacion a1=new Alimentacion("Leche",0.4);
       Alimentacion a2=new Alimentacion("Huevos",0.35);
       //2.
       Ropa r1=new Ropa("Blusa Rosa",18);
       Ropa r2=new Ropa("Pantalon",20);
       //3.
       Viaje v1=new Viaje("Murcia","Madrid",3,400);
       //4.
       Carrito carro=new Carrito();
       //5.
       carro.addProducto(a1);
       carro.addProducto(a2);
       carro.addProducto(r1);
       carro.addProducto(r2);
       carro.addProducto(v1);
       //6.
       carro.mostrarCarrito();
       //7.
       double pago=carro.precioTotalCarrito();
       System.out.println("Se debe pagar "+pago+"€");
       
    }
    
}
