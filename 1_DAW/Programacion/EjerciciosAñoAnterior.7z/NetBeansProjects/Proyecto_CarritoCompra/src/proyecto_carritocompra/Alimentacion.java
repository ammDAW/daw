/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto_carritocompra;

/**
 *
 * @author Profesor
 */
public class Alimentacion extends Producto{
    protected double iva;

    public Alimentacion(String nombre, double precio) {
        super(nombre, precio);
        this.iva = 0.04;
    }

    public double getIva() {
        return iva;
    }

    public void setIva(double iva) {
        this.iva = iva;
    }

    @Override
    public String toString() {
        return "Alimentacion{" + super.toString()+" Iva=" + iva + " Total: "+this.precioIva()+'}';
    }
    
    @Override
    public double precioIva(){
       return this.precio*(1+this.iva);
    }
    
}
