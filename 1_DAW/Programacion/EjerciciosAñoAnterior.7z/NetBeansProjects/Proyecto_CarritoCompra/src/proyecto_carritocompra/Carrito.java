/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto_carritocompra;

import java.util.ArrayList;

/**
 *
 * @author Profesor
 */
public class Carrito {
    private ArrayList <Vendible> listaInterfaces=new ArrayList();

    public Carrito() {
    }
    
    public void addProducto(Vendible v){
        if (!this.listaInterfaces.contains(v))
            this.listaInterfaces.add(v);
    }
    
    public void mostrarCarrito()
    {
        System.out.println("---LISTADO DE ARTÍCULOS DEL CARRITO---");
        for(Vendible v: this.listaInterfaces){
            System.out.println("-"+v.toString());
        }
    }
    
    public double precioTotalCarrito(){
        double suma=0.0;
        for(Vendible v: this.listaInterfaces)
            suma+=v.precioIva();
        return suma;
    }
}
