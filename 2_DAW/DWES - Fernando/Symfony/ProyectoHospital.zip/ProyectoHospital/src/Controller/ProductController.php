<?php

// src/Controller/ProductController.php
namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Doctrine\ORM\EntityManagerInterface;


use Symfony\Component\HttpFoundation\Request;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;

// tipos form
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\Extension\Core\Type\EmailType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\Extension\Core\Type\MoneyType;

// clase
use App\Entity\Product;
// form
use App\Form\ProductType;


// Constraints
use Symfony\Component\Validator\Constraints\Currency;




/**
* @Route("/")
*/
class ProductController extends AbstractController
{

/**
     * @Route("/NewFormClase", name="NewFormClase")
     */
    public function claseNewForm( Request $request)
    {
       
        $producto = new Product();
        $form = $this->createForm(ProductType::class, $producto );
       
        $form->handleRequest( $request );

        if ($form->isSubmitted() && $form->isValid()) {
            $em = $this->getDoctrine()->getManager();
            $em->persist($producto);
            $em->flush();
         
            // return new Response( "Save");
            return $this->redirectToRoute('producto_listar');
        }
        else
            return $this->render('producto/form.html.twig', array('form' => $form->createView(),));
    }
    
    
    /**
     * @Route("/EditFormClase/{id}", name="EditFormClase")
     */
     public function EditFormClase( Request $request, $id )
    {
       
        $producto = $this->getDoctrine()
        ->getRepository(Product::class)
        ->findOneById( $id );
		
        $form = $this->createForm(ProductType::class, $producto );
       
        $form->handleRequest( $request );

         if ($form->isSubmitted() && $form->isValid()) {
            $em = $this->getDoctrine()->getManager();
            $em->persist($producto);
            $em->flush();
         
            // return new Response( "Save");
            return $this->redirectToRoute('producto_listar');
        }
        else
            return $this->render('producto/form.html.twig', array('form' => $form->createView(),));
    }






	/**
     * @Route("/listar", name="producto_listar" )
     */
	public function listar() {
        /*
         * Repositorio de la entidad
         * (si no creamos uno y le metemos métodos propios
         * solamente tendrá los métodos de la clase de la entidad)
         */
         $productos = $this->getDoctrine()
        ->getRepository(Product::class)
        ->findAll();


		if (!$productos) {
        throw $this->createNotFoundException(
            'No product found for id '
        );
		}
		else
		{
			return $this->render('producto/listar.html.twig', [
            'productos' => $productos ]);
		}
    }
	
	/**
     * @Route("/show/{id}", name="producto_show" )
     */
	public function show( $id ) {
       
 
        /*
         * Repositorio de la entidad
         * (si no creamos uno y le metemos métodos propios
         * solamente tendrá los métodos de la clase de la entidad)
         */
         $producto = $this->getDoctrine()
        ->getRepository(Product::class)
        ->find( $id );
		

		if (!$producto) {
        throw $this->createNotFoundException(
            'No product found for id '
        );
		}
		else
		{
			return $this->render('producto/show.html.twig', [
            'producto' => $producto ]);
		}
    }	
    
    
    /**
     * @Route("/delete/{id}", name="producto_delete" )
     */
	public function delete( $id ) {
       
 
        /*
         * Repositorio de la entidad
         * (si no creamos uno y le metemos métodos propios
         * solamente tendrá los métodos de la clase de la entidad)
         */
         $producto = $this->getDoctrine()
        ->getRepository(Product::class)
        ->find( $id );
		

		if (!$producto) {
        throw $this->createNotFoundException(
            'No product found for id '
        );
		}
		else
		{
			$entityManager = $this->getDoctrine()->getManager();
            
			
			$entityManager->remove($producto);
			$entityManager->flush();
			
			
			return $this->render('msg.html.twig', [
            'msg' => 'El registro ha sido borrado' ]);
		}
    }


    /**
     * @Route("/update/{id}", name="producto_update" )
     */
	public function update( $id ) {
    
        /*
         * Repositorio de la entidad
         * (si no creamos uno y le metemos métodos propios
         * solamente tendrá los métodos de la clase de la entidad)
         */
         $producto = $this->getDoctrine()
        ->getRepository(Product::class)
        ->find( $id );
		

		if (!$producto) {
        throw $this->createNotFoundException(
            'No product found for id '
        );
		}
		else
		{
			$entityManager = $this->getDoctrine()->getManager();
            
            $producto->setName( "tuerca" );
            $producto->setPrice( 20 );
            $producto->setDescription( "Pos una tuerca" );
			$entityManager->persist($producto);
			$entityManager->flush();
			
			return $this->render('msg.html.twig', [
            'msg' => 'El registro ha sido actualizado' ]);
		}
    }


}

