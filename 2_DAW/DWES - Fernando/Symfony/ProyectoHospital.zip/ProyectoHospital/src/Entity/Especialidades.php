<?php

namespace App\Entity;

use App\Repository\EspecialidadesRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass=EspecialidadesRepository::class)
 */
class Especialidades
{
    /**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\ManyToMany(targetEntity=Medicos::class, mappedBy="especialidades")
     */
    private $medicos;

    /**
     * @ORM\OneToMany(targetEntity=Citas::class, mappedBy="especialidad")
     */
    private $citas;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $especialidad;

    /**
     * @ORM\OneToMany(targetEntity=Servicios::class, mappedBy="especialidad")
     */
    private $servicios;

    public function __construct()
    {
        $this->medicos = new ArrayCollection();
        $this->citas = new ArrayCollection();
        $this->servicios = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    /**
     * @return Collection|Medicos[]
     */
    public function getMedicos(): Collection
    {
        return $this->medicos;
    }

    public function addMedico(Medicos $medico): self
    {
        if (!$this->medicos->contains($medico)) {
            $this->medicos[] = $medico;
            $medico->addEspecialidade($this);
        }

        return $this;
    }

    public function removeMedico(Medicos $medico): self
    {
        if ($this->medicos->removeElement($medico)) {
            $medico->removeEspecialidade($this);
        }

        return $this;
    }

    /**
     * @return Collection|Citas[]
     */
    public function getCitas(): Collection
    {
        return $this->citas;
    }

    public function addCita(Citas $cita): self
    {
        if (!$this->citas->contains($cita)) {
            $this->citas[] = $cita;
            $cita->setEspecialidad($this);
        }

        return $this;
    }

    public function removeCita(Citas $cita): self
    {
        if ($this->citas->removeElement($cita)) {
            // set the owning side to null (unless already changed)
            if ($cita->getEspecialidad() === $this) {
                $cita->setEspecialidad(null);
            }
        }

        return $this;
    }

    public function getEspecialidad(): ?string
    {
        return $this->especialidad;
    }

    public function setEspecialidad(string $especialidad): self
    {
        $this->especialidad = $especialidad;

        return $this;
    }

    /**
     * @return Collection|Servicios[]
     */
    public function getServicios(): Collection
    {
        return $this->servicios;
    }

    public function addServicio(Servicios $servicio): self
    {
        if (!$this->servicios->contains($servicio)) {
            $this->servicios[] = $servicio;
            $servicio->setEspecialidad($this);
        }

        return $this;
    }

    public function removeServicio(Servicios $servicio): self
    {
        if ($this->servicios->removeElement($servicio)) {
            // set the owning side to null (unless already changed)
            if ($servicio->getEspecialidad() === $this) {
                $servicio->setEspecialidad(null);
            }
        }

        return $this;
    }
}
