<?php

namespace App\Entity;

use App\Repository\MedicosRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass=MedicosRepository::class)
 */
class Medicos
{
    /**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\ManyToMany(targetEntity=Especialidades::class, inversedBy="medicos")
     */
    private $especialidades;

    /**
     * @ORM\Column(type="integer")
     */
    private $medico_id;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $nombre;

    public function __construct()
    {
        $this->especialidades = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    /**
     * @return Collection|Especialidades[]
     */
    public function getEspecialidades(): Collection
    {
        return $this->especialidades;
    }

    public function addEspecialidades(Especialidades $especialidades): self
    {
        if (!$this->especialidades->contains($especialidades)) {
            $this->especialidades[] = $especialidades;
        }

        return $this;
    }

    public function removeEspecialidade(Especialidades $especialidades): self
    {
        $this->especialidades->removeElement($especialidades);

        return $this;
    }

    public function getMedicoId(): ?int
    {
        return $this->medico_id;
    }

    public function setMedicoId(int $medico_id): self
    {
        $this->medico_id = $medico_id;

        return $this;
    }

    public function getNombre(): ?string
    {
        return $this->nombre;
    }

    public function setNombre(string $nombre): self
    {
        $this->nombre = $nombre;

        return $this;
    }
}
