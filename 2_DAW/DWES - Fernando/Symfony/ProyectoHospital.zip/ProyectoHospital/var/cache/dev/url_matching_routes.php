<?php

/**
 * This file has been auto-generated
 * by the Symfony Routing Component.
 */

return [
    false, // $matchHost
    [ // $staticRoutes
        '/_profiler' => [[['_route' => '_profiler_home', '_controller' => 'web_profiler.controller.profiler::homeAction'], null, null, null, true, false, null]],
        '/_profiler/search' => [[['_route' => '_profiler_search', '_controller' => 'web_profiler.controller.profiler::searchAction'], null, null, null, false, false, null]],
        '/_profiler/search_bar' => [[['_route' => '_profiler_search_bar', '_controller' => 'web_profiler.controller.profiler::searchBarAction'], null, null, null, false, false, null]],
        '/_profiler/phpinfo' => [[['_route' => '_profiler_phpinfo', '_controller' => 'web_profiler.controller.profiler::phpinfoAction'], null, null, null, false, false, null]],
        '/_profiler/open' => [[['_route' => '_profiler_open_file', '_controller' => 'web_profiler.controller.profiler::openAction'], null, null, null, false, false, null]],
        '/hospital' => [[['_route' => 'hospital', '_controller' => 'App\\Controller\\HospitalController::index'], null, null, null, false, false, null]],
        '/cuadroMedico' => [[['_route' => 'hospital_cuadroMedico', '_controller' => 'App\\Controller\\HospitalController::cuadroMedico'], null, null, null, false, false, null]],
        '/citas' => [[['_route' => 'hospital_citas', '_controller' => 'App\\Controller\\HospitalController::citas'], null, null, null, false, false, null]],
        '/encuestas' => [[['_route' => 'hospital_encuestas', '_controller' => 'App\\Controller\\HospitalController::encuestas'], null, null, null, false, false, null]],
        '/servicios' => [[['_route' => 'hospital_servicios', '_controller' => 'App\\Controller\\HospitalController::servicios'], null, null, null, false, false, null]],
        '/bolsa' => [[['_route' => 'hospital_bolsa', '_controller' => 'App\\Controller\\HospitalController::bolsa'], null, null, null, false, false, null]],
        '/menu' => [[['_route' => 'menu', '_controller' => 'App\\Controller\\HospitalController::menu'], null, null, null, false, false, null]],
        '/menuLogeado' => [[['_route' => 'menuLogeado', '_controller' => 'App\\Controller\\HospitalController::menuLogeado'], null, null, null, false, false, null]],
        '/footer' => [[['_route' => 'footer', '_controller' => 'App\\Controller\\HospitalController::footer'], null, null, null, false, false, null]],
        '/privado/gestionMedicos' => [[['_route' => 'hospital_gestionMedicos', '_controller' => 'App\\Controller\\HospitalController::listarMedicos'], null, null, null, false, false, null]],
        '/NewFormClase' => [[['_route' => 'NewFormClase', '_controller' => 'App\\Controller\\ProductController::claseNewForm'], null, null, null, false, false, null]],
        '/listar' => [[['_route' => 'producto_listar', '_controller' => 'App\\Controller\\ProductController::listar'], null, null, null, false, false, null]],
        '/login' => [[['_route' => 'app_login', '_controller' => 'App\\Controller\\SecurityController::login'], null, null, null, false, false, null]],
        '/logout' => [[['_route' => 'app_logout', '_controller' => 'App\\Controller\\SecurityController::logout'], null, null, null, false, false, null]],
    ],
    [ // $regexpList
        0 => '{^(?'
                .'|/_(?'
                    .'|error/(\\d+)(?:\\.([^/]++))?(*:38)'
                    .'|wdt/([^/]++)(*:57)'
                    .'|profiler/([^/]++)(?'
                        .'|/(?'
                            .'|search/results(*:102)'
                            .'|router(*:116)'
                            .'|exception(?'
                                .'|(*:136)'
                                .'|\\.css(*:149)'
                            .')'
                        .')'
                        .'|(*:159)'
                    .')'
                .')'
                .'|/resultadoEncuestas/([^/]++)(*:197)'
                .'|/e(?'
                    .'|ncuestas/([^/]++)(*:227)'
                    .'|rror(?:/([^/]++))?(*:253)'
                .')'
                .'|/privado/(?'
                    .'|editMedico/([^/]++)(?:/([^/]++))?(*:307)'
                    .'|newMedico(?:/([^/]++))?(*:338)'
                .')'
                .'|/EditFormClase/([^/]++)(*:370)'
                .'|/show/([^/]++)(*:392)'
                .'|/delete/([^/]++)(*:416)'
                .'|/update/([^/]++)(*:440)'
            .')/?$}sDu',
    ],
    [ // $dynamicRoutes
        38 => [[['_route' => '_preview_error', '_controller' => 'error_controller::preview', '_format' => 'html'], ['code', '_format'], null, null, false, true, null]],
        57 => [[['_route' => '_wdt', '_controller' => 'web_profiler.controller.profiler::toolbarAction'], ['token'], null, null, false, true, null]],
        102 => [[['_route' => '_profiler_search_results', '_controller' => 'web_profiler.controller.profiler::searchResultsAction'], ['token'], null, null, false, false, null]],
        116 => [[['_route' => '_profiler_router', '_controller' => 'web_profiler.controller.router::panelAction'], ['token'], null, null, false, false, null]],
        136 => [[['_route' => '_profiler_exception', '_controller' => 'web_profiler.controller.exception_panel::body'], ['token'], null, null, false, false, null]],
        149 => [[['_route' => '_profiler_exception_css', '_controller' => 'web_profiler.controller.exception_panel::stylesheet'], ['token'], null, null, false, false, null]],
        159 => [[['_route' => '_profiler', '_controller' => 'web_profiler.controller.profiler::panelAction'], ['token'], null, null, false, true, null]],
        197 => [[['_route' => 'hospital_resultadoEncuestas', '_controller' => 'App\\Controller\\HospitalController::resultadoEncuestas'], ['id'], null, null, false, true, null]],
        227 => [[['_route' => 'hospital_preguntas', '_controller' => 'App\\Controller\\HospitalController::preguntas'], ['id'], null, null, false, true, null]],
        253 => [[['_route' => 'medico_error', 'error' => null, '_controller' => 'App\\Controller\\HospitalController::error'], ['error'], null, null, false, true, null]],
        307 => [[['_route' => 'editMedico', 'search' => null, '_controller' => 'App\\Controller\\HospitalController::editMedico'], ['id', 'search'], null, null, false, true, null]],
        338 => [[['_route' => 'newMedico', 'search' => null, '_controller' => 'App\\Controller\\HospitalController::newMedico'], ['search'], null, null, false, true, null]],
        370 => [[['_route' => 'EditFormClase', '_controller' => 'App\\Controller\\ProductController::EditFormClase'], ['id'], null, null, false, true, null]],
        392 => [[['_route' => 'producto_show', '_controller' => 'App\\Controller\\ProductController::show'], ['id'], null, null, false, true, null]],
        416 => [[['_route' => 'producto_delete', '_controller' => 'App\\Controller\\ProductController::delete'], ['id'], null, null, false, true, null]],
        440 => [
            [['_route' => 'producto_update', '_controller' => 'App\\Controller\\ProductController::update'], ['id'], null, null, false, true, null],
            [null, null, null, null, false, false, 0],
        ],
    ],
    null, // $checkCondition
];
