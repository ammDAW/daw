<?php

namespace ContainerC48cMWm;
include_once \dirname(__DIR__, 4).'/vendor/doctrine/persistence/lib/Doctrine/Persistence/ObjectManager.php';
include_once \dirname(__DIR__, 4).'/vendor/doctrine/orm/lib/Doctrine/ORM/EntityManagerInterface.php';
include_once \dirname(__DIR__, 4).'/vendor/doctrine/orm/lib/Doctrine/ORM/EntityManager.php';

class EntityManager_9a5be93 extends \Doctrine\ORM\EntityManager implements \ProxyManager\Proxy\VirtualProxyInterface
{

    /**
     * @var \Doctrine\ORM\EntityManager|null wrapped object, if the proxy is initialized
     */
    private $valueHolderee93d = null;

    /**
     * @var \Closure|null initializer responsible for generating the wrapped object
     */
    private $initializer87610 = null;

    /**
     * @var bool[] map of public properties of the parent class
     */
    private static $publicProperties0a3bb = [
        
    ];

    public function getConnection()
    {
        $this->initializer87610 && ($this->initializer87610->__invoke($valueHolderee93d, $this, 'getConnection', array(), $this->initializer87610) || 1) && $this->valueHolderee93d = $valueHolderee93d;

        return $this->valueHolderee93d->getConnection();
    }

    public function getMetadataFactory()
    {
        $this->initializer87610 && ($this->initializer87610->__invoke($valueHolderee93d, $this, 'getMetadataFactory', array(), $this->initializer87610) || 1) && $this->valueHolderee93d = $valueHolderee93d;

        return $this->valueHolderee93d->getMetadataFactory();
    }

    public function getExpressionBuilder()
    {
        $this->initializer87610 && ($this->initializer87610->__invoke($valueHolderee93d, $this, 'getExpressionBuilder', array(), $this->initializer87610) || 1) && $this->valueHolderee93d = $valueHolderee93d;

        return $this->valueHolderee93d->getExpressionBuilder();
    }

    public function beginTransaction()
    {
        $this->initializer87610 && ($this->initializer87610->__invoke($valueHolderee93d, $this, 'beginTransaction', array(), $this->initializer87610) || 1) && $this->valueHolderee93d = $valueHolderee93d;

        return $this->valueHolderee93d->beginTransaction();
    }

    public function getCache()
    {
        $this->initializer87610 && ($this->initializer87610->__invoke($valueHolderee93d, $this, 'getCache', array(), $this->initializer87610) || 1) && $this->valueHolderee93d = $valueHolderee93d;

        return $this->valueHolderee93d->getCache();
    }

    public function transactional($func)
    {
        $this->initializer87610 && ($this->initializer87610->__invoke($valueHolderee93d, $this, 'transactional', array('func' => $func), $this->initializer87610) || 1) && $this->valueHolderee93d = $valueHolderee93d;

        return $this->valueHolderee93d->transactional($func);
    }

    public function commit()
    {
        $this->initializer87610 && ($this->initializer87610->__invoke($valueHolderee93d, $this, 'commit', array(), $this->initializer87610) || 1) && $this->valueHolderee93d = $valueHolderee93d;

        return $this->valueHolderee93d->commit();
    }

    public function rollback()
    {
        $this->initializer87610 && ($this->initializer87610->__invoke($valueHolderee93d, $this, 'rollback', array(), $this->initializer87610) || 1) && $this->valueHolderee93d = $valueHolderee93d;

        return $this->valueHolderee93d->rollback();
    }

    public function getClassMetadata($className)
    {
        $this->initializer87610 && ($this->initializer87610->__invoke($valueHolderee93d, $this, 'getClassMetadata', array('className' => $className), $this->initializer87610) || 1) && $this->valueHolderee93d = $valueHolderee93d;

        return $this->valueHolderee93d->getClassMetadata($className);
    }

    public function createQuery($dql = '')
    {
        $this->initializer87610 && ($this->initializer87610->__invoke($valueHolderee93d, $this, 'createQuery', array('dql' => $dql), $this->initializer87610) || 1) && $this->valueHolderee93d = $valueHolderee93d;

        return $this->valueHolderee93d->createQuery($dql);
    }

    public function createNamedQuery($name)
    {
        $this->initializer87610 && ($this->initializer87610->__invoke($valueHolderee93d, $this, 'createNamedQuery', array('name' => $name), $this->initializer87610) || 1) && $this->valueHolderee93d = $valueHolderee93d;

        return $this->valueHolderee93d->createNamedQuery($name);
    }

    public function createNativeQuery($sql, \Doctrine\ORM\Query\ResultSetMapping $rsm)
    {
        $this->initializer87610 && ($this->initializer87610->__invoke($valueHolderee93d, $this, 'createNativeQuery', array('sql' => $sql, 'rsm' => $rsm), $this->initializer87610) || 1) && $this->valueHolderee93d = $valueHolderee93d;

        return $this->valueHolderee93d->createNativeQuery($sql, $rsm);
    }

    public function createNamedNativeQuery($name)
    {
        $this->initializer87610 && ($this->initializer87610->__invoke($valueHolderee93d, $this, 'createNamedNativeQuery', array('name' => $name), $this->initializer87610) || 1) && $this->valueHolderee93d = $valueHolderee93d;

        return $this->valueHolderee93d->createNamedNativeQuery($name);
    }

    public function createQueryBuilder()
    {
        $this->initializer87610 && ($this->initializer87610->__invoke($valueHolderee93d, $this, 'createQueryBuilder', array(), $this->initializer87610) || 1) && $this->valueHolderee93d = $valueHolderee93d;

        return $this->valueHolderee93d->createQueryBuilder();
    }

    public function flush($entity = null)
    {
        $this->initializer87610 && ($this->initializer87610->__invoke($valueHolderee93d, $this, 'flush', array('entity' => $entity), $this->initializer87610) || 1) && $this->valueHolderee93d = $valueHolderee93d;

        return $this->valueHolderee93d->flush($entity);
    }

    public function find($className, $id, $lockMode = null, $lockVersion = null)
    {
        $this->initializer87610 && ($this->initializer87610->__invoke($valueHolderee93d, $this, 'find', array('className' => $className, 'id' => $id, 'lockMode' => $lockMode, 'lockVersion' => $lockVersion), $this->initializer87610) || 1) && $this->valueHolderee93d = $valueHolderee93d;

        return $this->valueHolderee93d->find($className, $id, $lockMode, $lockVersion);
    }

    public function getReference($entityName, $id)
    {
        $this->initializer87610 && ($this->initializer87610->__invoke($valueHolderee93d, $this, 'getReference', array('entityName' => $entityName, 'id' => $id), $this->initializer87610) || 1) && $this->valueHolderee93d = $valueHolderee93d;

        return $this->valueHolderee93d->getReference($entityName, $id);
    }

    public function getPartialReference($entityName, $identifier)
    {
        $this->initializer87610 && ($this->initializer87610->__invoke($valueHolderee93d, $this, 'getPartialReference', array('entityName' => $entityName, 'identifier' => $identifier), $this->initializer87610) || 1) && $this->valueHolderee93d = $valueHolderee93d;

        return $this->valueHolderee93d->getPartialReference($entityName, $identifier);
    }

    public function clear($entityName = null)
    {
        $this->initializer87610 && ($this->initializer87610->__invoke($valueHolderee93d, $this, 'clear', array('entityName' => $entityName), $this->initializer87610) || 1) && $this->valueHolderee93d = $valueHolderee93d;

        return $this->valueHolderee93d->clear($entityName);
    }

    public function close()
    {
        $this->initializer87610 && ($this->initializer87610->__invoke($valueHolderee93d, $this, 'close', array(), $this->initializer87610) || 1) && $this->valueHolderee93d = $valueHolderee93d;

        return $this->valueHolderee93d->close();
    }

    public function persist($entity)
    {
        $this->initializer87610 && ($this->initializer87610->__invoke($valueHolderee93d, $this, 'persist', array('entity' => $entity), $this->initializer87610) || 1) && $this->valueHolderee93d = $valueHolderee93d;

        return $this->valueHolderee93d->persist($entity);
    }

    public function remove($entity)
    {
        $this->initializer87610 && ($this->initializer87610->__invoke($valueHolderee93d, $this, 'remove', array('entity' => $entity), $this->initializer87610) || 1) && $this->valueHolderee93d = $valueHolderee93d;

        return $this->valueHolderee93d->remove($entity);
    }

    public function refresh($entity)
    {
        $this->initializer87610 && ($this->initializer87610->__invoke($valueHolderee93d, $this, 'refresh', array('entity' => $entity), $this->initializer87610) || 1) && $this->valueHolderee93d = $valueHolderee93d;

        return $this->valueHolderee93d->refresh($entity);
    }

    public function detach($entity)
    {
        $this->initializer87610 && ($this->initializer87610->__invoke($valueHolderee93d, $this, 'detach', array('entity' => $entity), $this->initializer87610) || 1) && $this->valueHolderee93d = $valueHolderee93d;

        return $this->valueHolderee93d->detach($entity);
    }

    public function merge($entity)
    {
        $this->initializer87610 && ($this->initializer87610->__invoke($valueHolderee93d, $this, 'merge', array('entity' => $entity), $this->initializer87610) || 1) && $this->valueHolderee93d = $valueHolderee93d;

        return $this->valueHolderee93d->merge($entity);
    }

    public function copy($entity, $deep = false)
    {
        $this->initializer87610 && ($this->initializer87610->__invoke($valueHolderee93d, $this, 'copy', array('entity' => $entity, 'deep' => $deep), $this->initializer87610) || 1) && $this->valueHolderee93d = $valueHolderee93d;

        return $this->valueHolderee93d->copy($entity, $deep);
    }

    public function lock($entity, $lockMode, $lockVersion = null)
    {
        $this->initializer87610 && ($this->initializer87610->__invoke($valueHolderee93d, $this, 'lock', array('entity' => $entity, 'lockMode' => $lockMode, 'lockVersion' => $lockVersion), $this->initializer87610) || 1) && $this->valueHolderee93d = $valueHolderee93d;

        return $this->valueHolderee93d->lock($entity, $lockMode, $lockVersion);
    }

    public function getRepository($entityName)
    {
        $this->initializer87610 && ($this->initializer87610->__invoke($valueHolderee93d, $this, 'getRepository', array('entityName' => $entityName), $this->initializer87610) || 1) && $this->valueHolderee93d = $valueHolderee93d;

        return $this->valueHolderee93d->getRepository($entityName);
    }

    public function contains($entity)
    {
        $this->initializer87610 && ($this->initializer87610->__invoke($valueHolderee93d, $this, 'contains', array('entity' => $entity), $this->initializer87610) || 1) && $this->valueHolderee93d = $valueHolderee93d;

        return $this->valueHolderee93d->contains($entity);
    }

    public function getEventManager()
    {
        $this->initializer87610 && ($this->initializer87610->__invoke($valueHolderee93d, $this, 'getEventManager', array(), $this->initializer87610) || 1) && $this->valueHolderee93d = $valueHolderee93d;

        return $this->valueHolderee93d->getEventManager();
    }

    public function getConfiguration()
    {
        $this->initializer87610 && ($this->initializer87610->__invoke($valueHolderee93d, $this, 'getConfiguration', array(), $this->initializer87610) || 1) && $this->valueHolderee93d = $valueHolderee93d;

        return $this->valueHolderee93d->getConfiguration();
    }

    public function isOpen()
    {
        $this->initializer87610 && ($this->initializer87610->__invoke($valueHolderee93d, $this, 'isOpen', array(), $this->initializer87610) || 1) && $this->valueHolderee93d = $valueHolderee93d;

        return $this->valueHolderee93d->isOpen();
    }

    public function getUnitOfWork()
    {
        $this->initializer87610 && ($this->initializer87610->__invoke($valueHolderee93d, $this, 'getUnitOfWork', array(), $this->initializer87610) || 1) && $this->valueHolderee93d = $valueHolderee93d;

        return $this->valueHolderee93d->getUnitOfWork();
    }

    public function getHydrator($hydrationMode)
    {
        $this->initializer87610 && ($this->initializer87610->__invoke($valueHolderee93d, $this, 'getHydrator', array('hydrationMode' => $hydrationMode), $this->initializer87610) || 1) && $this->valueHolderee93d = $valueHolderee93d;

        return $this->valueHolderee93d->getHydrator($hydrationMode);
    }

    public function newHydrator($hydrationMode)
    {
        $this->initializer87610 && ($this->initializer87610->__invoke($valueHolderee93d, $this, 'newHydrator', array('hydrationMode' => $hydrationMode), $this->initializer87610) || 1) && $this->valueHolderee93d = $valueHolderee93d;

        return $this->valueHolderee93d->newHydrator($hydrationMode);
    }

    public function getProxyFactory()
    {
        $this->initializer87610 && ($this->initializer87610->__invoke($valueHolderee93d, $this, 'getProxyFactory', array(), $this->initializer87610) || 1) && $this->valueHolderee93d = $valueHolderee93d;

        return $this->valueHolderee93d->getProxyFactory();
    }

    public function initializeObject($obj)
    {
        $this->initializer87610 && ($this->initializer87610->__invoke($valueHolderee93d, $this, 'initializeObject', array('obj' => $obj), $this->initializer87610) || 1) && $this->valueHolderee93d = $valueHolderee93d;

        return $this->valueHolderee93d->initializeObject($obj);
    }

    public function getFilters()
    {
        $this->initializer87610 && ($this->initializer87610->__invoke($valueHolderee93d, $this, 'getFilters', array(), $this->initializer87610) || 1) && $this->valueHolderee93d = $valueHolderee93d;

        return $this->valueHolderee93d->getFilters();
    }

    public function isFiltersStateClean()
    {
        $this->initializer87610 && ($this->initializer87610->__invoke($valueHolderee93d, $this, 'isFiltersStateClean', array(), $this->initializer87610) || 1) && $this->valueHolderee93d = $valueHolderee93d;

        return $this->valueHolderee93d->isFiltersStateClean();
    }

    public function hasFilters()
    {
        $this->initializer87610 && ($this->initializer87610->__invoke($valueHolderee93d, $this, 'hasFilters', array(), $this->initializer87610) || 1) && $this->valueHolderee93d = $valueHolderee93d;

        return $this->valueHolderee93d->hasFilters();
    }

    /**
     * Constructor for lazy initialization
     *
     * @param \Closure|null $initializer
     */
    public static function staticProxyConstructor($initializer)
    {
        static $reflection;

        $reflection = $reflection ?? new \ReflectionClass(__CLASS__);
        $instance   = $reflection->newInstanceWithoutConstructor();

        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $instance, 'Doctrine\\ORM\\EntityManager')->__invoke($instance);

        $instance->initializer87610 = $initializer;

        return $instance;
    }

    protected function __construct(\Doctrine\DBAL\Connection $conn, \Doctrine\ORM\Configuration $config, \Doctrine\Common\EventManager $eventManager)
    {
        static $reflection;

        if (! $this->valueHolderee93d) {
            $reflection = $reflection ?? new \ReflectionClass('Doctrine\\ORM\\EntityManager');
            $this->valueHolderee93d = $reflection->newInstanceWithoutConstructor();
        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $this, 'Doctrine\\ORM\\EntityManager')->__invoke($this);

        }

        $this->valueHolderee93d->__construct($conn, $config, $eventManager);
    }

    public function & __get($name)
    {
        $this->initializer87610 && ($this->initializer87610->__invoke($valueHolderee93d, $this, '__get', ['name' => $name], $this->initializer87610) || 1) && $this->valueHolderee93d = $valueHolderee93d;

        if (isset(self::$publicProperties0a3bb[$name])) {
            return $this->valueHolderee93d->$name;
        }

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolderee93d;

            $backtrace = debug_backtrace(false, 1);
            trigger_error(
                sprintf(
                    'Undefined property: %s::$%s in %s on line %s',
                    $realInstanceReflection->getName(),
                    $name,
                    $backtrace[0]['file'],
                    $backtrace[0]['line']
                ),
                \E_USER_NOTICE
            );
            return $targetObject->$name;
        }

        $targetObject = $this->valueHolderee93d;
        $accessor = function & () use ($targetObject, $name) {
            return $targetObject->$name;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = & $accessor();

        return $returnValue;
    }

    public function __set($name, $value)
    {
        $this->initializer87610 && ($this->initializer87610->__invoke($valueHolderee93d, $this, '__set', array('name' => $name, 'value' => $value), $this->initializer87610) || 1) && $this->valueHolderee93d = $valueHolderee93d;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolderee93d;

            $targetObject->$name = $value;

            return $targetObject->$name;
        }

        $targetObject = $this->valueHolderee93d;
        $accessor = function & () use ($targetObject, $name, $value) {
            $targetObject->$name = $value;

            return $targetObject->$name;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = & $accessor();

        return $returnValue;
    }

    public function __isset($name)
    {
        $this->initializer87610 && ($this->initializer87610->__invoke($valueHolderee93d, $this, '__isset', array('name' => $name), $this->initializer87610) || 1) && $this->valueHolderee93d = $valueHolderee93d;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolderee93d;

            return isset($targetObject->$name);
        }

        $targetObject = $this->valueHolderee93d;
        $accessor = function () use ($targetObject, $name) {
            return isset($targetObject->$name);
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = $accessor();

        return $returnValue;
    }

    public function __unset($name)
    {
        $this->initializer87610 && ($this->initializer87610->__invoke($valueHolderee93d, $this, '__unset', array('name' => $name), $this->initializer87610) || 1) && $this->valueHolderee93d = $valueHolderee93d;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolderee93d;

            unset($targetObject->$name);

            return;
        }

        $targetObject = $this->valueHolderee93d;
        $accessor = function () use ($targetObject, $name) {
            unset($targetObject->$name);

            return;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $accessor();
    }

    public function __clone()
    {
        $this->initializer87610 && ($this->initializer87610->__invoke($valueHolderee93d, $this, '__clone', array(), $this->initializer87610) || 1) && $this->valueHolderee93d = $valueHolderee93d;

        $this->valueHolderee93d = clone $this->valueHolderee93d;
    }

    public function __sleep()
    {
        $this->initializer87610 && ($this->initializer87610->__invoke($valueHolderee93d, $this, '__sleep', array(), $this->initializer87610) || 1) && $this->valueHolderee93d = $valueHolderee93d;

        return array('valueHolderee93d');
    }

    public function __wakeup()
    {
        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $this, 'Doctrine\\ORM\\EntityManager')->__invoke($this);
    }

    public function setProxyInitializer(\Closure $initializer = null) : void
    {
        $this->initializer87610 = $initializer;
    }

    public function getProxyInitializer() : ?\Closure
    {
        return $this->initializer87610;
    }

    public function initializeProxy() : bool
    {
        return $this->initializer87610 && ($this->initializer87610->__invoke($valueHolderee93d, $this, 'initializeProxy', array(), $this->initializer87610) || 1) && $this->valueHolderee93d = $valueHolderee93d;
    }

    public function isProxyInitialized() : bool
    {
        return null !== $this->valueHolderee93d;
    }

    public function getWrappedValueHolderValue()
    {
        return $this->valueHolderee93d;
    }


}

if (!\class_exists('EntityManager_9a5be93', false)) {
    \class_alias(__NAMESPACE__.'\\EntityManager_9a5be93', 'EntityManager_9a5be93', false);
}
